import React, { useState } from 'react';
import {
  ARTIFACTS,
  BUILDER_BLUEPRINTS,
  CROPS,
  FACTORIES,
  FACTORY_RECIPES,
  FARM_ANIMALS,
  MATERIALS_META,
  OUTFITS,
  QUESTS,
  STOCK_COMPANIES,
  TECH_TREE,
  VEHICLES,
} from '../data/catalog';
import { DIG_SPOTS, FARM_PARCELS, ISLANDS, IslandId, SITES } from '../data/islandsData';
import { GameState, PlayerProfile } from '../data/storage';
import { AudioSettings, audioSys } from '../engine/AudioSystem';
import { RoadAuditReport } from '../engine/CollisionSystem';
import { QualityPreset, WeatherMode } from '../engine/ThreeEngine';

export type ModalId =
  | null
  | 'map'
  | 'factory'
  | 'exchange'
  | 'bank'
  | 'company'
  | 'elevator'
  | 'port'
  | 'dealership'
  | 'garage'
  | 'farm'
  | 'builder'
  | 'tech'
  | 'archaeology'
  | 'quests'
  | 'wardrobe'
  | 'fridge'
  | 'shop'
  | 'police'
  | 'restaurant'
  | 'hotel'
  | 'citymetrics'
  | 'settings';

interface GameModalsProps {
  modal: ModalId;
  factoryId: string;
  state: GameState;
  profile: PlayerProfile;
  roadAudit: RoadAuditReport | null;
  quality: QualityPreset;
  weather: WeatherMode;
  gameHour: number;
  hqFloor: number;
  onClose: () => void;
  onDispatch: (title: string, body: Record<string, any>) => void;
  onTeleport: (x: number, z: number) => void;
  onEnterInterior: (id: string, floor?: number) => void;
  onStartBuildGhost: (blueprintId: string) => void;
  onQualityChange: (q: QualityPreset) => void;
  onWeatherChange: (w: WeatherMode) => void;
  onHourChange: (h: number) => void;
  onProfileChange: (patch: Partial<PlayerProfile>) => void;
  onResetSave: () => void;
  onExportSave: () => string;
  onImportSave: (json: string) => boolean;
}

export const GameModals: React.FC<GameModalsProps> = ({
  modal,
  factoryId,
  state,
  profile,
  roadAudit,
  quality,
  weather,
  gameHour,
  hqFloor,
  onClose,
  onDispatch,
  onTeleport,
  onEnterInterior,
  onStartBuildGhost,
  onQualityChange,
  onWeatherChange,
  onHourChange,
  onProfileChange,
  onResetSave,
  onExportSave,
  onImportSave,
}) => {
  const [selectedFactory, setSelectedFactory] = useState(factoryId || 'glass');
  const [bankAmt, setBankAmt] = useState(200);
  const [exportItem, setExportItem] = useState('glass_sheet');
  const [exportQty, setExportQty] = useState(2);
  const [selectedCrop, setSelectedCrop] = useState('wheat');
  const [audioCfg, setAudioCfg] = useState<AudioSettings>(() => audioSys.getSettings());
  const [importText, setImportText] = useState('');
  const [exportPreview, setExportPreview] = useState('');

  if (!modal) return null;

  const activeFacId = modal === 'factory' ? (factoryId || selectedFactory) : selectedFactory;
  const facDef = FACTORIES[activeFacId] || FACTORIES.glass;
  const facState = state.factories[facDef.id];
  const activeVeh = state.vehicles.find((v) => v.uid === state.activeVehicleUid) || state.vehicles[0];

  const updateAudio = (patch: Partial<AudioSettings>) => {
    audioSys.updateSettings(patch);
    setAudioCfg(audioSys.getSettings());
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-6"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-4xl max-h-[88vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-right">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5 font-bold text-lg text-amber-400">
            <span>
              {modal === 'map' && '🗺️ خريطة الحضارات السبع والعالم'}
              {modal === 'factory' && `${facDef.emoji} ${facDef.name}`}
              {modal === 'exchange' && '📈 البورصة المركزية المباشرة'}
              {modal === 'bank' && '🏦 البنك المركزي والخزينة'}
              {modal === 'company' && '🏢 إدارة الشركات والعمليات'}
              {modal === 'elevator' && '🛗 مصعد برج الإدارة (5 طوابق)'}
              {modal === 'port' && '🚢 الميناء البحري والتصدير'}
              {modal === 'dealership' && '🚘 معرض السيارات (28 مركبة)'}
              {modal === 'garage' && '🔧 ورشة تصليح وتطوير المركبات'}
              {modal === 'farm' && '🌾 الحقول الزراعية الـ36 والحيوانات'}
              {modal === 'builder' && '🏗️ المخطط العمراني ثلاثي الأبعاد'}
              {modal === 'tech' && '🔬 شجرة التكنولوجيا والأبحاث'}
              {modal === 'archaeology' && '🏺 الآثار والتنقيب والمتحف'}
              {modal === 'quests' && '🎯 سجل المهام والرحلات الحضارية'}
              {modal === 'wardrobe' && '👗 خزانة الملابس والأزياء'}
              {modal === 'fridge' && '🧊 الثلاجة والمطبخ'}
              {modal === 'shop' && '🏪 السوق والمتاجر'}
              {modal === 'police' && '👮 مركز الشرطة والمرور'}
              {modal === 'restaurant' && '🍽️ مطعم الديوان الشرقي'}
              {modal === 'hotel' && '🏨 فندق الواحة الملكي'}
              {modal === 'citymetrics' && '👑 مجلس المدينة والمؤشرات الحضرية'}
              {modal === 'settings' && '⚙️ الإعدادات والجودة والحفظ'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono-num text-sm bg-slate-800 px-3 py-1 rounded-lg text-amber-300 border border-amber-500/30">
              🪙 {state.coins.toLocaleString()}
            </span>
            <button
              onClick={onClose}
              className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-rose-600 text-slate-200 text-sm font-bold transition-colors cursor-pointer"
            >
              إغلاق ✕
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto osw-scroll space-y-4">
          {/* ============ 1. WORLD MAP & CIVILIZATIONS ============ */}
          {modal === 'map' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.values(ISLANDS).map((isl) => {
                  const islSites = SITES.filter((s) => s.islandId === isl.id);
                  return (
                    <div key={isl.id} className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 flex flex-col justify-between gap-2">
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-base text-slate-100">
                            {isl.emoji} {isl.name}
                          </span>
                          <span className="text-xs font-mono-num text-slate-400">
                            ({isl.cx}, {isl.cz})
                          </span>
                        </div>
                        <div className="text-xs text-amber-400 font-semibold mt-0.5">{isl.civTitle}</div>
                        <p className="text-xs text-slate-300 mt-1 leading-relaxed">{isl.eraDesc}</p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {islSites.slice(0, 4).map((s) => (
                            <button
                              key={s.id}
                              onClick={() => {
                                onTeleport(s.frontX, s.frontZ);
                                onClose();
                              }}
                              className="text-[11px] bg-slate-900 hover:bg-slate-700 text-slate-200 px-2 py-0.5 rounded border border-slate-700 cursor-pointer"
                            >
                              {s.emoji} {s.name.split(' ')[0]}
                            </button>
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          onTeleport(isl.cx, isl.cz + 18);
                          onClose();
                        }}
                        className="w-full py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold cursor-pointer"
                      >
                        انتقال سريع للمركز 🧭
                      </button>
                    </div>
                  );
                })}
              </div>
              {roadAudit && (
                <div className="text-xs bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 flex items-center justify-between">
                  <span>
                    فحص خلوّ الطرق والجسور: تم فحص {roadAudit.checkedRoads} طريقاً وجسراً و{roadAudit.checkedColliders} مجسّماً
                  </span>
                  <span className={roadAudit.passed ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {roadAudit.passed ? '✅ جميع الطرق سالكة 100%' : `⚠️ عوائق: ${roadAudit.obstructions.length}`}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* ============ 2. FACTORIES (AL-NOOR GLASS FACTORY GOLD STANDARD + 6 OTHERS) ============ */}
          {modal === 'factory' && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {Object.values(FACTORIES).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSelectedFactory(f.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border cursor-pointer ${
                      facDef.id === f.id
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {f.emoji} {f.name}
                  </button>
                ))}
              </div>

              <div className="bg-slate-800/70 border border-slate-700 rounded-xl p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-base text-slate-100">{facDef.emoji} {facDef.name}</h3>
                    <p className="text-xs text-slate-300">{facDef.subtitle}</p>
                  </div>
                  {!facState.built ? (
                    <button
                      onClick={() => onDispatch('v15_factory_upgrade', { factoryId: facDef.id, kind: 'build' })}
                      disabled={state.coins < facDef.buildCost}
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-sm font-bold cursor-pointer"
                    >
                      بناء وتجهيز المصنع ({facDef.buildCost}🪙)
                    </button>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => onDispatch('v15_factory_upgrade', { factoryId: facDef.id, kind: 'worker' })}
                        disabled={facState.workers >= facDef.maxWorkers || state.coins < 85}
                        className="px-3 py-1.5 rounded-lg bg-sky-700 hover:bg-sky-600 disabled:opacity-40 text-xs font-bold text-white cursor-pointer"
                      >
                        👷 توظيف عامل ({facState.workers}/{facDef.maxWorkers}) · 85🪙
                      </button>
                      <button
                        onClick={() => onDispatch('v15_factory_upgrade', { factoryId: facDef.id, kind: 'machine' })}
                        disabled={facState.machines >= facDef.maxMachines || state.coins < 160}
                        className="px-3 py-1.5 rounded-lg bg-indigo-700 hover:bg-indigo-600 disabled:opacity-40 text-xs font-bold text-white cursor-pointer"
                      >
                        ⚙️ إضافة خط إنتاج ({facState.machines}/{facDef.maxMachines}) · 160🪙
                      </button>
                    </div>
                  )}
                </div>

                {facState.built && (
                  <>
                    {/* Active Batch Progress */}
                    {facState.activeJob && (
                      <div className="bg-slate-950 border border-amber-500/40 rounded-lg p-3 flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-bold text-amber-300">
                            🔥 خط الإنتاج يعمل: {FACTORY_RECIPES[facState.activeJob.recipeId]?.name}
                          </div>
                          <div className="text-xs text-slate-400 font-mono-num">
                            {Date.now() >= facState.activeJob.endAt
                              ? '✅ الدفعة جاهزة للاستلام!'
                              : `الوقت المتبقي: ${Math.ceil((facState.activeJob.endAt - Date.now()) / 1000)} ثانية`}
                          </div>
                        </div>
                        <button
                          onClick={() => onDispatch('v15_factory_collect', { factoryId: facDef.id })}
                          disabled={Date.now() < facState.activeJob.endAt}
                          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                        >
                          استلام الإنتاج 📦
                        </button>
                      </div>
                    )}

                    {/* Recipes */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {facDef.recipes.map((rid) => {
                        const rec = FACTORY_RECIPES[rid];
                        const hasInputs = Object.entries(rec.inputs).every(([k, q]) => (state.inventory[k] || 0) >= q);
                        const hasWorkers = facState.workers >= rec.minWorkers;
                        const canStart = !facState.activeJob && hasInputs && hasWorkers;
                        return (
                          <div key={rid} className="bg-slate-900/90 border border-slate-700 rounded-xl p-3 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-sm text-slate-100">{rec.emoji} {rec.name}</span>
                              <span className="text-xs text-slate-400">⏱️ {rec.durationSec}ث · 👷 {rec.minWorkers}+</span>
                            </div>
                            <div className="text-xs text-slate-300">
                              المواد المطلوبة:{' '}
                              {Object.entries(rec.inputs)
                                .map(([k, q]) => `${MATERIALS_META[k]?.emoji || ''} ${MATERIALS_META[k]?.name || CROPS[k]?.name || k} ×${q} (لديك ${state.inventory[k] || 0})`)
                                .join(' · ')}
                            </div>
                            <div className="text-xs text-emerald-400">
                              الناتج:{' '}
                              {Object.entries(rec.outputs)
                                .map(([k, q]) => `${MATERIALS_META[k]?.name || k} ×${q}`)
                                .join(' + ')}
                            </div>
                            <div className="flex items-center gap-2 pt-1">
                              <button
                                onClick={() => onDispatch('v15_factory_start', { factoryId: facDef.id, recipeId: rec.id })}
                                disabled={!canStart}
                                className="flex-1 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-bold cursor-pointer"
                              >
                                تشغيل الدفعة 🔥
                              </button>
                              {Object.keys(rec.inputs).map((mat) => (
                                <button
                                  key={mat}
                                  onClick={() =>
                                    onDispatch('v15_buy_mat', {
                                      item: mat,
                                      qty: 3,
                                      unitPrice: MATERIALS_META[mat]?.basePrice || 15,
                                    })
                                  }
                                  className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-200 border border-slate-700 cursor-pointer"
                                  title="شراء مواد خام"
                                >
                                  +3 {MATERIALS_META[mat]?.emoji || '📦'}
                                </button>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* ============ 3. STOCK EXCHANGE ============ */}
          {modal === 'exchange' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                أسعار الأسهم مرتبطة مباشرة بأداء المصانع والشحنات البحرية والأحداث الاقتصادية، وتوزّع أرباحاً دورية كل دقيقة.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {STOCK_COMPANIES.map((c) => {
                  const price = state.stockPrices[c.ticker] || c.basePrice;
                  const hist = state.stockHistory[c.ticker] || [price];
                  const prev = hist[hist.length - 2] || price;
                  const diffPct = prev > 0 ? ((price - prev) / prev) * 100 : 0;
                  const owned = state.stocksOwned[c.ticker] || 0;
                  return (
                    <div key={c.ticker} className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-bold text-sm text-slate-100">
                            {c.emoji} {c.name} <span className="font-mono-num text-xs text-amber-400">({c.ticker})</span>
                          </div>
                          <div className="text-[11px] text-slate-400">{c.sector} · أرباح {(c.dividendRate * 100).toFixed(1)}%</div>
                        </div>
                        <div className="text-left font-mono-num">
                          <div className="text-base font-bold text-slate-100">{price.toFixed(1)} 🪙</div>
                          <div className={`text-xs font-bold ${diffPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {diffPct >= 0 ? '▲' : '▼'} {Math.abs(diffPct).toFixed(2)}%
                          </div>
                        </div>
                      </div>
                      {/* Mini SVG Sparkline */}
                      <svg viewBox="0 0 120 26" className="w-full h-7 bg-slate-950/60 rounded p-0.5">
                        <polyline
                          fill="none"
                          stroke={diffPct >= 0 ? '#10b981' : '#ef4444'}
                          strokeWidth="2"
                          points={hist
                            .map((val, i) => {
                              const min = Math.min(...hist);
                              const max = Math.max(...hist);
                              const span = Math.max(1, max - min);
                              const x = (i / Math.max(1, hist.length - 1)) * 116 + 2;
                              const y = 24 - ((val - min) / span) * 20;
                              return `${x},${y}`;
                            })
                            .join(' ')}
                        />
                      </svg>
                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="text-slate-300">محفظتك: <b className="font-mono-num text-amber-300">{owned}</b> سهم</span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => onDispatch('v15_stock_buy', { ticker: c.ticker, qty: 1, price })}
                            disabled={state.coins < price}
                            className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold cursor-pointer"
                          >
                            شراء 1
                          </button>
                          <button
                            onClick={() => onDispatch('v15_stock_sell', { ticker: c.ticker, qty: 1, price })}
                            disabled={owned < 1}
                            className="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white font-bold cursor-pointer"
                          >
                            بيع 1
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ============ 4. CENTRAL BANK ============ */}
          {modal === 'bank' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="text-xs text-slate-400">رصيدك النقدي</div>
                  <div className="text-xl font-bold font-mono-num text-amber-300">{state.coins.toLocaleString()} 🪙</div>
                </div>
                <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="text-xs text-slate-400">الودائع بالخزينة</div>
                  <div className="text-xl font-bold font-mono-num text-emerald-400">{state.bankBalance.toLocaleString()} 🪙</div>
                </div>
                <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
                  <div className="text-xs text-slate-400">القرض القائم</div>
                  <div className="text-xl font-bold font-mono-num text-rose-400">{state.bankLoan.toLocaleString()} 🪙</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <label className="text-sm text-slate-300">المبلغ:</label>
                <input
                  type="number"
                  value={bankAmt}
                  onChange={(e) => setBankAmt(Math.max(10, Number(e.target.value)))}
                  className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-sm font-mono-num w-32 text-slate-100"
                />
                <button
                  onClick={() => onDispatch('v15_bank', { op: 'deposit', amount: bankAmt })}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white cursor-pointer"
                >
                  إيداع بالخزينة
                </button>
                <button
                  onClick={() => onDispatch('v15_bank', { op: 'withdraw', amount: bankAmt })}
                  className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-bold text-white cursor-pointer"
                >
                  سحب نقدي
                </button>
                <button
                  onClick={() => onDispatch('v15_bank', { op: 'loan', amount: bankAmt })}
                  className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-xs font-bold text-white cursor-pointer"
                >
                  قرض استثماري (+10%)
                </button>
                <button
                  onClick={() => onDispatch('v15_bank', { op: 'repay', amount: bankAmt })}
                  disabled={state.bankLoan <= 0}
                  className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-xs font-bold text-white cursor-pointer"
                >
                  سداد القرض
                </button>
              </div>
            </div>
          )}

          {/* ============ 5. HQ ELEVATOR & COMPANY ============ */}
          {(modal === 'elevator' || modal === 'company') && (
            <div className="space-y-4">
              <p className="text-sm text-slate-300">
                اختر الطابق في برج الإدارة للانتقال الفوري عبر المصعد:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { fl: 0, name: 'الاستقبال (الطابق الأرضي)', emoji: '🛎️' },
                  { fl: 1, name: 'الموارد البشرية (ط1)', emoji: '👷' },
                  { fl: 2, name: 'المالية والتسويق (ط2)', emoji: '📊' },
                  { fl: 3, name: 'مكتب الرئيس التنفيذي (ط3)', emoji: '👔' },
                  { fl: 4, name: 'مختبر التطوير (ط4)', emoji: '🔬' },
                  { fl: 5, name: 'السطح ومهبط الطائرات (ط5)', emoji: '🚁' },
                ].map((f) => (
                  <button
                    key={f.fl}
                    onClick={() => {
                      audioSys.playSfx('elevator');
                      onEnterInterior('biz_hq', f.fl);
                      onClose();
                    }}
                    className={`p-3 rounded-xl border text-right cursor-pointer ${
                      hqFloor === f.fl
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-100 border-slate-700'
                    }`}
                  >
                    <div className="text-lg">{f.emoji}</div>
                    <div className="text-xs mt-1">{f.name}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ============ 6. PORT EXPORT & MARITIME LOGISTICS ============ */}
          {modal === 'port' && (
            <div className="space-y-4">
              <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-4 space-y-3">
                <h4 className="font-bold text-sm text-sky-300">🚢 إطلاق شحنة تصدير بحرية (تتحرك الشاحنة والرافعة والسفينة مباشرة)</h4>
                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={exportItem}
                    onChange={(e) => setExportItem(e.target.value)}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100"
                  >
                    {['glass_sheet', 'glass_bottle', 'stained_glass', 'steel_beam', 'wood_plank', 'royal_pottery', 'silk_fabric', 'smart_chip'].map((k) => (
                      <option key={k} value={k}>
                        {MATERIALS_META[k].emoji} {MATERIALS_META[k].name} (بالمخزن: {state.inventory[k] || 0})
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={exportQty}
                    onChange={(e) => setExportQty(Math.max(1, Number(e.target.value)))}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm w-20 font-mono-num text-slate-100"
                  />
                  <button
                    onClick={() => {
                      const base = MATERIALS_META[exportItem]?.basePrice || 60;
                      const payout = Math.round(base * 1.65 * exportQty);
                      onDispatch('v15_export_launch', {
                        itemKey: exportItem,
                        qty: exportQty,
                        destination: 'موانئ الشرق الدولية',
                        payout,
                      });
                    }}
                    disabled={(state.inventory[exportItem] || 0) < exportQty}
                    className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                  >
                    إطلاق التصدير الآن ⚓
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-sm text-slate-200">الشحنات البحرية النشطة ({state.shipments.length})</h4>
                {state.shipments.length === 0 && (
                  <p className="text-xs text-slate-400">لا توجد شحنات حالياً. صنّع بضائع من جزيرة الصناعة وصدّرها من هنا.</p>
                )}
                {state.shipments.map((sh) => {
                  const ready = Date.now() >= sh.endAt;
                  return (
                    <div key={sh.id} className="bg-slate-800 border border-slate-700 rounded-lg p-3 flex items-center justify-between">
                      <div className="text-xs">
                        <b className="text-slate-100">{MATERIALS_META[sh.itemKey]?.name || sh.itemKey} ×{sh.qty}</b>
                        <div className="text-slate-400">
                          {sh.claimed ? '✅ تم استلام العائد' : ready ? '🏁 وصلت للميناء — جاهزة للاستلام!' : '🚢 قيد الإبحار والرافعة تعمل...'}
                        </div>
                      </div>
                      {!sh.claimed && (
                        <button
                          onClick={() => onDispatch('v15_export_claim', { shipmentId: sh.id })}
                          disabled={!ready}
                          className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                        >
                          تحصيل {sh.payout}🪙
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ============ 7. DEALERSHIP & GARAGE ============ */}
          {modal === 'dealership' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.values(VEHICLES).map((v) => {
                const owned = state.vehicles.some((o) => o.defId === v.id);
                return (
                  <div key={v.id} className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 flex flex-col justify-between gap-2">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-slate-100">{v.emoji} {v.name}</span>
                        <span className="text-[11px] bg-slate-900 px-2 py-0.5 rounded text-sky-300">
                          {v.fuelType === 'ev' ? '🔋 كهرباء' : v.fuelType === 'diesel' ? '🛢️ ديزل' : '⛽ بنزين'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">{v.desc}</p>
                      <div className="text-[11px] text-slate-300 mt-1.5 font-mono-num">
                        السرعة: {v.topSpeed * 3} كم/س · المقاعد: {v.seats}
                      </div>
                    </div>
                    <button
                      onClick={() => onDispatch('cbuy', { car: v.id, color: v.defaultColor })}
                      disabled={state.coins < v.price}
                      className="w-full py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-bold cursor-pointer"
                    >
                      {owned ? `شراء نسخة إضافية (${v.price}🪙)` : `شراء (${v.price}🪙)`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {modal === 'garage' && activeVeh && (
            <div className="space-y-4">
              <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <div className="font-bold text-base text-slate-100">
                    {VEHICLES[activeVeh.defId]?.emoji} {VEHICLES[activeVeh.defId]?.name}
                  </div>
                  <div className="text-xs text-slate-300 font-mono-num mt-1">
                    الحالة الهيكلية: {activeVeh.health}% · الوقود/البطارية: {Math.round(activeVeh.fuel)}/{VEHICLES[activeVeh.defId]?.tankSize}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => onDispatch('v15_veh_repair', { vehUid: activeVeh.uid, cost: 45 })}
                    disabled={activeVeh.health >= 100 || state.coins < 45}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                  >
                    تصليح كامل (45🪙) 🔧
                  </button>
                  <button
                    onClick={() => onDispatch('v15_veh_refuel', { vehUid: activeVeh.uid, cost: 25 })}
                    disabled={state.coins < 25}
                    className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                  >
                    تعبئة / شحن كامل (25🪙) ⛽
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ============ 8. FARM & LIVESTOCK ============ */}
          {modal === 'farm' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-slate-300 font-bold">اختر البذرة للزراعة:</span>
                {Object.values(CROPS).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCrop(c.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs border cursor-pointer ${
                      selectedCrop === c.id ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-slate-800 text-slate-200 border-slate-700'
                    }`}
                  >
                    {c.emoji} {c.name} ({c.seedPrice}🪙)
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-56 overflow-y-auto osw-scroll">
                {FARM_PARCELS.map((p) => {
                  const owned = state.ownedParcels.includes(p.id);
                  const plot = state.farmPlots[p.id];
                  const ready = plot && Date.now() >= plot.plantedAt + plot.growSec * 1000;
                  return (
                    <div key={p.id} className="bg-slate-800 border border-slate-700 rounded-lg p-2 text-center space-y-1">
                      <div className="text-[11px] font-mono-num text-slate-400">{p.id}</div>
                      {!owned ? (
                        <button
                          onClick={() => onDispatch('v15_parcel_buy', { parcelId: p.id })}
                          disabled={state.coins < p.price}
                          className="w-full py-1 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white text-[11px] font-bold cursor-pointer"
                        >
                          شراء {p.price}🪙
                        </button>
                      ) : !plot ? (
                        <button
                          onClick={() => onDispatch('plant', { plot: p.id, crop: selectedCrop })}
                          className="w-full py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] font-bold cursor-pointer"
                        >
                          ازرع 🌱
                        </button>
                      ) : (
                        <button
                          onClick={() => onDispatch('harvest', { plot: p.id })}
                          disabled={!ready}
                          className="w-full py-1 rounded bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 text-[11px] font-bold cursor-pointer"
                        >
                          {ready ? `اقطف ${CROPS[plot.cropId]?.emoji}` : 'ينمو ⏳'}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="border-t border-slate-800 pt-3">
                <h4 className="font-bold text-sm text-slate-200 mb-2">🐄 المواشي والرعاية البيطرية ({state.farmAnimals.length})</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {state.farmAnimals.map((a) => {
                    const def = FARM_ANIMALS.find((x) => x.id === a.kind);
                    if (!def) return null;
                    return (
                      <div key={a.id} className="bg-slate-800 border border-slate-700 rounded-lg p-2.5 flex items-center justify-between">
                        <span className="text-xs font-bold">{def.emoji} {def.name} (صحة {a.health}%)</span>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => onDispatch('v15_animal_care', { animalId: a.id })}
                            className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] cursor-pointer"
                          >
                            إطعام ورعاية (10🪙)
                          </button>
                          <button
                            onClick={() => onDispatch('v15_animal_collect', { animalId: a.id })}
                            className="px-2 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-bold cursor-pointer"
                          >
                            جمع {def.productEmoji}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ============ 9. 3D BUILDER & CITY PLANNER ============ */}
          {modal === 'builder' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                اختر تصميماً لوضعه بشبح ثلاثي الأبعاد مباشر على الخريطة (مع التحقق من الطرق والماء)، ثم أكمل مراحل البناء!
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {BUILDER_BLUEPRINTS.map((bp) => (
                  <div key={bp.id} className="bg-slate-800 border border-slate-700 rounded-xl p-3 space-y-2">
                    <div className="font-bold text-sm text-slate-100">{bp.emoji} {bp.name}</div>
                    <div className="text-[11px] text-slate-300">
                      سكان +{bp.popDelta} · وظائف +{bp.jobsDelta} · سعادة {bp.happyDelta >= 0 ? `+${bp.happyDelta}` : bp.happyDelta}
                    </div>
                    <button
                      onClick={() => {
                        onStartBuildGhost(bp.id);
                        onClose();
                      }}
                      disabled={state.coins < bp.cost}
                      className="w-full py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-bold cursor-pointer"
                    >
                      وضع شبح البناء ({bp.cost}🪙) 🏗️
                    </button>
                  </div>
                ))}
              </div>

              {state.placedBuildings.length > 0 && (
                <div className="space-y-2 border-t border-slate-800 pt-3">
                  <h4 className="font-bold text-sm text-slate-200">المباني قيد التشييد والمنفّذة ({state.placedBuildings.length})</h4>
                  {state.placedBuildings.map((b) => {
                    const bp = BUILDER_BLUEPRINTS.find((x) => x.id === b.blueprintId);
                    if (!bp) return null;
                    return (
                      <div key={b.uid} className="bg-slate-800 border border-slate-700 rounded-lg p-2.5 flex items-center justify-between">
                        <span className="text-xs">
                          {bp.emoji} {bp.name} — المرحلة <b className="text-amber-300">{b.stage}/{bp.stages}</b>
                        </span>
                        {b.stage < bp.stages ? (
                          <button
                            onClick={() => onDispatch('v15_build_advance', { uid: b.uid })}
                            className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
                          >
                            إكمال المرحلة التالية 🔨
                          </button>
                        ) : (
                          <span className="text-xs text-emerald-400 font-bold">✅ مكتمل</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ============ 10. TECH TREE ============ */}
          {modal === 'tech' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {TECH_TREE.map((t) => {
                const unlocked = state.techUnlocked.includes(t.id);
                const prereqMet = t.prereq.every((p) => state.techUnlocked.includes(p));
                return (
                  <div key={t.id} className="bg-slate-800 border border-slate-700 rounded-xl p-3.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-100">{t.emoji} {t.name}</span>
                      <span className="text-xs font-mono-num text-amber-300">{unlocked ? '✅ مفتوحة' : `${t.cost}🪙`}</span>
                    </div>
                    <p className="text-xs text-slate-300">{t.desc}</p>
                    {!unlocked && (
                      <button
                        onClick={() => onDispatch('v15_tech_unlock', { techId: t.id })}
                        disabled={!prereqMet || state.coins < t.cost}
                        className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                      >
                        {prereqMet ? 'تطوير التقنية الآن 🔬' : 'يتطلب فتح التقنية السابقة'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* ============ 11. ARCHAEOLOGY & MUSEUM ============ */}
          {modal === 'archaeology' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {DIG_SPOTS.map((d) => (
                  <div key={d.id} className="bg-slate-800 border border-slate-700 rounded-xl p-3 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-sm text-amber-300">⛏️ {d.name}</div>
                      <div className="text-xs text-slate-400">{d.hint}</div>
                    </div>
                    <button
                      onClick={() => {
                        onTeleport(d.x, d.z);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold cursor-pointer"
                    >
                      توجه للموقع
                    </button>
                  </div>
                ))}
              </div>
              <h4 className="font-bold text-sm text-slate-200">القطع الأثرية المكتشفة ({Object.keys(state.artifactsFound).length}/{ARTIFACTS.length})</h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {ARTIFACTS.map((a) => {
                  const qty = state.artifactsFound[a.id] || 0;
                  const exhibited = state.artifactsExhibited.includes(a.id);
                  return (
                    <div key={a.id} className="bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-center space-y-1">
                      <div className="text-2xl">{a.emoji}</div>
                      <div className="text-xs font-bold text-slate-100">{a.name}</div>
                      <div className="text-[11px] text-amber-300">+{a.dailyTourism}🪙/دقيقة سياحة</div>
                      {qty > 0 && !exhibited && (
                        <button
                          onClick={() => onDispatch('v15_exhibit', { artifactId: a.id })}
                          className="w-full py-1 rounded bg-emerald-600 text-white text-[11px] font-bold cursor-pointer"
                        >
                          عرض بالمتحف
                        </button>
                      )}
                      {exhibited && <div className="text-[11px] text-emerald-400 font-bold">🏛️ معروض</div>}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ============ 12. QUESTS ============ */}
          {modal === 'quests' && (
            <div className="space-y-3">
              {QUESTS.map((q) => {
                const done = state.questsCompleted.includes(q.id);
                return (
                  <div key={q.id} className="bg-slate-800 border border-slate-700 rounded-xl p-3.5 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-sm text-slate-100">
                        {done ? '✅' : '🎯'} {q.title}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">{q.hint}</p>
                      <div className="text-[11px] text-amber-400 mt-1">المكافأة: +{q.rewardCoins}🪙 · +{q.rewardXp} خبرة</div>
                    </div>
                    <button
                      onClick={() => {
                        onTeleport(q.targetX, q.targetZ);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shrink-0 cursor-pointer"
                    >
                      تتبع الموقع 📍
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* ============ 13. WARDROBE / FRIDGE / SHOP / POLICE / HOTEL / RESTO / METRICS ============ */}
          {modal === 'wardrobe' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {OUTFITS.map((o) => {
                  const owned = state.outfitsOwned.includes(o.id);
                  const active = profile.outfit === o.id;
                  return (
                    <div key={o.id} className="bg-slate-800 border border-slate-700 rounded-xl p-3 text-center space-y-2">
                      <div className="text-2xl">{o.emoji}</div>
                      <div className="text-xs font-bold text-slate-100">{o.name}</div>
                      {owned ? (
                        <button
                          onClick={() => onProfileChange({ outfit: o.id, color: o.color })}
                          className={`w-full py-1 rounded text-xs font-bold cursor-pointer ${
                            active ? 'bg-emerald-600 text-white' : 'bg-sky-600 text-white'
                          }`}
                        >
                          {active ? 'مُرتدى ✓' : 'ارتداء'}
                        </button>
                      ) : (
                        <button
                          onClick={() => onDispatch('v15_outfit_buy', { outfitId: o.id, price: o.price })}
                          disabled={state.coins < o.price}
                          className="w-full py-1 rounded bg-amber-500 disabled:opacity-40 text-slate-950 text-xs font-bold cursor-pointer"
                        >
                          شراء {o.price}🪙
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {modal === 'fridge' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                الشبع: {Math.round(state.hunger)}% · الارتواء: {Math.round(state.thirst)}% · الطاقة: {Math.round(state.energy)}%
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {[
                  { name: 'وجبة إفطار منزلية', food: 35, drink: 25, cost: 0 },
                  { name: 'سلطة طازجة من المزرعة', food: 28, drink: 18, cost: 8 },
                  { name: 'مقلوبة عائلية ساخنة', food: 65, drink: 20, cost: 16 },
                ].map((m) => (
                  <button
                    key={m.name}
                    onClick={() => onDispatch('v15_eat_meal', m)}
                    className="bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl p-3 text-right cursor-pointer"
                  >
                    <div className="font-bold text-xs text-slate-100">🍽️ {m.name}</div>
                    <div className="text-[11px] text-emerald-400 mt-1">+{m.food} شبع · +{m.drink} ماء</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {modal === 'shop' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {Object.entries(MATERIALS_META).map(([k, m]) => (
                <div key={k} className="bg-slate-800 border border-slate-700 rounded-lg p-2.5 flex items-center justify-between">
                  <span className="text-xs font-bold">
                    {m.emoji} {m.name} <span className="text-slate-400">(لديك: {state.inventory[k] || 0})</span>
                  </span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => onDispatch('v15_buy_mat', { item: k, qty: 2, unitPrice: m.basePrice })}
                      disabled={state.coins < m.basePrice * 2}
                      className="px-2.5 py-1 rounded bg-sky-600 disabled:opacity-40 text-white text-[11px] cursor-pointer"
                    >
                      شراء 2 ({m.basePrice * 2}🪙)
                    </button>
                    <button
                      onClick={() => onDispatch('v15_sell_item', { item: k, qty: 1, unitPrice: Math.round(m.basePrice * 0.9) })}
                      disabled={(state.inventory[k] || 0) < 1}
                      className="px-2.5 py-1 rounded bg-emerald-600 disabled:opacity-40 text-white text-[11px] cursor-pointer"
                    >
                      بيع 1
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {modal === 'police' && (
            <div className="space-y-3">
              <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-slate-100">المخالفات المرورية غير المسددة: {state.finesUnpaid}🪙</div>
                  <div className="text-xs text-slate-400 mt-1">اللصوص المقبوض عليهم: {state.thievesCaught} · مخالفات مسددة: {state.ticketsPaid}</div>
                </div>
                <button
                  onClick={() => onDispatch('v15_ticket_pay', {})}
                  disabled={state.finesUnpaid <= 0 || state.coins < state.finesUnpaid}
                  className="px-4 py-2 rounded-lg bg-emerald-600 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                >
                  سداد المخالفات الآن
                </button>
              </div>
            </div>
          )}

          {modal === 'restaurant' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { name: 'منسف ملكي', cost: 34, food: 70, drink: 15 },
                { name: 'مشاوي الديوان', cost: 28, food: 58, drink: 10 },
                { name: 'عصير ليمون بالنعنع', cost: 8, food: 5, drink: 45 },
              ].map((m) => (
                <button
                  key={m.name}
                  onClick={() => onDispatch('v15_eat_meal', m)}
                  disabled={state.coins < m.cost}
                  className="bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl p-3 text-right cursor-pointer"
                >
                  <div className="font-bold text-sm text-slate-100">{m.name}</div>
                  <div className="text-xs text-amber-300 mt-1">{m.cost}🪙</div>
                </button>
              ))}
            </div>
          )}

          {modal === 'hotel' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { name: 'غرفة قياسية', price: 40 },
                { name: 'غرفة عائلية', price: 65 },
                { name: 'الجناح الملكي', price: 110 },
              ].map((r) => (
                <button
                  key={r.name}
                  onClick={() => onDispatch('v15_hotel_book', { price: r.price })}
                  disabled={state.coins < r.price}
                  className="bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl p-3.5 text-right cursor-pointer"
                >
                  <div className="font-bold text-sm text-slate-100">🏨 {r.name}</div>
                  <div className="text-xs text-emerald-400 mt-1">استعادة الطاقة 100% · {r.price}🪙</div>
                </button>
              ))}
            </div>
          )}

          {modal === 'citymetrics' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">السكان</div><div className="text-xl font-bold font-mono-num">{state.cityMetrics.population}</div></div>
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">الرضا والسعادة</div><div className="text-xl font-bold font-mono-num text-emerald-400">{state.cityMetrics.happiness}%</div></div>
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">الوظائف</div><div className="text-xl font-bold font-mono-num text-sky-400">{state.cityMetrics.jobs}</div></div>
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">الكهرباء</div><div className="text-xl font-bold font-mono-num text-amber-300">{state.cityMetrics.powerUsed}/{state.cityMetrics.powerCapacity}</div></div>
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">المياه</div><div className="text-xl font-bold font-mono-num text-cyan-300">{state.cityMetrics.waterUsed}/{state.cityMetrics.waterCapacity}</div></div>
              <div className="bg-slate-800 p-3 rounded-xl"><div className="text-xs text-slate-400">التلوث</div><div className="text-xl font-bold font-mono-num text-rose-400">{state.cityMetrics.pollution}%</div></div>
            </div>
          )}

          {/* ============ 14. SETTINGS (GRAPHICS, WEATHER, TIME, AUDIO, SAVE/RESET) ============ */}
          {modal === 'settings' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 space-y-2.5">
                  <div className="font-bold text-sm text-amber-300">🎨 جودة الرسوم والطقس والوقت</div>
                  <div className="flex gap-1.5">
                    {(['low', 'medium', 'high', 'ultra'] as QualityPreset[]).map((q) => (
                      <button
                        key={q}
                        onClick={() => onQualityChange(q)}
                        className={`flex-1 py-1 rounded text-xs font-bold cursor-pointer ${
                          quality === q ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300'
                        }`}
                      >
                        {q === 'low' ? 'منخفضة' : q === 'medium' ? 'متوسطة' : q === 'high' ? 'عالية' : 'فائقة'}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onWeatherChange('clear')}
                      className={`flex-1 py-1.5 rounded text-xs font-bold cursor-pointer ${weather === 'clear' ? 'bg-sky-600 text-white' : 'bg-slate-900 text-slate-300'}`}
                    >
                      ☀️ صحو
                    </button>
                    <button
                      onClick={() => onWeatherChange('rain')}
                      className={`flex-1 py-1.5 rounded text-xs font-bold cursor-pointer ${weather === 'rain' ? 'bg-sky-600 text-white' : 'bg-slate-900 text-slate-300'}`}
                    >
                      🌧️ ممطر
                    </button>
                  </div>
                  <div className="text-xs text-slate-300">
                    ساعة العالم: <b className="font-mono-num">{Math.floor(gameHour)}:00</b>
                    <input
                      type="range"
                      min={0}
                      max={23}
                      value={Math.floor(gameHour)}
                      onChange={(e) => onHourChange(Number(e.target.value))}
                      className="w-full mt-1"
                    />
                  </div>
                </div>

                <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-amber-300">🔊 الصوت والمؤثرات</span>
                    <button
                      onClick={() => updateAudio({ muted: !audioCfg.muted })}
                      className="px-2.5 py-1 rounded bg-slate-900 text-xs text-slate-200 cursor-pointer"
                    >
                      {audioCfg.muted ? '🔇 صامت' : '🔊 شغّال'}
                    </button>
                  </div>
                  {[
                    { k: 'master' as const, label: 'الصوت العام' },
                    { k: 'sfx' as const, label: 'المؤثرات' },
                    { k: 'ambient' as const, label: 'البيئة' },
                    { k: 'music' as const, label: 'الموسيقى' },
                  ].map((s) => (
                    <div key={s.k} className="flex items-center gap-2 text-xs">
                      <span className="w-20 text-slate-300">{s.label}</span>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={audioCfg[s.k]}
                        onChange={(e) => updateAudio({ [s.k]: Number(e.target.value) })}
                        className="flex-1"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Save Export / Import / Reset */}
              <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 space-y-2.5">
                <div className="font-bold text-sm text-slate-100">💾 إدارة الحفظ (متوافق مع V14 osw_demo_v1)</div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setExportPreview(onExportSave())}
                    className="px-3 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold cursor-pointer"
                  >
                    تصدير نسخة الحفظ JSON 📤
                  </button>
                  <button
                    onClick={() => {
                      if (importText.trim()) onImportSave(importText.trim());
                    }}
                    className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
                  >
                    استيراد JSON 📥
                  </button>
                  <button
                    onClick={onResetSave}
                    className="px-3 py-1.5 rounded bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold cursor-pointer"
                  >
                    إعادة ضبط الحفظ 🗑️
                  </button>
                </div>
                {exportPreview && (
                  <textarea
                    readOnly
                    value={exportPreview}
                    rows={3}
                    className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-[11px] font-mono-num text-slate-300"
                  />
                )}
                <textarea
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="ألصق هنا بيانات الحفظ JSON للاستيراد..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-[11px] font-mono-num text-slate-300"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
