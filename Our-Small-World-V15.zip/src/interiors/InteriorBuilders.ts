import * as THREE from 'three';
import { ARTIFACTS, VEHICLES } from '../data/catalog';
import { SITES } from '../data/islandsData';
import { GameState } from '../data/storage';
import { buildVehicleMesh } from '../entities/VehicleSystem';
import { SpatialCollisionWorld } from '../engine/CollisionSystem';
import { getMarbleFloorTexture, getStoneTexture, makeSignTexture, updateTickerCanvas } from '../engine/Textures';
import { addBox, addCyl, createSignBoard, getMat, InteractiveZone } from '../world/MeshHelpers';

export interface InteriorSceneData {
  id: string;
  title: string;
  emoji: string;
  hw: number;
  hd: number;
  spawnX: number;
  spawnZ: number;
  exitX: number;
  exitZ: number;
  group: THREE.Group;
  zones: InteractiveZone[];
  tickerCanvas?: HTMLCanvasElement;
  tickerTexture?: THREE.CanvasTexture;
}

const INTERIOR_OFFSET_X = 2400;

export class InteriorManager {
  public activeInterior: InteriorSceneData | null = null;
  public collision = new SpatialCollisionWorld();
  private container = new THREE.Group();
  public currentHqFloor = 0;

  constructor(scene: THREE.Scene) {
    this.container.name = 'OSW_Interior_Root';
    scene.add(this.container);
  }

  public exitInterior(): { x: number; z: number } | null {
    if (!this.activeInterior) return null;
    const ret = { x: this.activeInterior.exitX, z: this.activeInterior.exitZ };
    this.container.remove(this.activeInterior.group);
    this.collision.clear();
    this.activeInterior = null;
    return ret;
  }

  public enterInterior(id: string, state: GameState, hqFloor = 0): InteriorSceneData {
    this.exitInterior();
    this.currentHqFloor = hqFloor;
    this.collision.clear();

    const site = SITES.find((s) => s.interiorId === id);
    const exitX = site ? site.frontX : 0;
    const exitZ = site ? site.frontZ : -19;

    const g = new THREE.Group();
    g.position.set(INTERIOR_OFFSET_X, 0, 0);
    const zones: InteractiveZone[] = [];

    let hw = 14;
    let hd = 11;
    let title = site?.name || 'مبنى داخلي';
    let emoji = site?.emoji || '🏛️';
    let floorColor = '#efe7d6';
    let wallColor = '#f8f2e4';

    if (id === 'home_ground') {
      hw = 15;
      hd = 11;
      title = 'القصر العائلي — الطابق الأرضي';
      emoji = '🏰';
    } else if (id === 'home_upper') {
      hw = 14;
      hd = 10;
      title = 'القصر العائلي — الطابق الثاني والغرف';
      emoji = '🛏️';
    } else if (id === 'ind_glass') {
      hw = 20;
      hd = 14;
      title = 'مصنع النور لصناعة الزجاج';
      emoji = '🪟';
      floorColor = '#cbd5e1';
      wallColor = '#e2e8f0';
    } else if (id.startsWith('ind_')) {
      hw = 16;
      hd = 12;
      floorColor = '#cbd5e1';
      wallColor = '#e2e8f0';
    } else if (id === 'biz_exchange') {
      hw = 18;
      hd = 13;
      floorColor = '#e5dcc8';
      wallColor = '#f4efe2';
    } else if (id === 'biz_hq') {
      hw = 14;
      hd = 11;
      const flNames = ['الاستقبال (الأرضي)', 'الموارد البشرية (ط1)', 'المالية والتسويق (ط2)', 'المدير التنفيذي (ط3)', 'مختبر التطوير (ط4)', 'السطح والمهبط (ط5)'];
      title = `برج الإدارة — ${flNames[hqFloor] || flNames[0]}`;
    } else if (id === 'life_temple') {
      hw = 16;
      hd = 13;
      floorColor = '#c9b48d';
      wallColor = '#b3986c';
    }

    // Build Room Shell (Floor + Walls + Exit Doorway)
    const marble = getMarbleFloorTexture();
    const stone = getStoneTexture(wallColor, 3);
    addBox(g, 0, -0.2, 0, hw * 2, 0.2, hd * 2, floorColor, { map: id.startsWith('ind_') ? undefined : marble, roughness: 0.65 });
    // North, West, East Walls
    addBox(g, 0, 0, -hd, hw * 2, 4.2, 0.4, wallColor, { map: stone });
    addBox(g, -hw, 0, 0, 0.4, 4.2, hd * 2, wallColor, { map: stone });
    addBox(g, hw, 0, 0, 0.4, 4.2, hd * 2, wallColor, { map: stone });
    // South wall with wide exit opening at x=0
    addBox(g, -(hw / 2 + 1.1), 0, hd, hw - 2.2, 4.2, 0.4, wallColor);
    addBox(g, hw / 2 + 1.1, 0, hd, hw - 2.2, 4.2, 0.4, wallColor);
    addBox(g, 0, 0.02, hd - 1.2, 3.6, 0.03, 1.4, '#b45309');

    // Perimeter collision walls inside interior
    this.collision.addBox('int_n', INTERIOR_OFFSET_X, -hd, hw * 2, 0.8);
    this.collision.addBox('int_w', INTERIOR_OFFSET_X - hw, 0, 0.8, hd * 2);
    this.collision.addBox('int_e', INTERIOR_OFFSET_X + hw, 0, 0.8, hd * 2);
    this.collision.addBox('int_sw', INTERIOR_OFFSET_X - (hw / 2 + 1.1), hd, hw - 2.2, 0.8);
    this.collision.addBox('int_se', INTERIOR_OFFSET_X + (hw / 2 + 1.1), hd, hw - 2.2, 0.8);

    // Exit Zone at South Doorway (except home_upper exits down stairs!)
    if (id !== 'home_upper') {
      zones.push({
        id: 'int_exit',
        label: 'الخروج إلى العالم الخارجي',
        emoji: '🚪',
        x: INTERIOR_OFFSET_X,
        z: hd - 1.2,
        radius: 3.2,
        action: 'exit_interior',
      });
    }

    let tickerCanvas: HTMLCanvasElement | undefined;
    let tickerTexture: THREE.CanvasTexture | undefined;

    // ============ SPECIFIC BESPOKE INTERIORS ============
    if (id === 'home_ground') {
      // Living Room (West side): L-sofa, coffee table, glowing OLED TV, rug
      addBox(g, -7, 0.02, -3, 7, 0.03, 5, '#991b1b');
      addBox(g, -7, 0, -0.5, 5.5, 0.85, 1.4, '#7f1d1d');
      addBox(g, -10.5, 0, -3, 1.4, 0.85, 4.2, '#7f1d1d');
      addBox(g, -7, 0, -3, 2.4, 0.45, 1.4, '#cbd5e1');
      // TV console + screen on North wall
      addBox(g, -7, 0, -9.8, 4.2, 0.7, 0.9, '#5c3a21');
      addBox(g, -7, 1.1, -9.9, 3.2, 1.8, 0.12, '#0ea5e9', { emissive: '#38bdf8', emissiveIntensity: 0.45 });
      this.collision.addBox('hg_sofa', INTERIOR_OFFSET_X - 7, -0.5, 5.6, 1.5);

      // Kitchen & Dining (East side) + Openable Fridge!
      addBox(g, 8, 0, -9.4, 9, 1.0, 1.5, '#e2e8f0');
      addBox(g, 13.2, 0, -6.5, 1.4, 2.4, 1.5, '#f8fafc', { metalness: 0.25 }); // Fridge!
      createSignBoard(g, makeSignTexture('🧊 الثلاجة', '#0369a1', '#ffffff'), 13.2, 2.9, -5.6, 2.2, 0.55);
      zones.push({ id: 'hg_fridge', label: 'فتح الثلاجة والطبخ', emoji: '🧊', x: INTERIOR_OFFSET_X + 12.2, z: -4.8, radius: 3.2, action: 'open:fridge' });

      // Dining Table
      addBox(g, 7, 0, -2, 4.2, 0.85, 2.4, '#78350f');
      this.collision.addBox('hg_table', INTERIOR_OFFSET_X + 7, -2, 4.4, 2.6);

      // Guest Bathroom partition (SW corner)
      addBox(g, -11, 0, 5.5, 5, 3.2, 0.3, '#cbd5e1');
      addBox(g, -8.5, 0, 7.5, 0.3, 3.2, 4, '#cbd5e1');
      addBox(g, -12.5, 0, 8.5, 1.8, 0.6, 3.2, '#f8fafc');

      // Grand Staircase to 2nd Floor (NE corner)
      for (let st = 0; st < 8; st++) {
        addBox(g, 1.5, st * 0.38, -4.5 - st * 0.65, 3.4, 0.38, 0.7, '#b45309');
      }
      createSignBoard(g, makeSignTexture('⬆️ للطابق الثاني (غرف النوم)', '#1e293b', '#fbbf24'), 1.5, 3.5, -9.4, 4.4, 0.75);
      zones.push({ id: 'hg_stairs_up', label: 'صعود الدرج إلى الطابق الثاني', emoji: '⬆️', x: INTERIOR_OFFSET_X + 1.5, z: -4.2, radius: 3.2, action: 'enter:home_upper' });
    } else if (id === 'home_upper') {
      // Master Bed
      addBox(g, -7, 0, -6.5, 4.6, 0.65, 4.0, '#7c2d12');
      addBox(g, -7, 0.65, -6.5, 4.3, 0.35, 3.7, '#f8fafc');
      addBox(g, -7, 0.9, -5.2, 4.3, 0.15, 1.6, '#be123c');
      this.collision.addBox('hu_bed', INTERIOR_OFFSET_X - 7, -6.5, 4.8, 4.2);
      zones.push({ id: 'hu_sleep', label: 'النوم في السرير (استعادة الطاقة 100%)', emoji: '🛏️', x: INTERIOR_OFFSET_X - 7, z: -3.8, radius: 3.4, action: 'action:sleep' });

      // Dressing Room with ONE proper Wardrobe & Mirror! (Not scattered outside!)
      addBox(g, 8.5, 0, -7.8, 5.5, 2.8, 1.3, '#5c3a21');
      addBox(g, 8.5, 0.4, -7.1, 2.2, 2.1, 0.08, '#bae6fd', { metalness: 0.7, roughness: 0.08 });
      createSignBoard(g, makeSignTexture('🪞 غرفة الملابس والمرآة', '#7c2d12', '#fef3c7'), 8.5, 3.2, -7.0, 4.0, 0.65);
      this.collision.addBox('hu_wardrobe', INTERIOR_OFFSET_X + 8.5, -7.8, 5.6, 1.5);
      zones.push({ id: 'hu_wardrobe_z', label: 'فتح خزانة الملابس والأزياء', emoji: '👗', x: INTERIOR_OFFSET_X + 8.5, z: -5.5, radius: 3.4, action: 'open:wardrobe' });

      // Balcony overlook on South edge
      addBox(g, 0, 0, hd - 0.5, 12, 1.1, 0.2, '#7dd3fc', { transparent: true, opacity: 0.5 });
      zones.push({ id: 'hu_stairs_down', label: 'نزول الدرج للطابق الأرضي', emoji: '⬇️', x: INTERIOR_OFFSET_X, z: hd - 2.2, radius: 3.5, action: 'enter:home_ground' });
    } else if (id === 'ind_glass') {
      // AL-NOOR GLASS FACTORY GOLD-STANDARD INTERIOR!
      // 1. Reception & Engineer Office (SW / NW)
      addBox(g, -14, 0, 8, 6, 1.0, 1.4, '#0369a1');
      createSignBoard(g, makeSignTexture('لوحة تحكم مصنع النور 🪟', '#0f172a', '#38bdf8'), -14, 2.8, 7.4, 4.8, 0.8);
      zones.push({ id: 'ind_glass_ctrl', label: 'غرفة التحكم والإنتاج (تشغيل/ترقية/عمال)', emoji: '🏭', x: INTERIOR_OFFSET_X - 13, z: 6.2, radius: 3.8, action: 'open:factory:glass' });

      // 2. Raw Silica Sand Storage (NW)
      addBox(g, -14, 0, -8, 6, 1.6, 5, '#eab308');
      createSignBoard(g, makeSignTexture('مخزن رمل السيليكا الخام 🏜️', '#78350f', '#fde68a'), -14, 3.0, -5.5, 5.2, 0.7);
      this.collision.addBox('ig_raw', INTERIOR_OFFSET_X - 14, -8, 6.2, 5.2);

      // 3. Automated Mixer + Twin Glowing Melting Furnaces (1500C)
      [-5, 1].forEach((fx, idx) => {
        addBox(g, fx, 0, -8, 4.8, 3.6, 4.4, '#334155');
        addBox(g, fx, 0.8, -5.75, 2.8, 1.8, 0.15, '#f97316', { emissive: '#ea580c', emissiveIntensity: 1.4 });
        createSignBoard(g, makeSignTexture(`فرن الصهر #${idx + 1} (1500°م) 🔥`, '#7c2d12', '#fde047'), fx, 4.2, -5.6, 4.2, 0.7);
        this.collision.addBox(`ig_furn_${idx}`, INTERIOR_OFFSET_X + fx, -8, 5, 4.6);
      });

      // 4. Rolling Forming Line + Annealing Cooling Tunnel (Center Conveyor)
      addBox(g, 2, 0, -1, 18, 0.9, 2.6, '#475569');
      addBox(g, 2, 0.95, -1, 16, 0.12, 1.8, '#38bdf8', { transparent: true, opacity: 0.75 });
      addBox(g, 7, 0.9, -1, 6, 1.4, 2.8, '#0284c7'); // Cooling tunnel hood
      createSignBoard(g, makeSignTexture('خط التشكيل والتلدين والتبريد ❄️', '#0369a1', '#ffffff'), 2, 3.1, -1, 6.4, 0.75);
      this.collision.addBox('ig_conv', INTERIOR_OFFSET_X + 2, -1, 18.2, 2.8);

      // 5. Quality Control Lab & Packing + Finished Glass Warehouse (East)
      addBox(g, 14, 0, 5, 6, 1.1, 4, '#10b981');
      addBox(g, 14, 0, -6, 6, 2.2, 4.5, '#bae6fd', { transparent: true, opacity: 0.8 });
      createSignBoard(g, makeSignTexture('فحص الجودة ومخزن الزجاج الجاهز 📦', '#065f46', '#ecfdf5'), 14, 3.2, -3.5, 5.5, 0.75);
      this.collision.addBox('ig_qc', INTERIOR_OFFSET_X + 14, 5, 6.2, 4.2);
      this.collision.addBox('ig_fin', INTERIOR_OFFSET_X + 14, -6, 6.2, 4.6);
      zones.push({ id: 'ind_glass_line', label: 'تشغيل خط تصنيع الزجاج', emoji: '🔥', x: INTERIOR_OFFSET_X + 2, z: 2.8, radius: 4.5, action: 'open:factory:glass' });
    } else if (id.startsWith('ind_') && id !== 'ind_garage') {
      const fKey = id.replace('ind_', '');
      const fMap: Record<string, string> = {
        steel: 'steel',
        wood: 'wood',
        pottery: 'pottery',
        textile: 'textile',
        food: 'food',
        elec: 'electronics',
      };
      const fid = fMap[fKey] || 'steel';
      addBox(g, -6, 0, -5, 6, 3.0, 4, '#475569');
      addBox(g, 4, 0, -2, 10, 1.1, 2.6, '#64748b');
      addBox(g, 0, 0, 4, 7, 1.0, 1.5, '#0f172a');
      createSignBoard(g, makeSignTexture(`غرفة تحكم ${title}`, '#0f172a', '#fbbf24'), 0, 3.0, 4, 6.5, 0.8);
      this.collision.addBox('ind_mach', INTERIOR_OFFSET_X - 6, -5, 6.2, 4.2);
      zones.push({ id: 'ind_ctrl', label: `إدارة وتشغيل ${title}`, emoji, x: INTERIOR_OFFSET_X, z: 6.2, radius: 4.2, action: `open:factory:${fid}` });
    } else if (id === 'ind_garage') {
      // Repair Pit & Hydraulic Lift
      addBox(g, 0, 0.05, -2, 6, 0.15, 9, '#334155');
      [-3.4, 3.4].forEach((lx) => addBox(g, lx, 0, -2, 0.5, 3.2, 0.5, '#f97316'));
      addBox(g, -10, 0, -6, 5, 1.2, 2, '#ea580c');
      zones.push({ id: 'gar_rep', label: 'تصليح وتطوير المركبات', emoji: '🔧', x: INTERIOR_OFFSET_X, z: 4, radius: 4.5, action: 'open:garage' });
    } else if (id === 'biz_exchange') {
      // Live 3D Ticker Canvas Board!
      tickerCanvas = document.createElement('canvas');
      tickerCanvas.width = 768;
      tickerCanvas.height = 280;
      updateTickerCanvas(
        tickerCanvas,
        Object.keys(state.stockPrices).map((tk) => ({
          ticker: tk,
          price: state.stockPrices[tk],
          changePct: 2.4,
        }))
      );
      tickerTexture = new THREE.CanvasTexture(tickerCanvas);
      tickerTexture.colorSpace = THREE.SRGBColorSpace;
      const board = new THREE.Mesh(
        new THREE.BoxGeometry(16, 4.2, 0.25),
        new THREE.MeshStandardMaterial({ map: tickerTexture, emissive: '#1e293b', emissiveIntensity: 0.35 })
      );
      board.position.set(0, 2.8, -hd + 0.4);
      g.add(board);

      // Broker trading desks
      [-8, 0, 8].forEach((dx) => {
        addBox(g, dx, 0, -3, 4.2, 1.0, 1.6, '#1e3a5f');
        this.collision.addBox(`ex_d_${dx}`, INTERIOR_OFFSET_X + dx, -3, 4.4, 1.8);
      });
      zones.push({ id: 'ex_trade', label: 'منصة التداول وشراء الأسهم', emoji: '📈', x: INTERIOR_OFFSET_X, z: 0, radius: 5.5, action: 'open:exchange' });
    } else if (id === 'biz_bank') {
      // Teller counters + Vault door
      addBox(g, -4, 0, -4, 12, 1.1, 1.6, '#78350f');
      addBox(g, 9, 0, -8, 4.4, 3.4, 2.2, '#475569', { metalness: 0.85, roughness: 0.25 }); // Vault!
      addBox(g, 9, 0.2, -5.5, 2.2, 1.0, 1.2, '#fbbf24', { metalness: 0.8 }); // Gold bars
      this.collision.addBox('bk_desk', INTERIOR_OFFSET_X - 4, -4, 12.2, 1.8);
      zones.push({ id: 'bk_open', label: 'خدمات البنك (إيداع، سحب، قروض)', emoji: '🏦', x: INTERIOR_OFFSET_X - 2, z: -1, radius: 4.5, action: 'open:bank' });
    } else if (id === 'biz_hq') {
      // 5-Floor HQ with working Elevator!
      addBox(g, 10, 0, -5, 3.5, 3.4, 3.5, '#64748b', { metalness: 0.6 });
      createSignBoard(g, makeSignTexture('🛗 مصعد الطوابق (0-5)', '#0f172a', '#fbbf24'), 10, 3.6, -3.1, 3.8, 0.7);
      addBox(g, -2, 0, -5, 8, 1.0, 2.2, '#1e3a5f');
      this.collision.addBox('hq_desk', INTERIOR_OFFSET_X - 2, -5, 8.2, 2.4);
      zones.push({ id: 'hq_elev', label: `تشغيل المصعد (الطابق الحالي: ${hqFloor})`, emoji: '🛗', x: INTERIOR_OFFSET_X + 8.5, z: -2.2, radius: 3.4, action: 'open:elevator' });
      zones.push({ id: 'hq_mgmt', label: 'إدارة الشركة والمشاريع', emoji: '🏢', x: INTERIOR_OFFSET_X - 2, z: -2.2, radius: 4.0, action: 'open:company' });
    } else if (id === 'biz_dealer') {
      // Showroom floor with 3 real 3D display cars!
      const showDefs = [VEHICLES.super, VEHICLES.ev_sedan, VEHICLES.suv];
      showDefs.forEach((vd, idx) => {
        const sx = -8 + idx * 8;
        addCyl(g, sx, 0, -4, 3.2, 3.4, 0.2, '#cbd5e1', 16);
        const cm = buildVehicleMesh(vd, vd.defaultColor);
        cm.group.position.set(sx, 0.2, -4);
        cm.group.rotation.y = 0.4;
        g.add(cm.group);
        this.collision.addCircle(`dl_car_${idx}`, INTERIOR_OFFSET_X + sx, -4, 3.3);
      });
      zones.push({ id: 'dl_buy', label: 'شراء وتجربة السيارات (28 مركبة)', emoji: '🚘', x: INTERIOR_OFFSET_X, z: 2.5, radius: 5.0, action: 'open:dealership' });
    } else if (id === 'saadoun_shop' || id === 'city_mall' || id === 'port_market') {
      addBox(g, -6, 0, -4, 5, 1.1, 1.8, '#b45309');
      addBox(g, 6, 0, -4, 5, 1.1, 1.8, '#0284c7');
      this.collision.addBox('sh_c1', INTERIOR_OFFSET_X - 6, -4, 5.2, 2);
      this.collision.addBox('sh_c2', INTERIOR_OFFSET_X + 6, -4, 5.2, 2);
      zones.push({ id: 'sh_buy', label: 'التسوق والبيع والشراء', emoji: '🛒', x: INTERIOR_OFFSET_X, z: 0, radius: 5.5, action: 'open:shop' });
    } else if (id === 'port_customs' || id === 'port_warehouse') {
      addBox(g, -6, 0, -5, 5, 2.2, 3, '#d97706');
      addBox(g, 6, 0, -5, 6, 1.1, 2, '#1e3a5f');
      zones.push({ id: 'prt_open', label: 'منصة الجمارك والتصدير البحري', emoji: '🚢', x: INTERIOR_OFFSET_X, z: 0, radius: 5.5, action: 'open:port' });
    } else if (id === 'agri_vet') {
      addBox(g, 0, 0, -5, 6, 1.1, 2, '#15803d');
      zones.push({ id: 'vet_open', label: 'رعاية الحيوانات والعيادة البيطرية', emoji: '🐄', x: INTERIOR_OFFSET_X, z: -1, radius: 4.5, action: 'open:farm' });
    } else if (id === 'city_hospital') {
      [-7, 7].forEach((bx) => {
        addBox(g, bx, 0, -5, 2.4, 0.7, 4.2, '#f8fafc');
        this.collision.addBox(`hs_b_${bx}`, INTERIOR_OFFSET_X + bx, -5, 2.5, 4.4);
      });
      addBox(g, 0, 0, -7, 6, 1.1, 1.6, '#ef4444');
      zones.push({ id: 'hosp_heal', label: 'علاج وفحص طبي شامل (25🪙)', emoji: '🩺', x: INTERIOR_OFFSET_X, z: -3, radius: 4.5, action: 'action:heal' });
    } else if (id === 'city_police') {
      addBox(g, 0, 0, -5, 7, 1.1, 1.6, '#1e3a8a');
      // Holding cell bars
      for (let i = -3; i <= 3; i += 1.2) addBox(g, i, 0, -8.5, 0.1, 3.0, 0.1, '#64748b');
      zones.push({ id: 'pol_open', label: 'مكتب المخالفات والأمن', emoji: '👮', x: INTERIOR_OFFSET_X, z: -1.5, radius: 4.5, action: 'open:police' });
    } else if (id === 'city_resto') {
      [[-6, -2], [6, -2], [0, 3]].forEach(([tx, tz]) => {
        addBox(g, tx, 0, tz, 2.4, 0.85, 2.4, '#78350f');
        this.collision.addBox(`rst_${tx}_${tz}`, INTERIOR_OFFSET_X + tx, tz, 2.6, 2.6);
      });
      addBox(g, 0, 0, -7.5, 8, 1.1, 1.6, '#c2410c');
      zones.push({ id: 'rst_eat', label: 'طلب وجبة من النادل', emoji: '🍽️', x: INTERIOR_OFFSET_X, z: -4, radius: 4.5, action: 'open:restaurant' });
    } else if (id === 'city_hotel') {
      addBox(g, 0, 0, -6, 8, 1.1, 1.6, '#92400e');
      addBox(g, -8, 0, -3, 3.6, 0.7, 3.6, '#f8fafc');
      zones.push({ id: 'htl_book', label: 'حجز جناح فندقي والراحة', emoji: '🏨', x: INTERIOR_OFFSET_X, z: -2.5, radius: 4.5, action: 'open:hotel' });
    } else if (id === 'city_museum') {
      // Display 3D pedestals for player's exhibited artifacts!
      addBox(g, 0, 0, -8, 8, 1.0, 1.6, '#92400e');
      state.artifactsExhibited.slice(0, 6).forEach((artId, idx) => {
        const art = ARTIFACTS.find((x) => x.id === artId);
        if (!art) return;
        const px = -9 + idx * 3.6;
        addCyl(g, px, 0, -2, 0.6, 0.7, 1.1, '#e2d5b5', 10);
        addBox(g, px, 1.25, -2, 0.7, 0.7, 0.7, art.color, { emissive: art.color, emissiveIntensity: 0.3 });
      });
      zones.push({ id: 'mus_open', label: 'إدارة المتحف والقطع الأثرية', emoji: '🏺', x: INTERIOR_OFFSET_X, z: 2.5, radius: 5.0, action: 'open:archaeology' });
    } else if (id === 'city_palace') {
      addBox(g, 0, 0, -7, 7, 0.5, 4, '#fbbf24');
      addBox(g, 0, 0.5, -8, 2, 1.8, 1.5, '#7f1d1d');
      zones.push({ id: 'pal_open', label: 'مجلس المدينة والمخطط العمراني', emoji: '👑', x: INTERIOR_OFFSET_X, z: -2, radius: 5.0, action: 'open:citymetrics' });
    } else if (id === 'life_uni' || id === 'life_lib') {
      [-7, 7].forEach((bx) => addBox(g, bx, 0, -5, 4, 2.8, 1.2, '#78350f'));
      zones.push({ id: 'tech_open', label: 'مركز الأبحاث والتكنولوجيا', emoji: '🔬', x: INTERIOR_OFFSET_X, z: -1, radius: 5.0, action: 'open:tech' });
    } else if (id === 'life_temple') {
      // Ancient Sun Temple + Secret Chamber!
      [-7, 7].forEach((cx) => {
        [-5, 1].forEach((cz) => {
          addCyl(g, cx, 0, cz, 0.7, 0.85, 4.0, '#d6c3a1', 12);
          this.collision.addCircle(`tmp_c_${cx}_${cz}`, INTERIOR_OFFSET_X + cx, cz, 0.9);
        });
      });
      // Golden Altar & Secret Relic
      addBox(g, 0, 0, -8, 4.5, 1.2, 2.6, '#b45309');
      addBox(g, 0, 1.3, -8, 1.0, 1.0, 1.0, '#fbbf24', { emissive: '#f59e0b', emissiveIntensity: 0.7 });
      zones.push({ id: 'tmp_dig', label: 'استكشاف الغرفة السرية والتنقيب', emoji: '🏛️', x: INTERIOR_OFFSET_X, z: -4.5, radius: 4.5, action: 'dig:dig_temple_inner' });
    }

    this.container.add(g);
    this.activeInterior = {
      id,
      title,
      emoji,
      hw,
      hd,
      spawnX: INTERIOR_OFFSET_X,
      spawnZ: hd - 3.5,
      exitX,
      exitZ,
      group: g,
      zones,
      tickerCanvas,
      tickerTexture,
    };
    return this.activeInterior;
  }

  public refreshExchangeBoard(state: GameState): void {
    if (!this.activeInterior?.tickerCanvas || !this.activeInterior?.tickerTexture) return;
    const rows = Object.keys(state.stockPrices).map((tk) => {
      const hist = state.stockHistory[tk] || [];
      const cur = state.stockPrices[tk];
      const prev = hist[hist.length - 2] || cur;
      const pct = prev > 0 ? ((cur - prev) / prev) * 100 : 0;
      return { ticker: tk, price: cur, changePct: pct };
    });
    updateTickerCanvas(this.activeInterior.tickerCanvas, rows);
    this.activeInterior.tickerTexture.needsUpdate = true;
  }
}
