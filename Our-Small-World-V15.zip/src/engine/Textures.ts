import * as THREE from 'three';

const cache = new Map<string, THREE.CanvasTexture>();

export function makeProceduralTexture(
  key: string,
  size: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const fullKey = `${key}_${size}_${repeatX}_${repeatY}`;
  const existing = cache.get(fullKey);
  if (existing) return existing;

  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    draw(ctx, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.needsUpdate = true;
  cache.set(fullKey, tex);
  return tex;
}

export function getAsphaltTexture(): THREE.CanvasTexture {
  return makeProceduralTexture(
    'asphalt_v2',
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#292d34';
      ctx.fillRect(0, 0, w, h);
      // Tire track wear bands
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(w * 0.18, 0, w * 0.22, h);
      ctx.fillRect(w * 0.6, 0, w * 0.22, h);
      for (let i = 0; i < 2400; i++) {
        const x = (i * 73) % w;
        const y = (i * 137) % h;
        ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.12)';
        ctx.fillRect(x, y, 2, 2);
      }
      // Sidewalk/road shoulder edge stripes
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(5, 0, 5, h);
      ctx.fillRect(w - 10, 0, 5, h);
      // Dashed gold centerline
      ctx.fillStyle = '#fbbf24';
      for (let y = 10; y < h; y += 44) {
        ctx.fillRect(w / 2 - 3, y, 6, 24);
      }
    },
    1,
    12
  );
}

export function getStoneTexture(baseHex = '#dcd0b8', repeat = 4): THREE.CanvasTexture {
  return makeProceduralTexture(
    `stone_v2_${baseHex}`,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, w, h);
      const rows = 8;
      const rh = h / rows;
      for (let r = 0; r < rows; r++) {
        const y = r * rh;
        const off = (r % 2) * 32;
        for (let x = -32; x < w + 32; x += 64) {
          const shade = ((r * 7 + x) % 3) - 1;
          ctx.fillStyle = shade > 0 ? 'rgba(255,255,255,0.06)' : shade < 0 ? 'rgba(40,30,15,0.06)' : 'rgba(0,0,0,0)';
          ctx.fillRect(x + off + 2, y + 2, 60, rh - 4);
        }
        ctx.strokeStyle = 'rgba(55, 42, 26, 0.24)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
        for (let x = off; x < w; x += 64) {
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(x, y + rh);
          ctx.stroke();
        }
      }
    },
    repeat,
    repeat
  );
}

export function getCobblestoneTexture(baseHex = '#b8ab96', repeat = 10): THREE.CanvasTexture {
  return makeProceduralTexture(
    `cobble_${baseHex}`,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#706557';
      ctx.fillRect(0, 0, w, h);
      const cw = 32;
      const ch = 24;
      for (let row = 0; row < h / ch + 1; row++) {
        const off = (row % 2) * (cw / 2);
        for (let col = -1; col < w / cw + 1; col++) {
          const x = col * cw + off;
          const y = row * ch;
          const v = ((row * 13 + col * 29) % 5) - 2;
          ctx.fillStyle = baseHex;
          ctx.fillRect(x + 2, y + 2, cw - 4, ch - 4);
          if (v !== 0) {
            ctx.fillStyle = v > 0 ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.12)';
            ctx.fillRect(x + 2, y + 2, cw - 4, ch - 4);
          }
          ctx.fillStyle = 'rgba(255,255,255,0.15)';
          ctx.fillRect(x + 3, y + 2, cw - 6, 3);
        }
      }
    },
    repeat,
    repeat
  );
}

export function getRoofTileTexture(baseHex = '#9a3412', repeat = 6): THREE.CanvasTexture {
  return makeProceduralTexture(
    `rooftile_${baseHex}`,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, w, h);
      const rows = 8;
      const rh = h / rows;
      for (let r = 0; r < rows; r++) {
        const y = r * rh;
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        ctx.fillRect(0, y + rh - 4, w, 4);
        ctx.fillStyle = 'rgba(255,255,255,0.1)';
        ctx.fillRect(0, y + 2, w, 3);
        for (let x = (r % 2) * 16; x < w; x += 32) {
          ctx.fillStyle = 'rgba(0,0,0,0.14)';
          ctx.fillRect(x, y, 2, rh);
        }
      }
    },
    repeat,
    repeat
  );
}

export function getGrassTexture(baseHex = '#589a50', repeat = 14): THREE.CanvasTexture {
  return makeProceduralTexture(
    `grass_v2_${baseHex}`,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = baseHex;
      ctx.fillRect(0, 0, w, h);
      // Soft mowed lawn patches
      ctx.fillStyle = 'rgba(255,255,255,0.045)';
      ctx.fillRect(0, 0, w / 2, h);
      for (let i = 0; i < 2200; i++) {
        const x = (i * 97) % w;
        const y = (i * 53) % h;
        ctx.fillStyle =
          i % 7 === 0
            ? 'rgba(253, 224, 71, 0.14)'
            : i % 3 === 0
            ? 'rgba(255,255,255,0.07)'
            : 'rgba(12,55,12,0.1)';
        ctx.fillRect(x, y, 3, i % 7 === 0 ? 3 : 6);
      }
    },
    repeat,
    repeat
  );
}

export function getWaterTexture(): THREE.CanvasTexture {
  return makeProceduralTexture(
    'water_ripples',
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#0d6094';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 160; i++) {
        const x = (i * 47) % w;
        const y = (i * 83) % h;
        ctx.fillStyle = i % 2 === 0 ? 'rgba(125, 211, 252, 0.13)' : 'rgba(7, 45, 75, 0.18)';
        ctx.beginPath();
        ctx.ellipse(x, y, 18 + (i % 14), 4 + (i % 4), 0.2, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    22,
    22
  );
}

export function getFacadeTexture(
  wallHex = '#efe4cf',
  trimHex = '#c5b496',
  glassHex = '#38bdf8',
  rows = 3,
  cols = 4,
  repeatX = 2,
  repeatY = 1
): THREE.CanvasTexture {
  return makeProceduralTexture(
    `facade_${wallHex}_${trimHex}_${glassHex}_${rows}x${cols}`,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = wallHex;
      ctx.fillRect(0, 0, w, h);

      // Subtle masonry lines
      ctx.strokeStyle = 'rgba(60, 45, 30, 0.1)';
      ctx.lineWidth = 2;
      for (let y = 16; y < h; y += 32) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      const rowH = h / rows;
      const colW = w / cols;

      // Floor stringcourse bands
      for (let r = 0; r < rows; r++) {
        const ry = r * rowH;
        ctx.fillStyle = trimHex;
        ctx.fillRect(0, ry, w, 10);
        ctx.fillStyle = 'rgba(0,0,0,0.12)';
        ctx.fillRect(0, ry + 10, w, 4);

        for (let c = 0; c < cols; c++) {
          const cx = c * colW;
          const ww = colW * 0.56;
          const wh = rowH * 0.58;
          const wx = cx + (colW - ww) / 2;
          const wy = ry + rowH * 0.24;

          // Outer frame + lintel + sill
          ctx.fillStyle = trimHex;
          ctx.fillRect(wx - 7, wy - 9, ww + 14, 9);
          ctx.fillRect(wx - 6, wy + wh, ww + 12, 8);
          ctx.fillStyle = '#334155';
          ctx.fillRect(wx - 4, wy - 2, ww + 8, wh + 4);

          // Glass gradient
          const grad = ctx.createLinearGradient(wx, wy, wx + ww, wy + wh);
          grad.addColorStop(0, '#0f2942');
          grad.addColorStop(0.45, glassHex);
          grad.addColorStop(1, '#1e3a5f');
          ctx.fillStyle = grad;
          ctx.fillRect(wx, wy, ww, wh);

          // Warm lit interior hint on some panes
          if ((r + c) % 3 === 0) {
            ctx.fillStyle = 'rgba(253, 230, 138, 0.36)';
            ctx.fillRect(wx + 3, wy + 3, ww - 6, wh - 6);
          }

          // Cross mullions
          ctx.fillStyle = '#e2e8f0';
          ctx.fillRect(wx + ww / 2 - 2, wy, 4, wh);
          ctx.fillRect(wx, wy + wh / 2 - 2, ww, 4);
        }
      }
    },
    repeatX,
    repeatY
  );
}

export function getGlassFacadeTexture(tint = '#38bdf8'): THREE.CanvasTexture {
  return makeProceduralTexture(
    `glass_v2_${tint}`,
    256,
    (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0c233a');
      grad.addColorStop(0.5, tint);
      grad.addColorStop(1, '#091b2e');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      // Spandrel bands
      for (let y = 0; y < h; y += 32) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.45)';
        ctx.fillRect(0, y, w, 7);
      }
      ctx.strokeStyle = 'rgba(226, 232, 240, 0.42)';
      ctx.lineWidth = 3;
      for (let x = 0; x <= w; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y <= h; y += 32) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    },
    2,
    4
  );
}

export function getMarbleFloorTexture(): THREE.CanvasTexture {
  return makeProceduralTexture(
    'marble_floor',
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#efe8da';
      ctx.fillRect(0, 0, w, h);
      for (let y = 0; y < 4; y++) {
        for (let x = 0; x < 4; x++) {
          ctx.fillStyle = (x + y) % 2 === 0 ? '#f3ede0' : '#dfd4be';
          ctx.fillRect(x * 64, y * 64, 62, 62);
        }
      }
    },
    4,
    4
  );
}

export function makeSignTexture(title: string, bgHex = '#0f172a', textHex = '#fbbf24', borderHex = '#f59e0b'): THREE.CanvasTexture {
  const key = `sign_${title}_${bgHex}_${textHex}`;
  const existing = cache.get(key);
  if (existing) return existing;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = bgHex;
    ctx.fillRect(0, 0, 512, 128);
    ctx.strokeStyle = borderHex;
    ctx.lineWidth = 6;
    ctx.strokeRect(6, 6, 500, 116);
    ctx.fillStyle = textHex;
    ctx.font = 'bold 34px Cairo, Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, 256, 66);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  cache.set(key, tex);
  return tex;
}

export function updateTickerCanvas(
  canvas: HTMLCanvasElement,
  stocks: Array<{ ticker: string; price: number; changePct: number }>
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.fillStyle = '#050b16';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = '#1e3a5f';
  ctx.lineWidth = 4;
  ctx.strokeRect(4, 4, canvas.width - 8, canvas.height - 8);

  ctx.fillStyle = '#fbbf24';
  ctx.font = 'bold 26px Cairo, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('لوحة تداول البورصة المباشرة — LIVE EXCHANGE', canvas.width / 2, 34);

  const cols = 2;
  const startY = 74;
  stocks.slice(0, 8).forEach((s, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = col === 0 ? 28 : canvas.width / 2 + 16;
    const y = startY + row * 44;
    ctx.fillStyle = 'rgba(30, 41, 59, 0.8)';
    ctx.fillRect(x, y - 24, canvas.width / 2 - 44, 36);
    ctx.fillStyle = '#e2e8f0';
    ctx.font = 'bold 20px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(s.ticker, x + 12, y);
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`${s.price.toFixed(1)} 🪙`, x + 125, y);
    ctx.fillStyle = s.changePct >= 0 ? '#22c55e' : '#ef4444';
    ctx.fillText(`${s.changePct >= 0 ? '▲' : '▼'} ${Math.abs(s.changePct).toFixed(1)}%`, x + 235, y);
  });
}
