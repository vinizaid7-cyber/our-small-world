export interface AudioSettings {
  muted: boolean;
  master: number; // 0..1
  sfx: number;
  ambient: number;
  music: number;
}

class AudioManager {
  private ctx: AudioContext | null = null;
  private settings: AudioSettings = {
    muted: false,
    master: 0.7,
    sfx: 0.85,
    ambient: 0.55,
    music: 0.45,
  };
  private ambientTimer: number | null = null;
  private currentZone: string = 'ISL_HOME';

  constructor() {
    try {
      const saved = localStorage.getItem('osw_v15_audio');
      if (saved) Object.assign(this.settings, JSON.parse(saved));
    } catch {
      // ignore
    }
  }

  public getSettings(): AudioSettings {
    return { ...this.settings };
  }

  public updateSettings(next: Partial<AudioSettings>): void {
    Object.assign(this.settings, next);
    try {
      localStorage.setItem('osw_v15_audio', JSON.stringify(this.settings));
    } catch {
      // ignore
    }
  }

  public unlock(): void {
    if (!this.ctx && typeof window !== 'undefined') {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AC) {
        this.ctx = new AC();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    this.startAmbientLoop();
  }

  private gainFor(channel: 'sfx' | 'ambient' | 'music', base = 0.2): number {
    if (this.settings.muted) return 0;
    return base * this.settings.master * this.settings[channel];
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number): void {
    if (!this.ctx || vol <= 0.001) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), now + dur);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(vol, now + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0008, now + dur);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  public playSfx(
    kind: 'coin' | 'door' | 'elevator' | 'horn' | 'crash' | 'step' | 'click' | 'siren' | 'build' | 'fanfare' | 'furnace' | 'turn'
  ): void {
    const v = this.gainFor('sfx', 0.22);
    if (v <= 0.001 || !this.ctx) return;
    switch (kind) {
      case 'click':
        this.tone(560, 0.06, 'sine', v * 0.6, 720);
        break;
      case 'coin':
        this.tone(880, 0.09, 'triangle', v, 1320);
        setTimeout(() => this.tone(1320, 0.16, 'sine', v * 0.9), 70);
        break;
      case 'door':
        this.tone(180, 0.18, 'triangle', v * 0.7, 110);
        break;
      case 'elevator':
        this.tone(740, 0.18, 'sine', v * 0.8);
        setTimeout(() => this.tone(987, 0.28, 'sine', v * 0.8), 140);
        break;
      case 'horn':
        this.tone(330, 0.28, 'sawtooth', v * 0.65);
        this.tone(415, 0.28, 'sawtooth', v * 0.45);
        break;
      case 'crash':
        this.tone(110, 0.3, 'sawtooth', v * 1.1, 38);
        break;
      case 'step':
        this.tone(140, 0.04, 'triangle', v * 0.2, 95);
        break;
      case 'siren':
        this.tone(680, 0.22, 'square', v * 0.45, 920);
        setTimeout(() => this.tone(920, 0.22, 'square', v * 0.45, 680), 230);
        break;
      case 'build':
        this.tone(240, 0.12, 'square', v * 0.6, 150);
        break;
      case 'fanfare':
        [523, 659, 784, 1046].forEach((f, idx) => {
          setTimeout(() => this.tone(f, 0.22, 'triangle', v * 0.85), idx * 95);
        });
        break;
      case 'furnace':
        this.tone(92, 0.4, 'sawtooth', v * 0.45, 76);
        break;
      case 'turn':
        this.tone(920, 0.03, 'square', v * 0.25);
        break;
    }
  }

  public setZone(zone: string): void {
    this.currentZone = zone;
  }

  private startAmbientLoop(): void {
    if (this.ambientTimer !== null || typeof window === 'undefined') return;
    this.ambientTimer = window.setInterval(() => {
      if (!this.ctx || this.settings.muted) return;
      const amb = this.gainFor('ambient', 0.045);
      const mus = this.gainFor('music', 0.035);
      if (amb > 0.002) {
        if (this.currentZone === 'ISL_PORT') {
          // Gentle wave shimmer
          this.tone(130, 1.4, 'sine', amb * 0.7, 95);
        } else if (this.currentZone === 'ISL_AGRI' || this.currentZone === 'ISL_HOME') {
          // Bird chirp
          if (Math.random() < 0.6) {
            const base = 1350 + Math.random() * 500;
            this.tone(base, 0.08, 'sine', amb * 0.6, base * 1.25);
          }
        } else if (this.currentZone === 'ISL_INDUSTRY') {
          this.tone(72, 0.9, 'triangle', amb * 0.65);
        }
      }
      if (mus > 0.002 && Math.random() < 0.55) {
        const scale = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25];
        const note = scale[Math.floor(Math.random() * scale.length)];
        this.tone(note, 1.1, 'sine', mus);
      }
    }, 2600);
  }
}

export const audioSys = new AudioManager();
