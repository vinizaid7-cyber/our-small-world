import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { BUILDER_BLUEPRINTS } from '../data/catalog';
import { islandAtPoint, IslandId } from '../data/islandsData';
import { GameState, PlayerProfile } from '../data/storage';
import { animateCharacterRig, CharacterRig, createCharacterRig } from '../entities/Characters3D';
import { NPCEntity, NPCManager } from '../entities/NPCManager';
import { VehicleInstance, VehicleManager } from '../entities/VehicleSystem';
import { InteriorManager, InteriorSceneData } from '../interiors/InteriorBuilders';
import { EconomySimulation } from '../systems/Simulation';
import { buildEntireWorld, WorldRefs } from '../world/WorldBuilder';
import { getMat, InteractiveZone } from '../world/MeshHelpers';
import { audioSys } from './AudioSystem';
import { SpatialCollisionWorld } from './CollisionSystem';

export type QualityPreset = 'low' | 'medium' | 'high' | 'ultra';
export type WeatherMode = 'clear' | 'rain';
export type CameraMode = 'third' | 'first';

export interface EngineCallbacks {
  onNearestPrompt: (prompt: { label: string; emoji: string; action: string } | null) => void;
  onHUDTick: (info: {
    x: number;
    z: number;
    islandId: IslandId;
    islandName: string;
    inInterior: InteriorSceneData | null;
    inVehicle: VehicleInstance | null;
    gameHour: number;
    fps: number;
  }) => void;
  onToast: (msg: string, tone?: 'info' | 'gold' | 'danger' | 'success') => void;
  onVehicleCrash: (veh: VehicleInstance, impact: number, target: string) => void;
  onPedestrianHit: (npc: NPCEntity) => void;
  onStateMutated: () => void;
  onGhostPlace: (blueprintId: string, islandId: IslandId, x: number, z: number, ry: number) => void;
}

export class ThreeGameEngine {
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public collision = new SpatialCollisionWorld();
  public world: WorldRefs;
  public interiors: InteriorManager;
  public npcs: NPCManager;
  public vehicles: VehicleManager;
  public economy = new EconomySimulation();

  public playerRig: CharacterRig;
  public playerX = 0;
  public playerZ = 8;
  public playerRY = Math.PI;
  public activeVehicle: VehicleInstance | null = null;
  public camMode: CameraMode = 'third';
  public camYaw = 0;
  public camPitch = 0.42;
  public camDist = 15;

  public quality: QualityPreset = 'high';
  public weather: WeatherMode = 'clear';
  public timeOffsetHours = 0; // allows shifting day/night smoothly
  public autoCycleTime = true;
  public gameHour = 10.5;

  public keys = new Set<string>();
  public touchMove = { x: 0, y: 0 };
  public sprinting = false;

  // 3D Builder Ghost Placement Mode
  public buildGhost: {
    blueprintId: string;
    mesh: THREE.Group;
    x: number;
    z: number;
    ry: number;
    valid: boolean;
  } | null = null;

  private hemiLight: THREE.HemisphereLight;
  private sunLight: THREE.DirectionalLight;
  private rainPoints: THREE.Points | null = null;
  private starPoints: THREE.Points | null = null;
  private animId = 0;
  private lastTime = performance.now();
  private elapsed = 0;
  private fpsFrames = 0;
  private fpsTimer = 0;
  private currentFps = 60;
  private hudTimer = 0;
  private isSoftwareGL = false;

  private nearestAction: { label: string; emoji: string; action: string } | null = null;
  private stateRef: GameState;
  private callbacks: EngineCallbacks;
  private disposed = false;

  // Scratch vectors to avoid GC inside loop
  private _camTarget = new THREE.Vector3();
  private _camDesired = new THREE.Vector3();

  constructor(
    container: HTMLElement,
    initialState: GameState,
    profile: PlayerProfile,
    callbacks: EngineCallbacks
  ) {
    this.stateRef = initialState;
    this.callbacks = callbacks;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#7cc4f5');
    this.scene.fog = new THREE.FogExp2('#9ad4f5', 0.0011);

    this.camera = new THREE.PerspectiveCamera(56, container.clientWidth / Math.max(1, container.clientHeight), 0.3, 1800);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.detectSoftwareGL();
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = !this.isSoftwareGL;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Environment reflections (skip heavy PMREM IBL on CPU software rasterizers like SwiftShader)
    if (!this.isSoftwareGL) {
      try {
        const pmrem = new THREE.PMREMGenerator(this.renderer);
        const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
        this.scene.environment = envTex;
        pmrem.dispose();
      } catch {
        // Fallback safely if PMREM unavailable
      }
    }

    // Lighting
    this.hemiLight = new THREE.HemisphereLight('#e0f2fe', '#3f6212', 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#fff7ed', 2.0);
    this.sunLight.position.set(120, 180, 90);
    if (!this.isSoftwareGL) {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(2048, 2048);
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 520;
      const d = 160;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.bias = -0.0004;
      this.sunLight.shadow.normalBias = 0.04;
    }
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Build Starfield & Rain
    this.buildSkyParticles();

    // Build World, Interiors, NPCs, Vehicles
    this.world = buildEntireWorld(this.scene, this.collision);
    this.world.syncState(this.stateRef);
    this.interiors = new InteriorManager(this.scene);
    this.npcs = new NPCManager(this.scene);
    this.vehicles = new VehicleManager(this.scene);
    this.vehicles.syncOwnedVehicles(this.stateRef.vehicles);

    // Player 3D Character Rig
    this.playerRig = createCharacterRig({
      gender: profile.gender,
      shirtColor: profile.color,
      hairColor: profile.hair,
      hairStyle: profile.hairStyle,
    });
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
    this.scene.add(this.playerRig.root);

    this.applyQuality(this.isSoftwareGL ? 'low' : 'high');
    this.bindEvents(container);
    this.loop();
  }

  private detectSoftwareGL(): void {
    try {
      const gl = this.renderer.getContext();
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      const rStr = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
      this.isSoftwareGL = /SwiftShader|llvmpipe|Software/i.test(rStr);
    } catch {
      this.isSoftwareGL = false;
    }
  }

  public applyQuality(q: QualityPreset): void {
    this.quality = q;
    const dpr = q === 'low' ? 1 : q === 'medium' ? Math.min(1.25, window.devicePixelRatio) : Math.min(2, window.devicePixelRatio);
    this.renderer.setPixelRatio(this.isSoftwareGL ? 1 : dpr);
    this.renderer.shadowMap.enabled = !this.isSoftwareGL && q !== 'low';
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.density = q === 'low' ? 0.0018 : 0.00095;
    }
  }

  public updateStateRef(next: GameState): void {
    this.stateRef = next;
    this.world.syncState(next);
    this.vehicles.syncOwnedVehicles(next.vehicles);
    this.interiors.refreshExchangeBoard(next);
  }

  public refreshPlayerLook(profile: PlayerProfile): void {
    const pos = this.playerRig.root.position.clone();
    const rot = this.playerRig.root.rotation.y;
    const vis = this.playerRig.root.visible;
    this.scene.remove(this.playerRig.root);
    this.playerRig = createCharacterRig({
      gender: profile.gender,
      shirtColor: profile.color,
      hairColor: profile.hair,
      hairStyle: profile.hairStyle,
    });
    this.playerRig.root.position.copy(pos);
    this.playerRig.root.rotation.y = rot;
    this.playerRig.root.visible = vis;
    this.scene.add(this.playerRig.root);
  }

  private buildSkyParticles(): void {
    // Stars for night sky
    const sCount = 320;
    const sPos = new Float32Array(sCount * 3);
    for (let i = 0; i < sCount; i++) {
      const a = Math.random() * Math.PI * 2;
      const el = 0.25 + Math.random() * 1.1;
      const r = 680;
      sPos[i * 3] = Math.cos(a) * Math.cos(el) * r;
      sPos[i * 3 + 1] = Math.sin(el) * r;
      sPos[i * 3 + 2] = Math.sin(a) * Math.cos(el) * r + 400;
    }
    const sGeo = new THREE.BufferGeometry();
    sGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3));
    this.starPoints = new THREE.Points(
      sGeo,
      new THREE.PointsMaterial({ color: '#fef9c3', size: 3.2, transparent: true, opacity: 0 })
    );
    this.scene.add(this.starPoints);

    // Rain particles around camera
    const rCount = 450;
    const rPos = new Float32Array(rCount * 3);
    for (let i = 0; i < rCount; i++) {
      rPos[i * 3] = (Math.random() - 0.5) * 90;
      rPos[i * 3 + 1] = Math.random() * 45;
      rPos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const rGeo = new THREE.BufferGeometry();
    rGeo.setAttribute('position', new THREE.BufferAttribute(rPos, 3));
    this.rainPoints = new THREE.Points(
      rGeo,
      new THREE.PointsMaterial({ color: '#bae6fd', size: 0.35, transparent: true, opacity: 0.6 })
    );
    this.rainPoints.visible = false;
    this.scene.add(this.rainPoints);
  }

  // ============ TELEPORT / ENTER / EXIT / VEHICLE ============
  public teleportTo(x: number, z: number): void {
    if (this.interiors.activeInterior) {
      this.interiors.exitInterior();
    }
    if (this.activeVehicle) {
      this.activeVehicle.x = x;
      this.activeVehicle.z = z;
      this.activeVehicle.speed = 0;
      this.activeVehicle.group.position.set(x, 0, z);
    } else {
      this.playerX = x;
      this.playerZ = z;
      this.playerRig.root.position.set(x, 0, z);
    }
    this.camYaw = 0;
  }

  public enterInterior(id: string, hqFloor = 0): InteriorSceneData {
    if (this.activeVehicle) {
      this.exitVehicle();
    }
    audioSys.playSfx('door');
    const data = this.interiors.enterInterior(id, this.stateRef, hqFloor);
    this.playerX = data.spawnX;
    this.playerZ = data.spawnZ;
    this.playerRY = Math.PI;
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
    this.world.root.visible = false;
    this.npcs.group.visible = false;
    this.vehicles.group.visible = false;
    return data;
  }

  public exitInterior(): void {
    const ret = this.interiors.exitInterior();
    if (!ret) return;
    audioSys.playSfx('door');
    this.world.root.visible = true;
    this.npcs.group.visible = true;
    this.vehicles.group.visible = true;
    this.playerX = ret.x;
    this.playerZ = ret.z;
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
  }

  public boardVehicle(veh: VehicleInstance): void {
    if (this.interiors.activeInterior) return;
    this.activeVehicle = veh;
    this.playerX = veh.x;
    this.playerZ = veh.z;
    this.playerRY = veh.ry;
    this.playerRig.root.visible = false;
    audioSys.playSfx('door');
    this.callbacks.onToast(`ركبت ${veh.def.emoji} ${veh.def.name} (WASD للقيادة · H للبوري · L للأنوار · F للنزول)`, 'info');
  }

  public exitVehicle(): void {
    if (!this.activeVehicle) return;
    const v = this.activeVehicle;
    v.speed = 0;
    this.playerX = v.x + Math.cos(v.ry) * (v.def.width / 2 + 1.1);
    this.playerZ = v.z - Math.sin(v.ry) * (v.def.width / 2 + 1.1);
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
    this.playerRig.root.visible = true;
    this.activeVehicle = null;
    audioSys.playSfx('door');
  }

  // ============ 3D GHOST BUILDER MODE ============
  public startBuildGhost(blueprintId: string): void {
    this.cancelBuildGhost();
    if (this.interiors.activeInterior) {
      this.callbacks.onToast('اخرج للخارج أولاً لوضع المبنى على الأرض', 'danger');
      return;
    }
    const bp = BUILDER_BLUEPRINTS.find((x) => x.id === blueprintId);
    if (!bp) return;
    const g = new THREE.Group();
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(bp.w, bp.h, bp.d),
      getMat('#22c55e', { transparent: true, opacity: 0.45 })
    );
    box.position.y = bp.h / 2;
    g.add(box);
    const gx = this.playerX + Math.sin(this.playerRY) * 14;
    const gz = this.playerZ + Math.cos(this.playerRY) * 14;
    g.position.set(gx, 0, gz);
    this.scene.add(g);
    this.buildGhost = { blueprintId, mesh: g, x: gx, z: gz, ry: 0, valid: true };
  }

  public rotateBuildGhost(): void {
    if (!this.buildGhost) return;
    this.buildGhost.ry += Math.PI / 2;
    this.buildGhost.mesh.rotation.y = this.buildGhost.ry;
  }

  public confirmBuildGhost(): void {
    if (!this.buildGhost) return;
    if (!this.buildGhost.valid) {
      this.callbacks.onToast('الموقع غير صالح للبناء (تأكد من البعد عن الطرق والماء والمباني)', 'danger');
      return;
    }
    const isl = islandAtPoint(this.buildGhost.x, this.buildGhost.z);
    const { blueprintId, x, z, ry } = this.buildGhost;
    this.cancelBuildGhost();
    this.callbacks.onGhostPlace(blueprintId, isl.id, Math.round(x), Math.round(z), ry);
  }

  public cancelBuildGhost(): void {
    if (!this.buildGhost) return;
    this.scene.remove(this.buildGhost.mesh);
    this.buildGhost = null;
  }

  // ============ INTERACTION TRIGGER ============
  public triggerNearestAction(): { action: string } | null {
    if (!this.nearestAction) return null;
    const act = this.nearestAction.action;

    if (act === 'gate:garage') {
      const open = this.world.toggleGarageGate();
      audioSys.playSfx('door');
      this.callbacks.onToast(open ? '🔓 تم فتح بوابة الكراج الذكية' : '🔒 تم إغلاق بوابة الكراج', 'info');
      return { action: act };
    }
    if (act === 'exit_interior') {
      this.exitInterior();
      return { action: act };
    }
    if (act.startsWith('enter:')) {
      const id = act.slice(6);
      const door = this.world.allDoors.find((d) => d.interiorId === id);
      if (door) door.isOpen = true;
      setTimeout(() => {
        this.enterInterior(id, 0);
      }, 180);
      return { action: act };
    }
    if (act.startsWith('board:')) {
      const uid = act.slice(6);
      const veh = this.vehicles.playerVehicles.find((v) => v.uid === uid);
      if (veh) this.boardVehicle(veh);
      return { action: act };
    }
    return { action: act };
  }

  private bindEvents(container: HTMLElement): void {
    let dragging = false;
    let lastX = 0;
    let lastY = 0;

    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      const k = e.key.toLowerCase();
      const c = e.code;
      this.keys.add(k);
      if (c) this.keys.add(c);
      if (k === 'shift' || c === 'ShiftLeft' || c === 'ShiftRight') this.sprinting = true;
      if (k === 'v' || c === 'KeyV') {
        this.camMode = this.camMode === 'third' ? 'first' : 'third';
        this.callbacks.onToast(this.camMode === 'first' ? '🎥 منظور الشخص الأول' : '🎥 منظور الشخص الثالث', 'info');
      }
      if ((k === 'f' || c === 'KeyF') && this.activeVehicle) {
        this.exitVehicle();
      }
      if ((k === 'h' || c === 'KeyH') && this.activeVehicle) {
        audioSys.playSfx('horn');
      }
      if ((k === 'l' || c === 'KeyL') && this.activeVehicle) {
        this.activeVehicle.headlightsOn = !this.activeVehicle.headlightsOn;
      }
      if ((k === 'q' || c === 'KeyQ') && this.activeVehicle) {
        this.activeVehicle.signal = this.activeVehicle.signal === -1 ? 0 : -1;
        audioSys.playSfx('turn');
      }
      if ((k === 'r' || c === 'KeyR') && this.buildGhost) {
        this.rotateBuildGhost();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const c = e.code;
      this.keys.delete(k);
      if (c) this.keys.delete(c);
      if (k === 'shift' || c === 'ShiftLeft' || c === 'ShiftRight') this.sprinting = false;
    };

    const onPointerDown = (e: PointerEvent) => {
      audioSys.unlock();
      if (e.target !== this.renderer.domElement) return;
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;
      this.camYaw -= dx * 0.0065;
      this.camPitch = Math.max(0.14, Math.min(1.25, this.camPitch + dy * 0.005));
    };

    const onPointerUp = () => {
      dragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      this.camDist = Math.max(6, Math.min(42, this.camDist + e.deltaY * 0.015));
    };

    const onResize = () => {
      if (this.disposed) return;
      this.camera.aspect = container.clientWidth / Math.max(1, container.clientHeight);
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    container.addEventListener('wheel', onWheel, { passive: true });
    window.addEventListener('resize', onResize);

    this._cleanup = () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      container.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', onResize);
    };
  }

  private _cleanup = () => {};

  private updateSkyAndWeather(dt: number): void {
    if (this.autoCycleTime) {
      this.gameHour = (this.gameHour + dt * 0.04) % 24;
    }
    const h = (this.gameHour + this.timeOffsetHours + 24) % 24;
    const isNight = h >= 20 || h < 5.5;
    const isSunset = (h >= 17 && h < 20) || (h >= 5.5 && h < 7.5);

    const skyColor = isNight ? '#0a1224' : isSunset ? '#f59e0b' : this.weather === 'rain' ? '#475569' : '#7cc4f5';
    (this.scene.background as THREE.Color).lerp(new THREE.Color(skyColor), 0.04);
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.copy(this.scene.background as THREE.Color);
    }

    // Sun angle
    const sunAngle = ((h - 6) / 12) * Math.PI;
    this.sunLight.position.set(
      this.playerX + Math.cos(sunAngle) * 180,
      Math.max(25, Math.sin(sunAngle) * 200),
      this.playerZ + 80
    );
    this.sunLight.target.position.set(this.playerX, 0, this.playerZ);
    this.sunLight.intensity = isNight ? 0.45 : this.weather === 'rain' ? 1.0 : 2.05;
    this.hemiLight.intensity = isNight ? 0.55 : 0.9;
    this.world.lampBulbMat.emissiveIntensity = isNight ? 1.8 : 0.15;

    if (this.starPoints) {
      (this.starPoints.material as THREE.PointsMaterial).opacity = isNight ? 0.88 : 0;
    }

    if (this.rainPoints) {
      this.rainPoints.visible = this.weather === 'rain' && !this.interiors.activeInterior;
      if (this.rainPoints.visible) {
        this.rainPoints.position.set(this.playerX, 0, this.playerZ);
        const attr = this.rainPoints.geometry.getAttribute('position') as THREE.BufferAttribute;
        for (let i = 0; i < attr.count; i++) {
          let y = attr.getY(i) - dt * 28;
          if (y < 0) y = 45;
          attr.setY(i, y);
        }
        attr.needsUpdate = true;
      }
    }
  }

  private loop = (): void => {
    if (this.disposed) return;
    this.animId = requestAnimationFrame(this.loop);

    const now = performance.now();
    const dt = Math.min(0.05, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.elapsed += dt;

    // FPS tracking
    this.fpsFrames++;
    this.fpsTimer += dt;
    if (this.fpsTimer >= 0.5) {
      this.currentFps = Math.round(this.fpsFrames / this.fpsTimer);
      this.fpsFrames = 0;
      this.fpsTimer = 0;
    }

    const inInt = this.interiors.activeInterior;
    const isNight = this.gameHour >= 20 || this.gameHour < 5.5;

    // Input axes (supporting both e.key and physical e.code for Arabic/English keyboards)
    let moveX = this.touchMove.x;
    let moveZ = this.touchMove.y;
    if (this.keys.has('w') || this.keys.has('KeyW') || this.keys.has('arrowup') || this.keys.has('ArrowUp')) moveZ -= 1;
    if (this.keys.has('s') || this.keys.has('KeyS') || this.keys.has('arrowdown') || this.keys.has('ArrowDown')) moveZ += 1;
    if (this.keys.has('a') || this.keys.has('KeyA') || this.keys.has('arrowleft') || this.keys.has('ArrowLeft')) moveX -= 1;
    if (this.keys.has('d') || this.keys.has('KeyD') || this.keys.has('arrowright') || this.keys.has('ArrowRight')) moveX += 1;

    // 1. Driving vs Walking
    if (this.activeVehicle && !inInt) {
      const throttle = -moveZ;
      const steer = -moveX;
      const brake = this.keys.has(' ');
      const honk = this.keys.has('h');
      this.vehicles.driveActiveVehicle(
        this.activeVehicle,
        dt,
        this.elapsed,
        { throttle, steer, brake, honk },
        isNight,
        this.collision,
        this.callbacks.onVehicleCrash
      );
      this.playerX = this.activeVehicle.x;
      this.playerZ = this.activeVehicle.z;
      this.playerRY = this.activeVehicle.ry;
    } else {
      const mag = Math.hypot(moveX, moveZ);
      let walkSpd = 0;
      if (mag > 0.05) {
        const nxIn = moveX / mag;
        const nzIn = moveZ / mag;
        // Camera-relative movement direction
        const sinY = Math.sin(this.camYaw);
        const cosY = Math.cos(this.camYaw);
        const wx = nxIn * cosY + nzIn * sinY;
        const wz = -nxIn * sinY + nzIn * cosY;

        walkSpd = this.sprinting ? 13.5 : 7.8;
        const targetX = this.playerX + wx * walkSpd * dt;
        const targetZ = this.playerZ + wz * walkSpd * dt;

        const colWorld = inInt ? this.interiors.collision : this.collision;
        const res = colWorld.resolveCircle(targetX, targetZ, 0.55, this.playerX, this.playerZ, !inInt);
        this.playerX = res.x;
        this.playerZ = res.z;
        this.playerRY = Math.atan2(wx, wz);
      }
      this.playerRig.root.position.set(this.playerX, inInt ? 0 : 0.08, this.playerZ);
      this.playerRig.root.rotation.y = this.playerRY;
      animateCharacterRig(this.playerRig, walkSpd, dt, this.elapsed);
    }

    // 2. Build Ghost Tracking
    if (this.buildGhost && !inInt) {
      const gx = this.playerX + Math.sin(this.playerRY) * 14;
      const gz = this.playerZ + Math.cos(this.playerRY) * 14;
      this.buildGhost.x = gx;
      this.buildGhost.z = gz;
      this.buildGhost.mesh.position.set(gx, 0, gz);
      const bp = BUILDER_BLUEPRINTS.find((x) => x.id === this.buildGhost!.blueprintId);
      if (bp) {
        const chk = this.collision.isPointClearForPlacement(gx, gz, bp.w, bp.d);
        this.buildGhost.valid = chk.ok;
        const box = this.buildGhost.mesh.children[0] as THREE.Mesh;
        if (box) {
          (box.material as THREE.MeshStandardMaterial).color.set(chk.ok ? '#22c55e' : '#ef4444');
        }
      }
    }

    // 3. Proximity Doors & Interactive Zones
    const exportingActive = this.stateRef.shipments.some((s) => !s.claimed && Date.now() < s.endAt);
    if (!inInt) {
      // Auto-open hinged doors when player walks right up to them!
      for (const d of this.world.allDoors) {
        const dist = Math.hypot(this.playerX - d.worldX, this.playerZ - d.worldZ);
        d.isOpen = dist < 6.5;
      }
    }
    this.world.updateAnimations(dt, this.elapsed, exportingActive);

    // Nearest Prompt Detection
    let prompt: { label: string; emoji: string; action: string } | null = null;
    let bestDist = Infinity;

    const zoneList: InteractiveZone[] = inInt ? inInt.zones : this.world.allZones;
    for (const z of zoneList) {
      const d = Math.hypot(this.playerX - z.x, this.playerZ - z.z);
      if (d <= z.radius && d < bestDist) {
        bestDist = d;
        prompt = { label: z.label, emoji: z.emoji, action: z.action };
      }
    }
    if (!inInt && !this.activeVehicle) {
      const nearVeh = this.vehicles.findNearestVehicle(this.playerX, this.playerZ, 4.5);
      if (nearVeh && Math.hypot(this.playerX - nearVeh.x, this.playerZ - nearVeh.z) < bestDist) {
        bestDist = Math.hypot(this.playerX - nearVeh.x, this.playerZ - nearVeh.z);
        prompt = { label: `ركوب ${nearVeh.def.name}`, emoji: nearVeh.def.emoji, action: `board:${nearVeh.uid}` };
      }
      const nearNpc = this.npcs.findNearestNPC(this.playerX, this.playerZ, 3.8);
      if (nearNpc && Math.hypot(this.playerX - nearNpc.x, this.playerZ - nearNpc.z) < bestDist) {
        prompt = {
          label: nearNpc.isThief ? 'القبض على اللص! (+120🪙)' : `التحدث مع ${nearNpc.name}`,
          emoji: nearNpc.emoji,
          action: nearNpc.isThief ? 'catch_thief' : `talk:${nearNpc.id}`,
        };
      }
    }
    if (
      prompt?.action !== this.nearestAction?.action ||
      prompt?.label !== this.nearestAction?.label
    ) {
      this.nearestAction = prompt;
      this.callbacks.onNearestPrompt(prompt);
    }

    // 4. World Systems Update
    if (!inInt) {
      this.world.updateLOD(this.playerX, this.playerZ);
      this.npcs.update(
        dt,
        this.elapsed,
        this.gameHour,
        this.collision,
        this.activeVehicle
          ? {
              x: this.activeVehicle.x,
              z: this.activeVehicle.z,
              speed: Math.abs(this.activeVehicle.speed),
              honking: this.keys.has('h'),
            }
          : null,
        this.callbacks.onPedestrianHit
      );
      this.vehicles.updateTrafficAndExports(dt, this.playerX, this.playerZ, exportingActive);
    }

    // 5. Economy Tick
    const econDirty = this.economy.tick(
      dt,
      this.stateRef,
      (msg) => this.callbacks.onToast(msg, 'gold'),
      (amt) => this.callbacks.onToast(`💰 عوائد الأسهم والسياحة: +${amt}🪙`, 'success')
    );
    if (econDirty) {
      this.interiors.refreshExchangeBoard(this.stateRef);
      this.callbacks.onStateMutated();
    }

    // 6. Smooth Camera Update (3rd Person / 1st Person / Driving / Indoor Safe)
    this.updateCamera(inInt);
    this.updateSkyAndWeather(dt);

    // 7. HUD Sync every ~0.2s
    this.hudTimer += dt;
    if (this.hudTimer >= 0.2) {
      this.hudTimer = 0;
      const curIsl = islandAtPoint(this.playerX, this.playerZ);
      audioSys.setZone(curIsl.id);
      this.callbacks.onHUDTick({
        x: this.playerX,
        z: this.playerZ,
        islandId: curIsl.id,
        islandName: inInt ? inInt.title : curIsl.name,
        inInterior: inInt,
        inVehicle: this.activeVehicle,
        gameHour: this.gameHour,
        fps: this.currentFps,
      });
    }

    this.renderer.render(this.scene, this.camera);
  };

  private updateCamera(inInt: InteriorSceneData | null): void {
    const focusY = this.activeVehicle ? 1.5 : 1.75;
    if (this.camMode === 'first' && !this.activeVehicle) {
      this._camDesired.set(
        this.playerX + Math.sin(this.playerRY) * 0.25,
        1.78,
        this.playerZ + Math.cos(this.playerRY) * 0.25
      );
      this._camTarget.set(
        this.playerX + Math.sin(this.playerRY) * 12,
        1.65 - (this.camPitch - 0.4) * 3,
        this.playerZ + Math.cos(this.playerRY) * 12
      );
      this.camera.position.lerp(this._camDesired, 0.45);
      this.camera.lookAt(this._camTarget);
      return;
    }

    const dist = inInt ? Math.min(this.camDist, 14) : this.activeVehicle ? Math.max(this.camDist, 13) : this.camDist;
    const yaw = this.activeVehicle ? this.activeVehicle.ry + Math.PI + this.camYaw * 0.5 : this.camYaw;
    const ox = Math.sin(yaw) * Math.cos(this.camPitch) * dist;
    const oy = Math.sin(this.camPitch) * dist + 1.8;
    const oz = Math.cos(yaw) * Math.cos(this.camPitch) * dist;

    let desiredX = this.playerX + ox;
    let desiredY = Math.max(2.2, oy);
    let desiredZ = this.playerZ + oz;

    // Indoor collision-safe camera clamping so walls never block view
    if (inInt) {
      const ix = 2400;
      desiredX = Math.max(ix - inInt.hw + 1.4, Math.min(ix + inInt.hw - 1.4, desiredX));
      desiredZ = Math.max(-inInt.hd + 1.4, Math.min(inInt.hd - 1.4, desiredZ));
      desiredY = Math.min(desiredY, 9.5);
    }

    this._camDesired.set(desiredX, desiredY, desiredZ);
    this.camera.position.lerp(this._camDesired, 0.16);
    this._camTarget.set(this.playerX, focusY, this.playerZ);
    this.camera.lookAt(this._camTarget);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.animId);
    this._cleanup();
    this.renderer.dispose();
  }
}
