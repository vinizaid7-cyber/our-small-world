import { ISLANDS, ROADS, RoadSegment } from '../data/islandsData';

export interface BoxCollider {
  id: string;
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  tag?: string;
}

export interface CircleCollider {
  id: string;
  x: number;
  z: number;
  r: number;
  tag?: string;
}

export interface RoadAuditReport {
  checkedRoads: number;
  checkedColliders: number;
  obstructions: Array<{ roadId: string; colliderId: string; x: number; z: number }>;
  passed: boolean;
}

export class SpatialCollisionWorld {
  public boxes: BoxCollider[] = [];
  public circles: CircleCollider[] = [];
  private grid = new Map<string, { boxes: BoxCollider[]; circles: CircleCollider[] }>();
  private readonly cellSize = 24;

  public clear(): void {
    this.boxes = [];
    this.circles = [];
    this.grid.clear();
  }

  private key(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  private addToCell(cx: number, cz: number, box?: BoxCollider, circle?: CircleCollider): void {
    const k = this.key(cx, cz);
    let bucket = this.grid.get(k);
    if (!bucket) {
      bucket = { boxes: [], circles: [] };
      this.grid.set(k, bucket);
    }
    if (box) bucket.boxes.push(box);
    if (circle) bucket.circles.push(circle);
  }

  public addBox(id: string, cx: number, cz: number, w: number, d: number, tag?: string): void {
    const b: BoxCollider = {
      id,
      x0: cx - w / 2,
      x1: cx + w / 2,
      z0: cz - d / 2,
      z1: cz + d / 2,
      tag,
    };
    this.boxes.push(b);
    const gx0 = Math.floor(b.x0 / this.cellSize);
    const gx1 = Math.floor(b.x1 / this.cellSize);
    const gz0 = Math.floor(b.z0 / this.cellSize);
    const gz1 = Math.floor(b.z1 / this.cellSize);
    for (let gx = gx0; gx <= gx1; gx++) {
      for (let gz = gz0; gz <= gz1; gz++) {
        this.addToCell(gx, gz, b, undefined);
      }
    }
  }

  public addCircle(id: string, x: number, z: number, r: number, tag?: string): void {
    const c: CircleCollider = { id, x, z, r, tag };
    this.circles.push(c);
    const gx0 = Math.floor((x - r) / this.cellSize);
    const gx1 = Math.floor((x + r) / this.cellSize);
    const gz0 = Math.floor((z - r) / this.cellSize);
    const gz1 = Math.floor((z + r) / this.cellSize);
    for (let gx = gx0; gx <= gx1; gx++) {
      for (let gz = gz0; gz <= gz1; gz++) {
        this.addToCell(gx, gz, undefined, c);
      }
    }
  }

  public removeByIdPrefix(prefix: string): void {
    this.boxes = this.boxes.filter((b) => !b.id.startsWith(prefix));
    this.circles = this.circles.filter((c) => !c.id.startsWith(prefix));
    this.rebuildGrid();
  }

  private rebuildGrid(): void {
    this.grid.clear();
    const oldBoxes = this.boxes.slice();
    const oldCircles = this.circles.slice();
    this.boxes = [];
    this.circles = [];
    oldBoxes.forEach((b) => this.addBox(b.id, (b.x0 + b.x1) / 2, (b.z0 + b.z1) / 2, b.x1 - b.x0, b.z1 - b.z0, b.tag));
    oldCircles.forEach((c) => this.addCircle(c.id, c.x, c.z, c.r, c.tag));
  }

  public isPointWalkableOrDrivable(x: number, z: number, radius = 0.5): boolean {
    // Must be on an island OR on a bridge road segment
    for (const isl of Object.values(ISLANDS)) {
      if (Math.hypot(x - isl.cx, z - isl.cz) <= isl.radius - radius) return true;
    }
    for (const r of ROADS) {
      if (!r.isBridge) continue;
      if (distancePointToSegment(x, z, r.x0, r.z0, r.x1, r.z1) <= r.width / 2 - radius * 0.4) {
        return true;
      }
    }
    return false;
  }

  /**
   * Resolves circle vs static colliders AND optional island/bridge boundary clamping.
   * Returns { x, z, hitColliderId }.
   */
  public resolveCircle(
    x: number,
    z: number,
    radius: number,
    prevX: number,
    prevZ: number,
    clampToLand = true
  ): { x: number; z: number; hitId: string | null } {
    let nx = x;
    let nz = z;
    let hitId: string | null = null;

    const gx0 = Math.floor((nx - radius - 2) / this.cellSize);
    const gx1 = Math.floor((nx + radius + 2) / this.cellSize);
    const gz0 = Math.floor((nz - radius - 2) / this.cellSize);
    const gz1 = Math.floor((nz + radius + 2) / this.cellSize);

    const seenBoxes = new Set<string>();
    const seenCircles = new Set<string>();

    for (let gx = gx0; gx <= gx1; gx++) {
      for (let gz = gz0; gz <= gz1; gz++) {
        const bucket = this.grid.get(this.key(gx, gz));
        if (!bucket) continue;

        for (const b of bucket.boxes) {
          if (seenBoxes.has(b.id)) continue;
          seenBoxes.add(b.id);
          const closestX = Math.max(b.x0, Math.min(nx, b.x1));
          const closestZ = Math.max(b.z0, Math.min(nz, b.z1));
          const dx = nx - closestX;
          const dz = nz - closestZ;
          const distSq = dx * dx + dz * dz;
          if (distSq < radius * radius) {
            hitId = b.id;
            const dist = Math.sqrt(distSq);
            if (dist > 0.0001) {
              const push = radius - dist;
              nx += (dx / dist) * push;
              nz += (dz / dist) * push;
            } else {
              // Inside box center: push toward nearest edge
              const dLeft = Math.abs(nx - b.x0);
              const dRight = Math.abs(b.x1 - nx);
              const dTop = Math.abs(nz - b.z0);
              const dBot = Math.abs(b.z1 - nz);
              const min = Math.min(dLeft, dRight, dTop, dBot);
              if (min === dLeft) nx = b.x0 - radius;
              else if (min === dRight) nx = b.x1 + radius;
              else if (min === dTop) nz = b.z0 - radius;
              else nz = b.z1 + radius;
            }
          }
        }

        for (const c of bucket.circles) {
          if (seenCircles.has(c.id)) continue;
          seenCircles.add(c.id);
          const dx = nx - c.x;
          const dz = nz - c.z;
          const minDist = radius + c.r;
          const distSq = dx * dx + dz * dz;
          if (distSq < minDist * minDist) {
            hitId = c.id;
            const dist = Math.sqrt(distSq) || 0.001;
            const push = minDist - dist;
            nx += (dx / dist) * push;
            nz += (dz / dist) * push;
          }
        }
      }
    }

    if (clampToLand && !this.isPointWalkableOrDrivable(nx, nz, radius * 0.5)) {
      if (this.isPointWalkableOrDrivable(prevX, nz, radius * 0.5)) {
        nx = prevX;
      } else if (this.isPointWalkableOrDrivable(nx, prevZ, radius * 0.5)) {
        nz = prevZ;
      } else {
        nx = prevX;
        nz = prevZ;
      }
      hitId = hitId || 'water_edge';
    }

    return { x: nx, z: nz, hitId };
  }

  public isPointClearForPlacement(x: number, z: number, w: number, d: number): { ok: boolean; reason?: string } {
    if (!this.isPointWalkableOrDrivable(x, z, Math.max(w, d) * 0.45)) {
      return { ok: false, reason: 'الموقع قريب من البحر أو خارج الجزيرة' };
    }
    // Check roads clearance
    const halfDiag = Math.max(w, d) * 0.55;
    for (const r of ROADS) {
      if (distancePointToSegment(x, z, r.x0, r.z0, r.x1, r.z1) < r.width / 2 + halfDiag) {
        return { ok: false, reason: 'لا يمكن البناء فوق الطريق العام' };
      }
    }
    // Check boxes
    const x0 = x - w / 2 - 1;
    const x1 = x + w / 2 + 1;
    const z0 = z - d / 2 - 1;
    const z1 = z + d / 2 + 1;
    for (const b of this.boxes) {
      if (x0 < b.x1 && x1 > b.x0 && z0 < b.z1 && z1 > b.z0) {
        return { ok: false, reason: 'يتعارض مع مبنى قائم' };
      }
    }
    return { ok: true };
  }

  /**
   * Automated diagnostic verifying ZERO obstacles lie inside any road lane!
   */
  public verifyWorldRoads(): RoadAuditReport {
    const obstructions: Array<{ roadId: string; colliderId: string; x: number; z: number }> = [];
    for (const r of ROADS) {
      const clearRadius = r.width / 2 - 0.8;
      for (const b of this.boxes) {
        const cx = (b.x0 + b.x1) / 2;
        const cz = (b.z0 + b.z1) / 2;
        const bw = (b.x1 - b.x0) / 2;
        const bd = (b.z1 - b.z0) / 2;
        if (segmentIntersectsBox(r, b.x0, b.z0, b.x1, b.z1, clearRadius - 1.5)) {
          // Only report if box center or edge penetrates driving lane
          const d = distancePointToSegment(cx, cz, r.x0, r.z0, r.x1, r.z1);
          if (d < clearRadius + Math.min(bw, bd) * 0.3) {
            obstructions.push({ roadId: r.id, colliderId: b.id, x: cx, z: cz });
          }
        }
      }
      for (const c of this.circles) {
        const d = distancePointToSegment(c.x, c.z, r.x0, r.z0, r.x1, r.z1);
        if (d < clearRadius + c.r * 0.6) {
          obstructions.push({ roadId: r.id, colliderId: c.id, x: c.x, z: c.z });
        }
      }
    }
    return {
      checkedRoads: ROADS.length,
      checkedColliders: this.boxes.length + this.circles.length,
      obstructions,
      passed: obstructions.length === 0,
    };
  }
}

export function distancePointToSegment(
  px: number,
  pz: number,
  x0: number,
  z0: number,
  x1: number,
  z1: number
): number {
  const vx = x1 - x0;
  const vz = z1 - z0;
  const wx = px - x0;
  const wz = pz - z0;
  const lenSq = vx * vx + vz * vz;
  if (lenSq < 0.0001) return Math.hypot(px - x0, pz - z0);
  const t = Math.max(0, Math.min(1, (wx * vx + wz * vz) / lenSq));
  const projX = x0 + t * vx;
  const projZ = z0 + t * vz;
  return Math.hypot(px - projX, pz - projZ);
}

function segmentIntersectsBox(
  r: RoadSegment,
  x0: number,
  z0: number,
  x1: number,
  z1: number,
  pad: number
): boolean {
  const steps = 12;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = r.x0 + (r.x1 - r.x0) * t;
    const z = r.z0 + (r.z1 - r.z0) * t;
    if (x >= x0 - pad && x <= x1 + pad && z >= z0 - pad && z <= z1 + pad) return true;
  }
  return false;
}
