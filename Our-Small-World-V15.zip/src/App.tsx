import React, { useCallback, useEffect, useRef, useState } from 'react';
import { QUESTS } from './data/catalog';
import { ISLANDS, islandAtPoint, IslandId } from './data/islandsData';
import {
  DemoStore,
  foldGameState,
  GameEventRecord,
  GameState,
  getActiveUid,
  loadDemoStore,
  PlayerProfile,
  saveDemoStore,
  setActiveUid,
} from './data/storage';
import { audioSys } from './engine/AudioSystem';
import { QualityPreset, ThreeGameEngine, WeatherMode } from './engine/ThreeEngine';
import { GameModals, ModalId } from './ui/GameModals';

interface ToastMsg {
  id: number;
  text: string;
  tone: 'info' | 'gold' | 'danger' | 'success';
}

export default function App() {
  const [store, setStore] = useState<DemoStore>(() => loadDemoStore());
  const [activeUid, setUidState] = useState<string>(() => getActiveUid(loadDemoStore()));
  const [entered, setEntered] = useState(false);

  const [gameState, setGameState] = useState<GameState>(() => foldGameState(loadDemoStore().entries));
  const [modal, setModal] = useState<ModalId>(null);
  const [factoryId, setFactoryId] = useState('glass');
  const [npcDialog, setNpcDialog] = useState<{ name: string; emoji: string; lines: string[]; action?: string } | null>(null);
  const [prompt, setPrompt] = useState<{ label: string; emoji: string; action: string } | null>(null);
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const [ghostActive, setGhostActive] = useState(false);

  const [hudInfo, setHudInfo] = useState<{
    x: number;
    z: number;
    islandId: IslandId;
    islandName: string;
    inInterior: boolean;
    interiorId: string | null;
    inVehicleName: string | null;
    vehSpeed: number;
    vehFuelPct: number;
    vehHealth: number;
    gameHour: number;
    fps: number;
  }>({
    x: 0,
    z: 8,
    islandId: 'ISL_HOME',
    islandName: ISLANDS.ISL_HOME.name,
    inInterior: false,
    interiorId: null,
    inVehicleName: null,
    vehSpeed: 0,
    vehFuelPct: 100,
    vehHealth: 100,
    gameHour: 10.5,
    fps: 60,
  });

  const [quality, setQuality] = useState<QualityPreset>('high');
  const [weather, setWeather] = useState<WeatherMode>('clear');

  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<ThreeGameEngine | null>(null);
  const storeRef = useRef(store);
  storeRef.current = store;

  const activeProfile = store.users.find((u) => u.id === activeUid) || store.users[0];

  const pushToast = useCallback((text: string, tone: ToastMsg['tone'] = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dispatchEvent = useCallback(
    (title: string, body: Record<string, any>) => {
      const rec: GameEventRecord = {
        id: 'e_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6),
        created_at: new Date().toISOString(),
        author: activeUid,
        house: 'game',
        title,
        body: JSON.stringify(body),
      };
      const nextStore: DemoStore = {
        ...storeRef.current,
        entries: [...storeRef.current.entries, rec],
      };
      saveDemoStore(nextStore);
      setStore(nextStore);

      const folded = foldGameState(nextStore.entries);
      // Preserve live stock prices from running engine if present
      if (engineRef.current) {
        folded.stockPrices = { ...engineRef.current['stateRef'].stockPrices };
        folded.stockHistory = { ...engineRef.current['stateRef'].stockHistory };
        engineRef.current.updateStateRef(folded);
      }
      setGameState(folded);

      // Auto-check quest completions
      if (title === 'v15_factory_start' && body.factoryId === 'glass' && !folded.questsCompleted.includes('q2_glass_factory')) {
        const q = QUESTS.find((x) => x.id === 'q2_glass_factory');
        if (q) setTimeout(() => dispatchEvent('v15_quest_done', { questId: q.id, rewardCoins: q.rewardCoins, rewardXp: q.rewardXp }), 300);
      }
      if (title === 'v15_stock_buy' && !folded.questsCompleted.includes('q3_stock_exchange')) {
        const q = QUESTS.find((x) => x.id === 'q3_stock_exchange');
        if (q) setTimeout(() => dispatchEvent('v15_quest_done', { questId: q.id, rewardCoins: q.rewardCoins, rewardXp: q.rewardXp }), 300);
      }
      if (title === 'v15_export_launch' && !folded.questsCompleted.includes('q4_port_export')) {
        const q = QUESTS.find((x) => x.id === 'q4_port_export');
        if (q) setTimeout(() => dispatchEvent('v15_quest_done', { questId: q.id, rewardCoins: q.rewardCoins, rewardXp: q.rewardXp }), 300);
      }
      if (title === 'v15_excavate' && !folded.questsCompleted.includes('q5_temple_excavate')) {
        const q = QUESTS.find((x) => x.id === 'q5_temple_excavate');
        if (q) setTimeout(() => dispatchEvent('v15_quest_done', { questId: q.id, rewardCoins: q.rewardCoins, rewardXp: q.rewardXp }), 300);
      }

      if (title === 'v15_quest_done') {
        audioSys.playSfx('fanfare');
        pushToast(`🏆 أنجزت مهمة! +${body.rewardCoins}🪙`, 'gold');
      } else if (title === 'v15_factory_collect' || title === 'v15_export_claim' || title === 'v15_thief_catch') {
        audioSys.playSfx('coin');
      }
    },
    [activeUid, pushToast]
  );

  // Mount Three.js Engine once player enters the world
  useEffect(() => {
    if (!entered || !mountRef.current || engineRef.current) return;

    const eng = new ThreeGameEngine(mountRef.current, gameState, activeProfile, {
      onNearestPrompt: (p) => setPrompt(p),
      onHUDTick: (info) => {
        setHudInfo({
          x: Math.round(info.x),
          z: Math.round(info.z),
          islandId: info.islandId,
          islandName: info.islandName,
          inInterior: !!info.inInterior,
          interiorId: info.inInterior?.id || null,
          inVehicleName: info.inVehicle ? `${info.inVehicle.def.emoji} ${info.inVehicle.def.name}` : null,
          vehSpeed: info.inVehicle ? Math.round(Math.abs(info.inVehicle.speed) * 3) : 0,
          vehFuelPct: info.inVehicle ? Math.round((info.inVehicle.fuel / info.inVehicle.def.tankSize) * 100) : 100,
          vehHealth: info.inVehicle ? Math.round(info.inVehicle.health) : 100,
          gameHour: info.gameHour,
          fps: info.fps,
        });
      },
      onToast: pushToast,
      onVehicleCrash: (veh, impact, target) => {
        const dmg = Math.min(28, Math.round(impact * 0.9));
        dispatchEvent('v15_veh_damage', { vehUid: veh.uid, amount: dmg });
        pushToast(`💥 اصطدام (${target})! تضررت المركبة -${dmg}%`, 'danger');
        if (impact > 16) {
          audioSys.playSfx('siren');
          dispatchEvent('v15_ticket_fine', { amount: 65 });
          pushToast('🚓 مخالفة قيادة متهورة من الشرطة (+65🪙 غرامة)', 'danger');
        }
      },
      onPedestrianHit: (npc) => {
        audioSys.playSfx('siren');
        pushToast(`🚑 انتبه! كدت تصدم ${npc.name} — تم تحرير مخالفة مرورية (+85🪙)`, 'danger');
        dispatchEvent('v15_ticket_fine', { amount: 85 });
      },
      onStateMutated: () => {
        if (engineRef.current) setGameState({ ...engineRef.current['stateRef'] });
      },
      onGhostPlace: (blueprintId, islandId, x, z, ry) => {
        setGhostActive(false);
        audioSys.playSfx('build');
        dispatchEvent('v15_build_place', { blueprintId, islandId, x, z, ry });
        pushToast('🏗️ تم وضع أساس المبنى بنجاح! أكمل مراحل البناء من المخطط.', 'success');
      },
    });

    engineRef.current = eng;

    // Expose read-only & test helper bridge for automated Playwright E2E checks
    (window as any).__OSW_DEBUG__ = {
      getRoadAudit: () => eng.world.roadAudit,
      getPosition: () => ({ x: eng.playerX, z: eng.playerZ, island: islandAtPoint(eng.playerX, eng.playerZ).id }),
      teleport: (x: number, z: number) => eng.teleportTo(x, z),
      enterInterior: (id: string, floor = 0) => eng.enterInterior(id, floor),
      exitInterior: () => eng.exitInterior(),
      boardFirstVehicle: () => {
        const v = eng.vehicles.playerVehicles[0];
        if (v) eng.boardVehicle(v);
        return !!v;
      },
      getVehicleCount: () => eng.vehicles.playerVehicles.length,
      getActiveInterior: () => eng.interiors.activeInterior?.id || null,
    };

    return () => {
      eng.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entered]);

  const handleActionTrigger = useCallback(() => {
    const eng = engineRef.current;
    if (!eng) return;
    const res = eng.triggerNearestAction();
    if (!res) return;
    const act = res.action;

    if (act === 'enter:home_upper' && !gameState.questsCompleted.includes('q1_explore_villa')) {
      const q = QUESTS.find((x) => x.id === 'q1_explore_villa');
      if (q) dispatchEvent('v15_quest_done', { questId: q.id, rewardCoins: q.rewardCoins, rewardXp: q.rewardXp });
    }

    if (act.startsWith('open:')) {
      const parts = act.split(':');
      const rawTarget = parts[1];
      if (rawTarget === 'leisure') {
        audioSys.playSfx('fanfare');
        pushToast('🎡 استمتعت بجولة في مدينة الملاهي والشاطئ! (+20 طاقة)', 'gold');
        return;
      }
      const target = rawTarget as ModalId;
      if (target === 'factory' && parts[2]) setFactoryId(parts[2]);
      setModal(target);
    } else if (act.startsWith('gas:')) {
      const v = eng.activeVehicle || eng.vehicles.playerVehicles[0];
      if (v) {
        dispatchEvent('v15_veh_refuel', { vehUid: v.uid, cost: 25 });
        v.fuel = v.def.tankSize;
        audioSys.playSfx('coin');
        pushToast(`⛽ تم تزويد ${v.def.name} بالطاقة/الوقود 100%!`, 'success');
      }
    } else if (act.startsWith('dig:')) {
      const pool = ['art_sun_seal', 'art_glass_amphora', 'art_astrolabe', 'art_maritime_compass', 'art_royal_crown'];
      const pick = pool[Math.floor(Math.random() * pool.length)];
      dispatchEvent('v15_excavate', { artifactId: pick, spotId: act.slice(4) });
      audioSys.playSfx('fanfare');
      pushToast('⛏️ اكتشفت قطعة أثرية تاريخية نادرة! تفقد سجل الآثار والمتحف.', 'gold');
    } else if (act === 'action:sleep') {
      dispatchEvent('v15_sleep', {});
      audioSys.playSfx('fanfare');
      pushToast('🛏️ نمت جيداً واستعدت طاقتك 100%!', 'success');
    } else if (act === 'action:bbq') {
      dispatchEvent('v15_eat_meal', { cost: 0, food: 35, drink: 25 });
      audioSys.playSfx('coin');
      pushToast('🍖 شواء رائع في حديقة القصر! استعدت الشبع والطاقة.', 'success');
    } else if (act === 'action:heal') {
      dispatchEvent('v15_hospital_heal', {});
      audioSys.playSfx('fanfare');
      pushToast('🩺 تم الفحص والعلاج الشامل بنجاح!', 'success');
    } else if (act === 'catch_thief') {
      dispatchEvent('v15_thief_catch', {});
      audioSys.playSfx('fanfare');
      pushToast('👮 أحسنت! قبضت على اللص وحصلت على مكافأة +120🪙!', 'gold');
    } else if (act.startsWith('talk:')) {
      const npcId = act.slice(5);
      const npc = eng.npcs.npcs.find((n) => n.id === npcId);
      if (npc) {
        npc.rig.talkTimer = 3.5;
        npc.rig.gestureTimer = 2.5;
        setNpcDialog({ name: npc.name, emoji: npc.emoji, lines: npc.lines, action: npc.action });
      }
    }
  }, [dispatchEvent, gameState.questsCompleted, pushToast]);

  // Global E key listener for interaction
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if ((e.key.toLowerCase() === 'e' || e.code === 'KeyE') && entered && !modal) {
        handleActionTrigger();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [entered, modal, handleActionTrigger]);

  // ============ AUTH / 2-PLAYER ENTRY SCREEN ============
  if (!entered) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-950 p-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl space-y-5 text-center">
          <div className="text-5xl">🏰</div>
          <div>
            <h1 className="text-2xl font-extrabold text-amber-400">عالمنا الصغير V15</h1>
            <p className="text-sm text-slate-300 mt-1">عصر الحضارات الحية — THE LIVING CIVILIZATIONS</p>
          </div>
          <div className="space-y-2.5 text-right">
            <div className="text-xs text-slate-400 font-bold">اختر شخصيتك للدخول إلى العالم المشترك:</div>
            {store.users.map((u) => (
              <button
                key={u.id}
                onClick={() => {
                  audioSys.unlock();
                  setActiveUid(u.id);
                  setUidState(u.id);
                  setEntered(true);
                }}
                className="w-full flex items-center justify-between p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <span className="w-4 h-4 rounded-full inline-block" style={{ backgroundColor: u.color }} />
                  <span className="font-bold text-base text-slate-100">{u.name}</span>
                </div>
                <span className="text-xs text-amber-400 font-bold">دخول العالم ←</span>
              </button>
            ))}
          </div>
          <div className="text-[11px] text-slate-400 bg-slate-950/70 rounded-lg p-2.5 border border-slate-800">
            التحكم: WASD أو الأسهم للمشي/القيادة · سحب الماوس لتدوير الكاميرا · E للتفاعل وفتح الأبواب · V تغيير المنظور
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-hidden bg-slate-950">
      {/* 3D WebGL Viewport (occupies 100% canvas, >=85% unobstructed!) */}
      <div ref={mountRef} className="w-full h-full" />

      {/* Compact Top HUD Bar */}
      <div className="pointer-events-none fixed top-2.5 inset-x-3 z-20 flex flex-wrap items-center justify-between gap-2">
        {/* Player & Economy Readout */}
        <div className="pointer-events-auto flex items-center gap-2 bg-slate-950/90 border border-slate-700/80 rounded-xl px-3 py-1.5 shadow-lg">
          <span className="font-bold text-sm text-slate-100">{activeProfile.name}</span>
          <span className="font-mono-num text-sm font-bold text-amber-300">🪙 {gameState.coins.toLocaleString()}</span>
          <span className="hidden sm:inline text-xs text-slate-400">|</span>
          <span className="hidden sm:inline text-xs font-mono-num text-emerald-400">⚡ {Math.round(gameState.energy)}%</span>
          <span className="hidden sm:inline text-xs font-mono-num text-orange-300">🍞 {Math.round(gameState.hunger)}%</span>
          <span className="hidden md:inline text-xs text-slate-400">|</span>
          <span className="text-xs font-bold text-sky-300">{hudInfo.islandName}</span>
        </div>

        {/* Clean Action Dock */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-950/90 border border-slate-700/80 rounded-xl p-1 shadow-lg">
          <button onClick={() => setModal('map')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">🗺️ الخريطة</button>
          <button onClick={() => setModal('factory')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">🏭 المصانع</button>
          <button onClick={() => setModal('exchange')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">📈 البورصة</button>
          <button onClick={() => setModal('builder')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">🏗️ البناء</button>
          <button onClick={() => setModal('quests')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">🎯 المهام</button>
          <button onClick={() => setModal('settings')} className="px-2.5 py-1.5 rounded-lg hover:bg-slate-800 text-xs font-bold text-slate-100 cursor-pointer">⚙️</button>
        </div>
      </div>

      {/* Live Event Banner (only when active) */}
      {gameState.activeEvent && (
        <div className="pointer-events-none fixed top-16 left-1/2 -translate-x-1/2 z-20 bg-amber-950/90 border border-amber-500/50 text-amber-200 text-xs font-bold px-4 py-1.5 rounded-xl shadow">
          {gameState.activeEvent.title} — {gameState.activeEvent.desc}
        </div>
      )}

      {/* Toasts */}
      <div className="pointer-events-none fixed top-16 right-3 z-30 space-y-2 max-w-xs">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border shadow-lg ${
              t.tone === 'danger'
                ? 'bg-rose-950/95 border-rose-500 text-rose-200'
                : t.tone === 'gold'
                ? 'bg-amber-950/95 border-amber-500 text-amber-200'
                : t.tone === 'success'
                ? 'bg-emerald-950/95 border-emerald-500 text-emerald-200'
                : 'bg-slate-900/95 border-slate-700 text-slate-100'
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>

      {/* Vehicle Driving Telemetry Cluster */}
      {hudInfo.inVehicleName && (
        <div className="fixed bottom-4 left-4 z-20 bg-slate-950/90 border border-slate-700 rounded-xl px-4 py-2.5 space-y-1 shadow-xl">
          <div className="text-xs font-bold text-sky-300">{hudInfo.inVehicleName}</div>
          <div className="flex items-center gap-3 font-mono-num text-xs">
            <span>🏎️ {hudInfo.vehSpeed} كم/س</span>
            <span className={hudInfo.vehFuelPct < 20 ? 'text-rose-400' : 'text-emerald-400'}>⛽ {hudInfo.vehFuelPct}%</span>
            <span className={hudInfo.vehHealth < 40 ? 'text-rose-400' : 'text-amber-300'}>🛡️ {hudInfo.vehHealth}%</span>
          </div>
          <div className="flex gap-1.5 pt-1">
            <button
              onClick={() => engineRef.current?.exitVehicle()}
              className="px-2.5 py-1 rounded bg-rose-700 hover:bg-rose-600 text-white text-[11px] font-bold cursor-pointer"
            >
              نزول [F]
            </button>
            <button
              onClick={() => {
                if (engineRef.current?.activeVehicle) {
                  engineRef.current.activeVehicle.headlightsOn = !engineRef.current.activeVehicle.headlightsOn;
                }
              }}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] cursor-pointer"
            >
              أنوار [L]
            </button>
            <button
              onClick={() => audioSys.playSfx('horn')}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] cursor-pointer"
            >
              بوري [H]
            </button>
          </div>
        </div>
      )}

      {/* 3D Builder Ghost Confirmation Toolbar */}
      {ghostActive && (
        <div className="fixed bottom-16 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-slate-950/95 border border-amber-500/70 rounded-xl px-4 py-2.5 shadow-2xl">
          <span className="text-xs font-bold text-amber-300">تحرك لتحديد موقع المبنى</span>
          <button
            onClick={() => engineRef.current?.rotateBuildGhost()}
            className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold cursor-pointer"
          >
            تدوير [R] ↻
          </button>
          <button
            onClick={() => engineRef.current?.confirmBuildGhost()}
            className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
          >
            تثبيت البناء ✓
          </button>
          <button
            onClick={() => {
              engineRef.current?.cancelBuildGhost();
              setGhostActive(false);
            }}
            className="px-3 py-1 rounded-lg bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold cursor-pointer"
          >
            إلغاء ✕
          </button>
        </div>
      )}

      {/* Contextual Proximity Interaction Prompt */}
      {prompt && !modal && !npcDialog && (
        <button
          onClick={handleActionTrigger}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2.5 bg-slate-950/95 hover:bg-slate-900 border border-amber-500/80 text-slate-100 px-5 py-2.5 rounded-xl shadow-2xl cursor-pointer transition-transform active:scale-95"
        >
          <span className="text-lg">{prompt.emoji}</span>
          <span className="text-sm font-bold">{prompt.label}</span>
          <span className="font-mono-num text-xs bg-amber-500 text-slate-950 px-2 py-0.5 rounded font-bold">E</span>
        </button>
      )}

      {/* Quick Return to Exterior Button when inside any building */}
      {hudInfo.inInterior && !modal && (
        <button
          onClick={() => engineRef.current?.exitInterior()}
          className="fixed bottom-6 right-4 z-20 px-4 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold shadow-lg cursor-pointer"
        >
          🚪 الخروج من المبنى
        </button>
      )}

      {/* NPC Dialogue Popup */}
      {npcDialog && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-lg bg-slate-950/95 border border-amber-500/60 rounded-2xl p-4 shadow-2xl space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-400">
              {npcDialog.emoji} {npcDialog.name}
            </span>
            <button onClick={() => setNpcDialog(null)} className="text-xs text-slate-400 hover:text-white cursor-pointer">
              إغلاق ✕
            </button>
          </div>
          <p className="text-sm text-slate-100 leading-relaxed">
            {npcDialog.lines[Math.floor(Math.random() * npcDialog.lines.length)]}
          </p>
          {npcDialog.action && (
            <button
              onClick={() => {
                const act = npcDialog.action!;
                setNpcDialog(null);
                if (act.startsWith('enter:')) engineRef.current?.enterInterior(act.slice(6), 0);
                else if (act.startsWith('open:')) setModal(act.slice(5) as ModalId);
              }}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
            >
              فتح الخدمة المرتبطة ←
            </button>
          )}
        </div>
      )}

      {/* Interactive System Modals */}
      <GameModals
        modal={modal}
        factoryId={factoryId}
        state={gameState}
        profile={activeProfile}
        roadAudit={engineRef.current?.world.roadAudit || null}
        quality={quality}
        weather={weather}
        gameHour={hudInfo.gameHour}
        hqFloor={engineRef.current?.interiors.currentHqFloor || 0}
        onClose={() => setModal(null)}
        onDispatch={dispatchEvent}
        onTeleport={(x, z) => engineRef.current?.teleportTo(x, z)}
        onEnterInterior={(id, floor) => engineRef.current?.enterInterior(id, floor || 0)}
        onStartBuildGhost={(bpId) => {
          engineRef.current?.startBuildGhost(bpId);
          setGhostActive(true);
        }}
        onQualityChange={(q) => {
          setQuality(q);
          engineRef.current?.applyQuality(q);
        }}
        onWeatherChange={(w) => {
          setWeather(w);
          if (engineRef.current) engineRef.current.weather = w;
        }}
        onHourChange={(h) => {
          if (engineRef.current) {
            engineRef.current.autoCycleTime = false;
            engineRef.current.gameHour = h;
          }
        }}
        onProfileChange={(patch) => {
          const nextUsers = store.users.map((u) => (u.id === activeUid ? { ...u, ...patch } : u));
          const nextStore = { ...store, users: nextUsers };
          saveDemoStore(nextStore);
          setStore(nextStore);
          const updated = nextUsers.find((u) => u.id === activeUid);
          if (updated && engineRef.current) engineRef.current.refreshPlayerLook(updated);
        }}
        onResetSave={() => {
          localStorage.removeItem('osw_demo_v1');
          const fresh = loadDemoStore();
          setStore(fresh);
          const folded = foldGameState(fresh.entries);
          setGameState(folded);
          engineRef.current?.updateStateRef(folded);
          pushToast('🗑️ تم إعادة ضبط الحفظ بالكامل.', 'info');
        }}
        onExportSave={() => JSON.stringify(store, null, 2)}
        onImportSave={(json) => {
          try {
            const parsed = JSON.parse(json) as DemoStore;
            if (!parsed || !Array.isArray(parsed.entries)) return false;
            saveDemoStore(parsed);
            setStore(parsed);
            const folded = foldGameState(parsed.entries);
            setGameState(folded);
            engineRef.current?.updateStateRef(folded);
            pushToast('✅ تم استيراد الحفظ بنجاح!', 'success');
            return true;
          } catch {
            pushToast('❌ صيغة JSON غير صالحة.', 'danger');
            return false;
          }
        }}
      />
    </div>
  );
}
