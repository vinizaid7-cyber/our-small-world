import { FACTORIES, STOCK_COMPANIES } from '../data/catalog';
import { GameState } from '../data/storage';

const WORLD_EVENTS = [
  { id: 'ev_glass_boom', title: 'طفرة إعمار زجاجية!', desc: 'ارتفاع الطلب على ألواح الزجاج +35% في البورصة والتصدير' },
  { id: 'ev_harvest_fest', title: 'مهرجان الحصاد الذهبي', desc: 'إقبال كبير على المنتجات الزراعية والحيوانية' },
  { id: 'ev_port_rush', title: 'ذروة الملاحة البحرية', desc: 'زيادة عوائد التصدير عبر الميناء بنسبة +25%' },
  { id: 'ev_tech_summit', title: 'قمة التكنولوجيا والروبوتات', desc: 'ارتفاع أسهم مختبرات المستقبل والكهرباء' },
];

export class EconomySimulation {
  private stockTimer = 0;
  private eventTimer = 45;
  private dividendTimer = 60;

  /**
   * Advances real-time economy:
   * - Updates live Stock Market prices linked directly to factory production & city metrics
   * - Triggers periodic World Events
   * - Pays dividends & decays player hunger/thirst gently
   */
  public tick(
    dt: number,
    state: GameState,
    onEventNotify: (msg: string) => void,
    onDividend: (amount: number) => void
  ): boolean {
    let dirty = false;

    // Gentle needs decay
    state.hunger = Math.max(10, state.hunger - dt * 0.08);
    state.thirst = Math.max(10, state.thirst - dt * 0.11);

    // Stock Exchange dynamic calculation every 6 seconds
    this.stockTimer += dt;
    if (this.stockTimer >= 6) {
      this.stockTimer = 0;
      const now = Date.now();
      for (const comp of STOCK_COMPANIES) {
        let bias = 0;
        if (comp.linkedFactoryId) {
          const f = state.factories[comp.linkedFactoryId];
          if (f?.built) bias += 0.008;
          if (f?.activeJob) bias += 0.018;
        }
        if (comp.linkedSector === 'port' && state.shipments.some((s) => !s.claimed)) {
          bias += 0.02;
        }
        if (comp.linkedSector === 'agri' && Object.keys(state.farmPlots).length >= 3) {
          bias += 0.012;
        }
        if (comp.linkedSector === 'heritage' && state.artifactsExhibited.length >= 2) {
          bias += 0.015;
        }
        if (state.activeEvent?.id === 'ev_glass_boom' && comp.ticker === 'ALNOOR') bias += 0.04;
        if (state.activeEvent?.id === 'ev_tech_summit' && comp.ticker === 'TECHBOT') bias += 0.04;

        const prev = state.stockPrices[comp.ticker] || comp.basePrice;
        // Deterministic-feeling bounded oscillation + real industrial performance bias
        const wave = Math.sin(now / 19000 + comp.basePrice) * 0.025;
        const meanPull = (comp.basePrice * 1.1 - prev) * 0.002;
        const next = Math.max(12, Math.round((prev * (1 + wave + bias) + meanPull) * 10) / 10);

        state.stockPrices[comp.ticker] = next;
        const hist = state.stockHistory[comp.ticker] || [];
        hist.push(next);
        if (hist.length > 24) hist.shift();
        state.stockHistory[comp.ticker] = hist;
      }

      // Auto-complete factory batch indicator check
      for (const f of Object.values(state.factories)) {
        if (f.activeJob && now >= f.activeJob.endAt) {
          dirty = true;
        }
      }
      if (state.activeEvent && now >= state.activeEvent.endsAt) {
        state.activeEvent = null;
      }
      dirty = true;
    }

    // Dynamic City/Market Events
    this.eventTimer -= dt;
    if (this.eventTimer <= 0) {
      this.eventTimer = 95;
      const pick = WORLD_EVENTS[Math.floor(Math.random() * WORLD_EVENTS.length)];
      state.activeEvent = {
        ...pick,
        endsAt: Date.now() + 75000,
      };
      onEventNotify(`📣 حدث حي جديد: ${pick.title} — ${pick.desc}`);
      dirty = true;
    }

    // Stock Dividends + Museum Tourism payout every 60s
    this.dividendTimer -= dt;
    if (this.dividendTimer <= 0) {
      this.dividendTimer = 60;
      let totalDiv = 0;
      for (const comp of STOCK_COMPANIES) {
        const qty = state.stocksOwned[comp.ticker] || 0;
        if (qty > 0) {
          totalDiv += Math.round(qty * (state.stockPrices[comp.ticker] || comp.basePrice) * comp.dividendRate);
        }
      }
      totalDiv += state.artifactsExhibited.length * 10;
      if (totalDiv > 0) {
        state.coins += totalDiv;
        onDividend(totalDiv);
        dirty = true;
      }
    }

    return dirty;
  }
}

export function factoryPowerRequirement(state: GameState): number {
  let kw = 0;
  for (const f of Object.values(state.factories)) {
    if (f.built) {
      const def = FACTORIES[f.id];
      kw += def.zone === 'heavy' ? 30 : 15;
    }
  }
  return kw;
}
