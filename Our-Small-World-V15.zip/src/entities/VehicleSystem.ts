import * as THREE from 'three';
import { VEHICLES, VehicleDef } from '../data/catalog';
import { BUS_STOPS, ROADS } from '../data/islandsData';
import { OwnedVehicle } from '../data/storage';
import { audioSys } from '../engine/AudioSystem';
import { SpatialCollisionWorld } from '../engine/CollisionSystem';
import { addBox, addCyl, getMat } from '../world/MeshHelpers';

export interface VehicleInstance {
  uid: string;
  def: VehicleDef;
  group: THREE.Group;
  headlights: THREE.Mesh[];
  leftSignals: THREE.Mesh[];
  rightSignals: THREE.Mesh[];
  x: number;
  z: number;
  ry: number;
  speed: number;
  steer: number;
  fuel: number;
  health: number;
  headlightsOn: boolean;
  signal: -1 | 0 | 1;
}

export interface TrafficCar {
  id: string;
  group: THREE.Group;
  kind: 'sedan' | 'citybus' | 'schoolbus' | 'truck' | 'police';
  route: Array<[number, number]>;
  waypointIdx: number;
  x: number;
  z: number;
  ry: number;
  speed: number;
  pauseTimer: number;
}

export function buildVehicleMesh(def: VehicleDef, color: string): {
  group: THREE.Group;
  headlights: THREE.Mesh[];
  leftSignals: THREE.Mesh[];
  rightSignals: THREE.Mesh[];
} {
  const g = new THREE.Group();
  const W = def.width;
  const L = def.length;
  const H = def.height;

  const isBus = def.category === 'transit';
  const isTruck = def.category === 'truck' && L > 6;
  const isTractor = def.category === 'farm';

  // Chassis
  if (isBus) {
    addBox(g, 0, 0.45, 0, W, H - 0.5, L, color);
    addBox(g, 0, H - 1.15, 0, W + 0.04, 0.78, L - 0.8, '#93c5fd', { roughness: 0.15, opacity: 0.65, transparent: true });
    addBox(g, 0, H - 0.1, 0, W - 0.2, 0.18, L - 0.4, '#f8fafc');
  } else if (isTruck) {
    addBox(g, 0, 0.45, L * 0.28, W * 0.94, 1.8, L * 0.32, color);
    addBox(g, 0, 0.55, -L * 0.18, W, H - 0.6, L * 0.62, '#e2e8f0');
    addBox(g, 0, 1.4, L * 0.44, W * 0.86, 0.85, 0.1, '#93c5fd', { roughness: 0.15 });
  } else if (isTractor) {
    addBox(g, 0, 0.55, 0.2, W * 0.68, 0.9, L * 0.72, color);
    addBox(g, 0, 1.45, -0.4, W * 0.66, 0.95, 1.3, '#93c5fd', { transparent: true, opacity: 0.65 });
  } else {
    // Lower body
    addBox(g, 0, 0.35, 0, W, H * 0.42, L, color, { roughness: 0.32, metalness: 0.42 });
    // Cabin + visible interior seats/steering wheel
    addBox(g, 0, 0.35 + H * 0.42, -L * 0.06, W * 0.86, H * 0.44, L * 0.52, color, { roughness: 0.32, metalness: 0.4 });
    // Windshield & Rear window
    addBox(g, 0, 0.38 + H * 0.42, L * 0.20, W * 0.82, H * 0.36, 0.12, '#7dd3fc', { transparent: true, opacity: 0.65, roughness: 0.1 });
    addBox(g, 0, 0.38 + H * 0.42, -L * 0.32, W * 0.8, H * 0.34, 0.12, '#7dd3fc', { transparent: true, opacity: 0.65, roughness: 0.1 });
    // Side mirrors
    [-W / 2 - 0.1, W / 2 + 0.1].forEach((mx) => addBox(g, mx, 0.85, L * 0.16, 0.18, 0.12, 0.22, '#1e293b'));
  }

  // Police / Ambulance Roof Lightbar
  if (def.id === 'police' || def.id === 'ambulance') {
    addBox(g, -0.35, H + 0.05, 0, 0.55, 0.18, 0.35, '#2563eb', { emissive: '#3b82f6', emissiveIntensity: 0.9 });
    addBox(g, 0.35, H + 0.05, 0, 0.55, 0.18, 0.35, '#dc2626', { emissive: '#ef4444', emissiveIntensity: 0.9 });
  }

  // Wheels (4 or 6)
  const wheelZ = isBus || isTruck ? [-L * 0.34, L * 0.34] : [-L * 0.32, L * 0.32];
  wheelZ.forEach((wz, idx) => {
    const r = isTractor && idx === 0 ? 0.65 : 0.38;
    [-W / 2 - 0.04, W / 2 + 0.04].forEach((wx) => {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.28, 12), getMat('#111827', { roughness: 0.9 }));
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(wx, r, wz);
      wheel.castShadow = true;
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.55, r * 0.55, 0.3, 8), getMat('#cbd5e1', { metalness: 0.7 }));
      rim.rotation.z = Math.PI / 2;
      rim.position.copy(wheel.position);
      g.add(wheel, rim);
    });
  });

  // License plate
  addBox(g, 0, 0.42, L / 2 + 0.02, 0.55, 0.16, 0.04, '#f8fafc');
  addBox(g, 0, 0.42, -L / 2 - 0.02, 0.55, 0.16, 0.04, '#f8fafc');

  // Headlights & Turn Signals
  const headlights: THREE.Mesh[] = [];
  const leftSignals: THREE.Mesh[] = [];
  const rightSignals: THREE.Mesh[] = [];
  [-W * 0.34, W * 0.34].forEach((hx, i) => {
    const hl = addBox(g, hx, 0.62, L / 2 + 0.03, 0.28, 0.16, 0.06, '#fef9c3', {
      emissive: '#fef08a',
      emissiveIntensity: 0.3,
    });
    headlights.push(hl);

    const sig = addBox(g, hx * 1.15, 0.58, L / 2 + 0.03, 0.14, 0.14, 0.06, '#f59e0b', {
      emissive: '#f59e0b',
      emissiveIntensity: 0,
    });
    if (i === 0) rightSignals.push(sig);
    else leftSignals.push(sig);
  });

  return { group: g, headlights, leftSignals, rightSignals };
}

export class VehicleManager {
  public playerVehicles: VehicleInstance[] = [];
  public traffic: TrafficCar[] = [];
  public exportTruck: { group: THREE.Group; active: boolean; progress: number } | null = null;
  public group = new THREE.Group();
  private lastCollisionToastAt = 0;

  constructor(scene: THREE.Scene) {
    this.group.name = 'OSW_Vehicles';
    scene.add(this.group);
    this.spawnTrafficAndBuses();
  }

  public syncOwnedVehicles(owned: OwnedVehicle[]): void {
    // Keep existing physics positions for matching UIDs, add new ones, remove deleted
    const existing = new Map(this.playerVehicles.map((v) => [v.uid, v]));
    const nextList: VehicleInstance[] = [];

    for (const o of owned) {
      const prev = existing.get(o.uid);
      if (prev) {
        prev.fuel = o.fuel;
        prev.health = o.health;
        nextList.push(prev);
        existing.delete(o.uid);
      } else {
        const def = VEHICLES[o.defId] || VEHICLES.sedan;
        const built = buildVehicleMesh(def, o.color || def.defaultColor);
        built.group.position.set(o.x, 0, o.z);
        built.group.rotation.y = o.ry;
        this.group.add(built.group);
        nextList.push({
          uid: o.uid,
          def,
          group: built.group,
          headlights: built.headlights,
          leftSignals: built.leftSignals,
          rightSignals: built.rightSignals,
          x: o.x,
          z: o.z,
          ry: o.ry,
          speed: 0,
          steer: 0,
          fuel: o.fuel,
          health: o.health,
          headlightsOn: false,
          signal: 0,
        });
      }
    }
    existing.forEach((v) => this.group.remove(v.group));
    this.playerVehicles = nextList;
  }

  private spawnTrafficAndBuses(): void {
    // Active City Bus loop connecting bus stops across islands!
    const busDef = VEHICLES.citybus;
    const busMesh = buildVehicleMesh(busDef, '#0284c7');
    const busRoute: Array<[number, number]> = [
      [0, 42],
      [130, 42],
      [195, 130],
      [360, 130],
      [360, 325],
      [270, 405],
      [270, 600],
      [65, 600],
      [-265, 670],
      [-480, 670],
      [-480, 460],
      [-420, 405],
      [-420, 230],
      [-265, 230],
      [-130, 42],
      [0, 42],
    ];
    busMesh.group.position.set(busRoute[0][0], 0, busRoute[0][1]);
    this.group.add(busMesh.group);
    this.traffic.push({
      id: 'traffic_citybus',
      group: busMesh.group,
      kind: 'citybus',
      route: busRoute,
      waypointIdx: 1,
      x: busRoute[0][0],
      z: busRoute[0][1],
      ry: 0,
      speed: 14,
      pauseTimer: 0,
    });

    // School Bus loop between Home, City, and Life University!
    const sbMesh = buildVehicleMesh(VEHICLES.schoolbus, '#f59e0b');
    const sbRoute: Array<[number, number]> = [
      [-60, 42],
      [0, 42],
      [0, 130],
      [270, 405],
      [270, 600],
      [700, 600],
      [270, 600],
      [270, 405],
      [0, 130],
      [0, 42],
    ];
    sbMesh.group.position.set(sbRoute[0][0], 0, sbRoute[0][1]);
    this.group.add(sbMesh.group);
    this.traffic.push({
      id: 'traffic_schoolbus',
      group: sbMesh.group,
      kind: 'schoolbus',
      route: sbRoute,
      waypointIdx: 1,
      x: sbRoute[0][0],
      z: sbRoute[0][1],
      ry: 0,
      speed: 13,
      pauseTimer: 0,
    });

    // Police Cruiser patrolling ISL_CITY
    const polMesh = buildVehicleMesh(VEHICLES.police, '#1e293b');
    const polRoute: Array<[number, number]> = [
      [270, 465],
      [270, 740],
      [270, 600],
      [390, 600],
      [150, 600],
      [270, 600],
    ];
    polMesh.group.position.set(polRoute[0][0], 0, polRoute[0][1]);
    this.group.add(polMesh.group);
    this.traffic.push({
      id: 'traffic_police',
      group: polMesh.group,
      kind: 'police',
      route: polRoute,
      waypointIdx: 1,
      x: polRoute[0][0],
      z: polRoute[0][1],
      ry: 0,
      speed: 15,
      pauseTimer: 0,
    });

    // Export Cargo Truck from Industry -> Port!
    const trMesh = buildVehicleMesh(VEHICLES.boxtruck, '#2563eb');
    trMesh.group.visible = false;
    this.group.add(trMesh.group);
    this.exportTruck = { group: trMesh.group, active: false, progress: 0 };
  }

  public findNearestVehicle(x: number, z: number, maxDist = 5.5): VehicleInstance | null {
    let best: VehicleInstance | null = null;
    let bd = maxDist;
    for (const v of this.playerVehicles) {
      const d = Math.hypot(v.x - x, v.z - z);
      if (d < bd) {
        bd = d;
        best = v;
      }
    }
    return best;
  }

  public driveActiveVehicle(
    veh: VehicleInstance,
    dt: number,
    elapsed: number,
    input: { throttle: number; steer: number; brake: boolean; honk: boolean },
    isNight: boolean,
    collision: SpatialCollisionWorld,
    onCrash: (veh: VehicleInstance, impactSpeed: number, target: string) => void
  ): void {
    // Fuel check
    const hasFuel = veh.fuel > 0.2;
    const accel = hasFuel ? veh.def.accel : 0;
    const maxSpd = veh.def.topSpeed * (veh.health < 35 ? 0.55 : 1);

    if (input.throttle !== 0 && hasFuel) {
      veh.speed += input.throttle * accel * dt;
      veh.fuel = Math.max(0, veh.fuel - veh.def.fuelBurnPerSec * Math.abs(input.throttle) * dt);
    } else {
      veh.speed *= Math.max(0, 1 - dt * 2.2);
    }

    if (input.brake) {
      veh.speed *= Math.max(0, 1 - dt * 6.5);
    }
    veh.speed = Math.max(-maxSpd * 0.45, Math.min(maxSpd, veh.speed));

    if (Math.abs(veh.speed) > 0.4) {
      const turnDir = veh.speed >= 0 ? 1 : -1;
      veh.ry += input.steer * turnDir * 2.2 * dt;
    }

    const prevX = veh.x;
    const prevZ = veh.z;
    const nx = veh.x + Math.sin(veh.ry) * veh.speed * dt;
    const nz = veh.z + Math.cos(veh.ry) * veh.speed * dt;

    // 1. Strict Building & Water Collision
    const radius = Math.max(1.2, veh.def.width * 0.62);
    const res = collision.resolveCircle(nx, nz, radius, prevX, prevZ, true);
    veh.x = res.x;
    veh.z = res.z;

    if (res.hitId && Math.abs(veh.speed) > 6.5) {
      const impact = Math.abs(veh.speed);
      veh.speed *= -0.25;
      if (elapsed - this.lastCollisionToastAt > 1.2) {
        this.lastCollisionToastAt = elapsed;
        audioSys.playSfx('crash');
        onCrash(veh, impact, res.hitId);
      }
    } else if (res.hitId) {
      veh.speed *= 0.4;
    }

    // 2. Strict Vehicle-vs-Traffic Vehicle Collision!
    for (const tc of this.traffic) {
      const d = Math.hypot(veh.x - tc.x, veh.z - tc.z);
      const minD = radius + (tc.kind.includes('bus') ? 2.4 : 1.7);
      if (d < minD) {
        const pushX = d > 0.01 ? (veh.x - tc.x) / d : 1;
        const pushZ = d > 0.01 ? (veh.z - tc.z) / d : 0;
        veh.x = tc.x + pushX * minD;
        veh.z = tc.z + pushZ * minD;
        if (Math.abs(veh.speed) > 5.5 && elapsed - this.lastCollisionToastAt > 1.2) {
          this.lastCollisionToastAt = elapsed;
          audioSys.playSfx('crash');
          onCrash(veh, Math.abs(veh.speed), tc.id);
        }
        veh.speed *= -0.2;
      }
    }

    veh.group.position.set(veh.x, 0, veh.z);
    veh.group.rotation.y = veh.ry;

    // Headlights & Turn Signals
    const hlIntensity = veh.headlightsOn || isNight ? 1.5 : 0.2;
    veh.headlights.forEach((m) => {
      (m.material as THREE.MeshStandardMaterial).emissiveIntensity = hlIntensity;
    });
    const blinkOn = Math.floor(elapsed * 3) % 2 === 0;
    veh.leftSignals.forEach((m) => {
      (m.material as THREE.MeshStandardMaterial).emissiveIntensity = veh.signal === -1 && blinkOn ? 1.8 : 0;
    });
    veh.rightSignals.forEach((m) => {
      (m.material as THREE.MeshStandardMaterial).emissiveIntensity = veh.signal === 1 && blinkOn ? 1.8 : 0;
    });
  }

  public updateTrafficAndExports(
    dt: number,
    playerX: number,
    playerZ: number,
    exportingActive: boolean
  ): void {
    // Autonomous buses & police patrol with stop pauses & player braking!
    for (const tc of this.traffic) {
      if (tc.pauseTimer > 0) {
        tc.pauseTimer -= dt;
        continue;
      }
      // Slow/stop if player is directly in front
      const distPlayer = Math.hypot(playerX - tc.x, playerZ - tc.z);
      if (distPlayer < 6.5) continue;

      const target = tc.route[tc.waypointIdx];
      const dx = target[0] - tc.x;
      const dz = target[1] - tc.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 2.2) {
        tc.waypointIdx = (tc.waypointIdx + 1) % tc.route.length;
        // Pause briefly at bus stops!
        if (tc.kind === 'citybus' || tc.kind === 'schoolbus') {
          const nearStop = BUS_STOPS.some((b) => Math.hypot(b.x - tc.x, b.z - tc.z) < 28);
          if (nearStop) tc.pauseTimer = 3.0;
        }
      } else {
        const step = Math.min(dist, tc.speed * dt);
        tc.x += (dx / dist) * step;
        tc.z += (dz / dist) * step;
        tc.ry = Math.atan2(dx, dz);
        tc.group.position.set(tc.x, 0, tc.z);
        tc.group.rotation.y = tc.ry;
      }
    }

    // Export Cargo Truck animation from Industry -> Port pier
    if (this.exportTruck) {
      if (exportingActive) {
        this.exportTruck.group.visible = true;
        this.exportTruck.progress = (this.exportTruck.progress + dt * 0.08) % 1;
        const pts: Array<[number, number]> = [
          [315, 130],
          [270, 405],
          [270, 600],
          [-265, 670],
          [-480, 670],
          [-440, 1110],
          [-580, 1110],
        ];
        const segFloat = this.exportTruck.progress * (pts.length - 1);
        const i = Math.min(pts.length - 2, Math.floor(segFloat));
        const f = segFloat - i;
        const x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f;
        const z = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f;
        const ry = Math.atan2(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
        this.exportTruck.group.position.set(x, 0, z);
        this.exportTruck.group.rotation.y = ry;
      } else {
        this.exportTruck.group.visible = false;
      }
    }
  }
}

export function roadClearCheckSample(): number {
  return ROADS.length;
}
