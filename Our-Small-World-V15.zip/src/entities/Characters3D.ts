import * as THREE from 'three';
import { getMat } from '../world/MeshHelpers';

export interface CharacterLook {
  gender: 'boy' | 'girl';
  shirtColor: string;
  pantsColor?: string;
  skinColor?: string;
  hairColor?: string;
  hairStyle?: 'short' | 'long' | 'ponytail' | 'cap';
  role?: 'citizen' | 'child' | 'worker' | 'police' | 'doctor' | 'waiter' | 'merchant' | 'elder' | 'thief';
  scale?: number;
}

export interface CharacterRig {
  root: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  mouth: THREE.Mesh;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  blinkTimer: number;
  talkTimer: number;
  gestureTimer: number;
}

export function createCharacterRig(look: CharacterLook): CharacterRig {
  const root = new THREE.Group();
  const isChild = look.role === 'child';
  const scale = look.scale ?? (isChild ? 0.72 : 1.0);
  root.scale.setScalar(scale);

  const skin = look.skinColor || '#f2c8a2';
  const shirt =
    look.role === 'police'
      ? '#1e3a8a'
      : look.role === 'doctor'
      ? '#f8fafc'
      : look.role === 'worker'
      ? '#f59e0b'
      : look.role === 'waiter'
      ? '#f8fafc'
      : look.role === 'thief'
      ? '#18181b'
      : look.shirtColor;
  const pants = look.pantsColor || (look.role === 'police' ? '#0f172a' : '#334155');
  const hairCol = look.role === 'elder' ? '#e2e8f0' : look.hairColor || '#231811';

  // Legs (hips at y = 0.78)
  const makeLeg = (x: number): THREE.Group => {
    const g = new THREE.Group();
    g.position.set(x, 0.78, 0);
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.72, 0.24), getMat(pants));
    leg.position.y = -0.36;
    leg.castShadow = true;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.14, 0.34), getMat('#111827'));
    shoe.position.set(0, -0.71, 0.05);
    g.add(leg, shoe);
    root.add(g);
    return g;
  };
  const leftLeg = makeLeg(-0.14);
  const rightLeg = makeLeg(0.14);

  // Torso (y = 0.78 .. 1.46)
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.68, 0.32), getMat(shirt));
  torso.position.y = 1.12;
  torso.castShadow = true;
  root.add(torso);

  if (look.role === 'worker') {
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.42, 0.34), getMat('#facc15', { emissive: '#ca8a04', emissiveIntensity: 0.15 }));
    vest.position.y = 1.12;
    root.add(vest);
  } else if (look.role === 'doctor') {
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.03), getMat('#ef4444'));
    badge.position.set(0.14, 1.24, 0.17);
    root.add(badge);
  } else if (look.role === 'waiter') {
    const apron = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.48, 0.05), getMat('#7f1d1d'));
    apron.position.set(0, 0.96, 0.16);
    root.add(apron);
  }

  // Arms
  const makeArm = (x: number): THREE.Group => {
    const g = new THREE.Group();
    g.position.set(x, 1.38, 0);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.42, 0.18), getMat(shirt));
    sleeve.position.y = -0.21;
    sleeve.castShadow = true;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.095, 8, 8), getMat(skin));
    hand.position.y = -0.47;
    g.add(sleeve, hand);
    root.add(g);
    return g;
  };
  const leftArm = makeArm(-0.39);
  const rightArm = makeArm(0.39);

  // Expressive Head (y = 1.72)
  const head = new THREE.Group();
  head.position.set(0, 1.72, 0);
  const skull = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.46, 0.44), getMat(skin));
  skull.castShadow = true;
  head.add(skull);

  // Eyes (sclera + pupils) + Eyelids (blinking) + Eyebrows
  const eyeGeo = new THREE.BoxGeometry(0.09, 0.09, 0.03);
  const pupilGeo = new THREE.BoxGeometry(0.05, 0.05, 0.035);
  const lidGeo = new THREE.BoxGeometry(0.1, 0.09, 0.04);
  const browGeo = new THREE.BoxGeometry(0.11, 0.028, 0.03);

  const lEye = new THREE.Mesh(eyeGeo, getMat('#ffffff'));
  lEye.position.set(-0.11, 0.04, 0.22);
  const rEye = new THREE.Mesh(eyeGeo, getMat('#ffffff'));
  rEye.position.set(0.11, 0.04, 0.22);

  const lPupil = new THREE.Mesh(pupilGeo, getMat('#0f172a'));
  lPupil.position.set(-0.11, 0.04, 0.23);
  const rPupil = new THREE.Mesh(pupilGeo, getMat('#0f172a'));
  rPupil.position.set(0.11, 0.04, 0.23);

  const leftEyelid = new THREE.Mesh(lidGeo, getMat(skin));
  leftEyelid.position.set(-0.11, 0.085, 0.235);
  leftEyelid.scale.y = 0.05;
  const rightEyelid = new THREE.Mesh(lidGeo, getMat(skin));
  rightEyelid.position.set(0.11, 0.085, 0.235);
  rightEyelid.scale.y = 0.05;

  const lBrow = new THREE.Mesh(browGeo, getMat(hairCol));
  lBrow.position.set(-0.11, 0.115, 0.225);
  const rBrow = new THREE.Mesh(browGeo, getMat(hairCol));
  rBrow.position.set(0.11, 0.115, 0.225);

  // Nose & Mouth
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.065, 0.06), getMat('#dca77d'));
  nose.position.set(0, -0.02, 0.23);

  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.04, 0.03), getMat('#991b1b'));
  mouth.position.set(0, -0.11, 0.225);

  head.add(lEye, rEye, lPupil, rPupil, leftEyelid, rightEyelid, lBrow, rBrow, nose, mouth);

  // Hair / Headwear
  if (look.role === 'worker') {
    const hat = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), getMat('#fbbf24'));
    hat.position.y = 0.12;
    head.add(hat);
  } else if (look.role === 'police') {
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.25, 0.16, 12), getMat('#1e3a8a'));
    cap.position.y = 0.24;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.04, 0.18), getMat('#0f172a'));
    visor.position.set(0, 0.17, 0.2);
    head.add(cap, visor);
  } else if (look.hairStyle === 'long' || look.gender === 'girl') {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.48), getMat(hairCol));
    top.position.y = 0.22;
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.56, 0.16), getMat(hairCol));
    back.position.set(0, -0.06, -0.18);
    head.add(top, back);
  } else {
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.49, 0.14, 0.47), getMat(hairCol));
    top.position.y = 0.22;
    head.add(top);
  }

  root.add(head);

  return {
    root,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    mouth,
    leftEyelid,
    rightEyelid,
    blinkTimer: Math.random() * 4,
    talkTimer: 0,
    gestureTimer: 0,
  };
}

export function animateCharacterRig(rig: CharacterRig, speed: number, dt: number, elapsed: number): void {
  // Walk / Run cycle
  const moving = speed > 0.25;
  if (moving) {
    const freq = Math.min(14, 5 + speed * 1.1);
    const swing = Math.sin(elapsed * freq) * 0.65;
    rig.leftLeg.rotation.x = swing;
    rig.rightLeg.rotation.x = -swing;
    rig.leftArm.rotation.x = -swing * 0.8;
    rig.rightArm.rotation.x = swing * 0.8;
  } else {
    rig.leftLeg.rotation.x *= 0.85;
    rig.rightLeg.rotation.x *= 0.85;
    rig.leftArm.rotation.x *= 0.85;
    rig.rightArm.rotation.x *= 0.85;
  }

  // Hand gesture while talking
  if (rig.gestureTimer > 0) {
    rig.gestureTimer -= dt;
    rig.rightArm.rotation.x = -0.8 + Math.sin(elapsed * 9) * 0.35;
    rig.leftArm.rotation.x = -0.35 + Math.cos(elapsed * 7) * 0.2;
  }

  // Talking mouth animation
  if (rig.talkTimer > 0) {
    rig.talkTimer -= dt;
    rig.mouth.scale.y = 1 + Math.abs(Math.sin(elapsed * 16)) * 2.2;
  } else {
    rig.mouth.scale.y = 1;
  }

  // Natural blinking
  rig.blinkTimer -= dt;
  if (rig.blinkTimer <= 0) {
    if (rig.blinkTimer > -0.14) {
      rig.leftEyelid.scale.y = 1.0;
      rig.rightEyelid.scale.y = 1.0;
    } else {
      rig.leftEyelid.scale.y = 0.05;
      rig.rightEyelid.scale.y = 0.05;
      rig.blinkTimer = 2.6 + Math.random() * 3.5;
    }
  }
}
