import * as THREE from 'three';
import { BUS_STOPS, IslandId, ISLANDS } from '../data/islandsData';
import { SpatialCollisionWorld } from '../engine/CollisionSystem';
import { animateCharacterRig, CharacterLook, CharacterRig, createCharacterRig } from './Characters3D';

export interface NPCEntity {
  id: string;
  name: string;
  emoji: string;
  islandId: IslandId;
  role: CharacterLook['role'];
  rig: CharacterRig;
  x: number;
  z: number;
  ry: number;
  homeX: number;
  homeZ: number;
  workX: number;
  workZ: number;
  targetX: number;
  targetZ: number;
  speed: number;
  lines: string[];
  waitingAtBusStop?: string;
  scaredTimer: number;
  isThief?: boolean;
  isPursuer?: boolean;
  action?: string;
}

export class NPCManager {
  public npcs: NPCEntity[] = [];
  public group = new THREE.Group();
  private thiefCooldown = 25;

  constructor(scene: THREE.Scene) {
    this.group.name = 'OSW_NPCs';
    scene.add(this.group);
    this.populateAllCivilizations();
  }

  private addNPC(cfg: {
    id: string;
    name: string;
    emoji: string;
    islandId: IslandId;
    role: CharacterLook['role'];
    gender: 'boy' | 'girl';
    shirtColor: string;
    x: number;
    z: number;
    workX: number;
    workZ: number;
    lines: string[];
    action?: string;
    waitingAtBusStop?: string;
  }): void {
    const rig = createCharacterRig({
      gender: cfg.gender,
      shirtColor: cfg.shirtColor,
      role: cfg.role,
    });
    rig.root.position.set(cfg.x, 0, cfg.z);
    this.group.add(rig.root);

    this.npcs.push({
      id: cfg.id,
      name: cfg.name,
      emoji: cfg.emoji,
      islandId: cfg.islandId,
      role: cfg.role,
      rig,
      x: cfg.x,
      z: cfg.z,
      ry: 0,
      homeX: cfg.x,
      homeZ: cfg.z,
      workX: cfg.workX,
      workZ: cfg.workZ,
      targetX: cfg.x,
      targetZ: cfg.z,
      speed: cfg.role === 'child' ? 2.6 : 1.9,
      lines: cfg.lines,
      scaredTimer: 0,
      waitingAtBusStop: cfg.waitingAtBusStop,
      action: cfg.action,
    });
  }

  private populateAllCivilizations(): void {
    // 1. ISL_HOME Citizens & Saadoun Merchant
    this.addNPC({
      id: 'npc_saadoun',
      name: 'العم سعدون',
      emoji: '🧔',
      islandId: 'ISL_HOME',
      role: 'merchant',
      gender: 'boy',
      shirtColor: '#b45309',
      x: -54,
      z: 30,
      workX: -54,
      workZ: 28,
      lines: ['أهلاً بك في سوق سعدون التراثي الجديد!', 'كل ما تحتاجه من بذور وطعام وهدايا متوفر هنا.', 'الشوارع الآن نظيفة ومفتوحة لسيارتك.'],
      action: 'enter:saadoun_shop',
    });
    this.addNPC({
      id: 'npc_home_child1',
      name: 'رامي الصغير',
      emoji: '🧒',
      islandId: 'ISL_HOME',
      role: 'child',
      gender: 'boy',
      shirtColor: '#38bdf8',
      x: -64,
      z: 56,
      workX: -48,
      workZ: 56,
      lines: ['أنا ألعب في حديقة الجوار!', 'هل جربت قيادة السيارة الجديدة؟'],
    });
    this.addNPC({
      id: 'npc_home_elder',
      name: 'الحجّة أم طارق',
      emoji: '👵',
      islandId: 'ISL_HOME',
      role: 'elder',
      gender: 'girl',
      shirtColor: '#7c3aed',
      x: 56,
      z: 54,
      workX: 60,
      workZ: 32,
      lines: ['صباح الخير يا بني، القصر العائلي أصبح تحفة معمارية!', 'لا تنسَ زيارة الجزر الست واكتشاف حضاراتها.'],
    });

    // 2. ISL_BUSINESS Merchants, Brokers & Bankers
    this.addNPC({
      id: 'npc_broker',
      name: 'الوسيط المالي طارق',
      emoji: '📈',
      islandId: 'ISL_BUSINESS',
      role: 'merchant',
      gender: 'boy',
      shirtColor: '#1e293b',
      x: -420,
      z: 178,
      workX: -420,
      workZ: 174,
      lines: ['سوق البورصة يتابع أداء مصانعك في الجزيرة الصناعية لحظة بلحظة!', 'ادخل قاعة البورصة وشاهد لوحة الأسعار المباشرة.'],
      action: 'enter:biz_exchange',
    });
    this.addNPC({
      id: 'npc_banker',
      name: 'المديرة سلمى (البنك)',
      emoji: '🏦',
      islandId: 'ISL_BUSINESS',
      role: 'citizen',
      gender: 'girl',
      shirtColor: '#0369a1',
      x: -382,
      z: 194,
      workX: -376,
      workZ: 190,
      lines: ['نرحب بك في البنك المركزي.', 'يمكنك إيداع مدخراتك أو أخذ تمويل لتوسيع مصانعك.'],
      action: 'enter:biz_bank',
    });

    // 3. ISL_PORT Sailors & Customs Officer
    this.addNPC({
      id: 'npc_captain',
      name: 'القبطان بحري',
      emoji: '⚓',
      islandId: 'ISL_PORT',
      role: 'worker',
      gender: 'boy',
      shirtColor: '#0284c7',
      x: -505,
      z: 1090,
      workX: -520,
      workZ: 1095,
      lines: ['السفينة جاهزة في الرصيف لتصدير منتجات الزجاج والفولاذ!', 'راقب الرافعة عند إطلاق شحنة التصدير.'],
      action: 'open:port',
    });
    this.addNPC({
      id: 'npc_port_worker',
      name: 'عامل الرصيف',
      emoji: '📦',
      islandId: 'ISL_PORT',
      role: 'worker',
      gender: 'boy',
      shirtColor: '#f59e0b',
      x: -460,
      z: 1118,
      workX: -560,
      workZ: 1105,
      lines: ['نحن نفرّغ الحاويات القادمة من أعالي البحار.'],
    });

    // 4. ISL_AGRI Farmers & Vet
    this.addNPC({
      id: 'npc_farmer1',
      name: 'المزارع أبو جابر',
      emoji: '🌾',
      islandId: 'ISL_AGRI',
      role: 'worker',
      gender: 'boy',
      shirtColor: '#15803d',
      x: -425,
      z: 645,
      workX: -450,
      workZ: 560,
      lines: ['النواعير تدور وتغذي قنوات الري بالماء العذب!', 'تفقد الحقول الـ36 وازرع ما تشاء.'],
      action: 'open:farm',
    });
    this.addNPC({
      id: 'npc_vet',
      name: 'الطبيبة البيطرية ريم',
      emoji: '🩺',
      islandId: 'ISL_AGRI',
      role: 'doctor',
      gender: 'girl',
      shirtColor: '#ffffff',
      x: -545,
      z: 645,
      workX: -545,
      workZ: 641,
      lines: ['حيوانات المزرعة بصحة ممتازة بفضل العناية المستمرة.'],
      action: 'enter:agri_vet',
    });

    // 5. ISL_INDUSTRY Glass Factory Engineer & Workers
    this.addNPC({
      id: 'npc_glass_eng',
      name: 'المهندس مازن (مصنع النور)',
      emoji: '🪟',
      islandId: 'ISL_INDUSTRY',
      role: 'worker',
      gender: 'boy',
      shirtColor: '#0284c7',
      x: 315,
      z: 98,
      workX: 315,
      workZ: 95,
      lines: ['أهلاً بك في مصنع النور لصناعة الزجاج!', 'الأفران تعمل على 1500 درجة مئوية. ادخل وشاهد خط الصهر والتلدين.'],
      action: 'enter:ind_glass',
    });
    this.addNPC({
      id: 'npc_steel_wrk',
      name: 'عامل الصلب خالد',
      emoji: '⚙️',
      islandId: 'ISL_INDUSTRY',
      role: 'worker',
      gender: 'boy',
      shirtColor: '#ea580c',
      x: 425,
      z: 98,
      workX: 425,
      workZ: 95,
      lines: ['الفولاذ الذي ننتجه ضروري لبناء الأبراج والجسور في المدينة.'],
      action: 'enter:ind_steel',
    });

    // 6. ISL_CITY Police Patrol, Doctor, Waiter, Thief & Citizens
    this.addNPC({
      id: 'npc_police_1',
      name: 'الضابط نبيل',
      emoji: '👮',
      islandId: 'ISL_CITY',
      role: 'police',
      gender: 'boy',
      shirtColor: '#1e3a8a',
      x: 245,
      z: 615,
      workX: 270,
      workZ: 590,
      lines: ['نحن نراقب سلامة السير والمشاة في المدينة.', 'التزم بالسرعة واحترم إشارات المشاة!'],
      action: 'enter:city_police',
    });
    this.addNPC({
      id: 'npc_doctor_city',
      name: 'د. هالة',
      emoji: '🩺',
      islandId: 'ISL_CITY',
      role: 'doctor',
      gender: 'girl',
      shirtColor: '#ffffff',
      x: 322,
      z: 550,
      workX: 328,
      workZ: 545,
      lines: ['مستشفى العاصمة جاهز للطوارئ والإسعاف على مدار الساعة.'],
      action: 'enter:city_hospital',
    });

    // 7. ISL_LIFE Scholar, Archaeologist, Children at Park/Beach
    this.addNPC({
      id: 'npc_scholar',
      name: 'البروفيسور فؤاد',
      emoji: '🎓',
      islandId: 'ISL_LIFE',
      role: 'elder',
      gender: 'boy',
      shirtColor: '#4338ca',
      x: 630,
      z: 562,
      workX: 630,
      workZ: 558,
      lines: ['العلم هو أساس نهضة الحضارات. افتح شجرة الأبحاث لتطوير الشبكات والروبوتات!'],
      action: 'open:tech',
    });
    this.addNPC({
      id: 'npc_life_child1',
      name: 'تالا',
      emoji: '👧',
      islandId: 'ISL_LIFE',
      role: 'child',
      gender: 'girl',
      shirtColor: '#ec4899',
      x: 765,
      z: 655,
      workX: 745,
      workZ: 705,
      lines: ['عجلة الملاهي والكاروسيل رائعان جداً!'],
    });

    // Waiting passengers at Bus Stops
    BUS_STOPS.slice(0, 5).forEach((bs, idx) => {
      this.addNPC({
        id: `npc_buswait_${bs.id}`,
        name: ['مسافر سمير', 'سارة', 'عمر', 'نور', 'ياسر'][idx],
        emoji: '🧳',
        islandId: bs.islandId,
        role: 'citizen',
        gender: idx % 2 === 0 ? 'boy' : 'girl',
        shirtColor: ['#0d9488', '#db2777', '#2563eb', '#9333ea', '#d97706'][idx],
        x: bs.x + (idx % 2 ? 1.2 : -1.2),
        z: bs.z + 1.2,
        workX: bs.x,
        workZ: bs.z + 1.5,
        lines: ['أنا بانتظار حافلة النقل العام للتنقل بين الجزر.'],
        waitingAtBusStop: bs.id,
      });
    });

    // Dynamic Thief & Pursuit Pair on ISL_CITY
    this.addNPC({
      id: 'npc_thief',
      name: 'لص هارب',
      emoji: '🦹',
      islandId: 'ISL_CITY',
      role: 'thief',
      gender: 'boy',
      shirtColor: '#18181b',
      x: 295,
      z: 625,
      workX: 250,
      workZ: 645,
      lines: ['ابتعد عن طريقي!'],
    });
    const thief = this.npcs[this.npcs.length - 1];
    thief.isThief = true;
    thief.speed = 4.6;
  }

  public update(
    dt: number,
    elapsed: number,
    gameHour: number,
    collision: SpatialCollisionWorld,
    playerCarPos: { x: number; z: number; speed: number; honking: boolean } | null,
    onPedestrianHit: (npc: NPCEntity) => void
  ): void {
    const isNight = gameHour >= 21 || gameHour < 6;
    const isWork = gameHour >= 8 && gameHour < 17;

    this.thiefCooldown -= dt;

    for (const n of this.npcs) {
      if (n.scaredTimer > 0) n.scaredTimer -= dt;

      // Thief dynamic fleeing from Police or Player!
      if (n.isThief) {
        const isl = ISLANDS[n.islandId];
        if (Math.hypot(n.x - n.targetX, n.z - n.targetZ) < 3) {
          const ang = Math.random() * Math.PI * 2;
          n.targetX = isl.cx + Math.cos(ang) * 75;
          n.targetZ = isl.cz + Math.sin(ang) * 75;
        }
      } else if (n.waitingAtBusStop) {
        // Stay neatly near bus shelter
        n.targetX = n.homeX;
        n.targetZ = n.homeZ;
      } else if (isWork) {
        n.targetX = n.workX + Math.sin(elapsed * 0.25 + n.homeX) * 4;
        n.targetZ = n.workZ + Math.cos(elapsed * 0.25 + n.homeZ) * 4;
      } else if (isNight) {
        n.targetX = n.homeX;
        n.targetZ = n.homeZ;
      } else {
        // Stroll around nearby
        n.targetX = n.homeX + Math.sin(elapsed * 0.18 + n.homeZ) * 8;
        n.targetZ = n.homeZ + Math.cos(elapsed * 0.18 + n.homeX) * 8;
      }

      // Pedestrian avoidance of approaching player vehicle!
      let curSpeed = n.speed;
      if (playerCarPos && !n.isThief) {
        const dx = n.x - playerCarPos.x;
        const dz = n.z - playerCarPos.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 10 && (playerCarPos.speed > 4 || playerCarPos.honking)) {
          // Dodge sideways away from vehicle
          const nx = dist > 0.1 ? dx / dist : 1;
          const nz = dist > 0.1 ? dz / dist : 0;
          n.targetX = n.x + nx * 8;
          n.targetZ = n.z + nz * 8;
          curSpeed = 5.2;
          n.scaredTimer = 2.0;
        }
        if (dist < 2.2 && playerCarPos.speed > 6.5 && n.scaredTimer <= 1.7) {
          n.scaredTimer = 4.0;
          onPedestrianHit(n);
        }
      }

      const dx = n.targetX - n.x;
      const dz = n.targetZ - n.z;
      const dist = Math.hypot(dx, dz);
      let moveSpd = 0;
      if (dist > 0.7) {
        const step = Math.min(dist, curSpeed * dt);
        const nx = n.x + (dx / dist) * step;
        const nz = n.z + (dz / dist) * step;
        const res = collision.resolveCircle(nx, nz, 0.45, n.x, n.z, true);
        n.x = res.x;
        n.z = res.z;
        n.ry = Math.atan2(dx, dz);
        moveSpd = curSpeed;
      }

      n.rig.root.position.set(n.x, 0, n.z);
      n.rig.root.rotation.y = n.ry;
      animateCharacterRig(n.rig, moveSpd, dt, elapsed);
    }
  }

  public findNearestNPC(x: number, z: number, maxDist = 4.5): NPCEntity | null {
    let best: NPCEntity | null = null;
    let bd = maxDist;
    for (const n of this.npcs) {
      const d = Math.hypot(n.x - x, n.z - z);
      if (d < bd) {
        bd = d;
        best = n;
      }
    }
    return best;
  }
}
