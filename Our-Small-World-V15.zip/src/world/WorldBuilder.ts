import * as THREE from 'three';
import { GameState } from '../data/storage';
import { RoadAuditReport, SpatialCollisionWorld } from '../engine/CollisionSystem';
import { getWaterTexture } from '../engine/Textures';
import { buildAllCivilizations, CivilizationsRefs, syncDynamicWorldMeshes } from './Civilizations';
import { buildHomeIsland, HomeIslandRefs } from './HomeIsland';
import { AnimatedDoor, AnimatedProp, getMat, InstancedNatureBuilder, InteractiveZone } from './MeshHelpers';

export interface WorldRefs {
  root: THREE.Group;
  ocean: THREE.Mesh;
  lampBulbMat: THREE.MeshStandardMaterial;
  home: HomeIslandRefs;
  civs: CivilizationsRefs;
  allDoors: AnimatedDoor[];
  allZones: InteractiveZone[];
  allAnims: AnimatedProp[];
  roadAudit: RoadAuditReport;
  syncState: (state: GameState) => void;
  toggleGarageGate: () => boolean;
  updateAnimations: (dt: number, elapsed: number, exportingActive: boolean) => void;
  updateLOD: (camX: number, camZ: number) => void;
}

export function buildEntireWorld(scene: THREE.Scene, collision: SpatialCollisionWorld): WorldRefs {
  collision.clear();
  const root = new THREE.Group();
  root.name = 'OSW_World_Root';

  // Vast Shimmering Ocean Plane (strictly at y = -0.82 below all beach/island geometry)
  const waterTex = getWaterTexture();
  const ocean = new THREE.Mesh(
    new THREE.PlaneGeometry(3600, 3600, 1, 1),
    getMat('#0e5a8a', { map: waterTex, roughness: 0.2, metalness: 0.16 })
  );
  ocean.rotation.x = -Math.PI / 2;
  ocean.position.set(0, -0.82, 520);
  ocean.receiveShadow = true;
  root.add(ocean);

  const nature = new InstancedNatureBuilder();
  const home = buildHomeIsland(root, collision, nature);
  const civs = buildAllCivilizations(root, collision, nature);
  const { lampBulbMat } = nature.build(root);

  scene.add(root);

  const allDoors = [...home.doors, ...civs.doors];
  const allZones = [...home.zones, ...civs.zones];
  const allAnims = [...home.anims, ...civs.anims];

  // Automated Road Integrity Verification at boot
  const roadAudit = collision.verifyWorldRoads();

  const toggleGarageGate = (): boolean => {
    home.garageGate.isOpen = !home.garageGate.isOpen;
    return home.garageGate.isOpen;
  };

  const syncState = (state: GameState): void => {
    syncDynamicWorldMeshes(civs.cropGroup, civs.placedGroup, collision, state);
  };

  const updateAnimations = (dt: number, elapsed: number, exportingActive: boolean): void => {
    // Gentle ocean wave ripple scroll
    waterTex.offset.x = (elapsed * 0.012) % 1;
    waterTex.offset.y = (elapsed * 0.008) % 1;

    // 1. Hinged doors smoothly interpolate toward open/closed target
    for (const d of allDoors) {
      const target = d.isOpen ? d.openAngle : d.closedAngle;
      d.pivot.rotation.y += (target - d.pivot.rotation.y) * Math.min(1, dt * 8);
    }

    // 2. Automated garage sliding gate
    const gateTargetX = home.garageGate.isOpen ? home.garageGate.openX : home.garageGate.closedX;
    home.garageGate.mesh.position.x += (gateTargetX - home.garageGate.mesh.position.x) * Math.min(1, dt * 5);

    // 3. Waterwheels, windmills, lighthouse, ferris wheel, carousel, ship & boat bobbing
    for (const a of allAnims) {
      if (a.kind === 'spinZ') a.mesh.rotation.z += a.speed * dt;
      else if (a.kind === 'spinY') a.mesh.rotation.y += a.speed * dt;
      else if (a.kind === 'bobY') a.mesh.position.y = (a.baseY ?? 0) + Math.sin(elapsed * a.speed + (a.phase ?? 0)) * (a.amp ?? 0.2);
      else if (a.kind === 'sway') a.mesh.rotation.y += Math.sin(elapsed * a.speed + (a.phase ?? 0)) * dt * 0.25;
    }

    // 4. Port Export animation: Crane swings container & ship departs gently!
    if (civs.portCraneHook && civs.portShipGroup) {
      if (exportingActive) {
        civs.portCraneHook.position.x = -22 + Math.sin(elapsed * 1.8) * 10;
        civs.portCraneHook.position.y = 14 + Math.cos(elapsed * 2.2) * 3;
        civs.portShipGroup.position.z = 1110 + Math.sin(elapsed * 0.6) * 28;
      } else {
        civs.portCraneHook.position.x += (-22 - civs.portCraneHook.position.x) * Math.min(1, dt * 3);
        civs.portCraneHook.position.y += (17 - civs.portCraneHook.position.y) * Math.min(1, dt * 3);
        civs.portShipGroup.position.z += (1110 - civs.portShipGroup.position.z) * Math.min(1, dt * 2);
      }
    }
  };

  // Proximity-based island LOD visibility to keep FPS ultra-smooth
  const updateLOD = (camX: number, camZ: number): void => {
    for (const [id, grp] of Object.entries(civs.islandGroups)) {
      if (id === 'ISL_HOME') {
        grp.visible = true;
        continue;
      }
      const box = grp.children[0];
      if (!box) continue;
      const dist = Math.hypot(camX - box.position.x, camZ - box.position.z);
      grp.visible = dist < 680;
    }
  };

  return {
    root,
    ocean,
    lampBulbMat,
    home,
    civs,
    allDoors,
    allZones,
    allAnims,
    roadAudit,
    syncState,
    toggleGarageGate,
    updateAnimations,
    updateLOD,
  };
}
