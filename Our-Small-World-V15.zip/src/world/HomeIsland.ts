import * as THREE from 'three';
import { SpatialCollisionWorld } from '../engine/CollisionSystem';
import { getCobblestoneTexture, getRoofTileTexture, getStoneTexture, makeSignTexture } from '../engine/Textures';
import {
  addArchitecturalTrim,
  addBalcony,
  addDetailedWindow,
  addFacadeWindows,
  addRooftopDetails,
  addShopAwning,
} from './BuildingDetails';
import {
  addBox,
  addCyl,
  addDome,
  addRoofPyramid,
  AnimatedDoor,
  AnimatedProp,
  createHingedDoor,
  createSignBoard,
  InstancedNatureBuilder,
  InteractiveZone,
} from './MeshHelpers';

export interface HomeIslandRefs {
  doors: AnimatedDoor[];
  zones: InteractiveZone[];
  anims: AnimatedProp[];
  garageGate: {
    mesh: THREE.Group;
    isOpen: boolean;
    closedX: number;
    openX: number;
    x: number;
    z: number;
  };
}

/**
 * Rebuilt Island 1 (ISL_HOME):
 * - Zero V14 clutter, zero vast empty voids, zero ground Z-fighting
 * - Rich 2-Story Luxury Villa with stone quoins, shutters, balconies, pergola & courtyard fountain
 * - Detailed Saadoun Heritage Market, Diwan Hall, 8 residential townhouses/cottages, Orchard Gazebo,
 *   Park Pond, Coastal Pier with sailboat, sidewalks, flowerbeds, hedges & benches
 */
export function buildHomeIsland(
  parent: THREE.Group,
  collision: SpatialCollisionWorld,
  nature: InstancedNatureBuilder
): HomeIslandRefs {
  const doors: AnimatedDoor[] = [];
  const zones: InteractiveZone[] = [];
  const anims: AnimatedProp[] = [];

  const stoneTex = getStoneTexture('#f3ebdb', 4);
  const cobbleTex = getCobblestoneTexture('#cfc2a8', 8);
  const roofTex = getRoofTileTexture('#9a3412', 5);

  // ================= 0. LANDSCAPED PAVED COURTYARD & SIDEWALKS (y: 0.01 -> 0.05, clear under roads y: 0.10) =================
  // Grand cobble courtyard in front of Villa & between Market / Diwan
  addBox(parent, 0, 0, 2, 148, 0.04, 62, '#d6cab2', { map: cobbleTex, roughness: 0.88, castShadow: false });
  // Southern village paved plaza strips flanking roads
  addBox(parent, -62, 0, 64, 72, 0.04, 24, '#cfc3ab', { map: cobbleTex, roughness: 0.9, castShadow: false });
  addBox(parent, 62, 0, 64, 72, 0.04, 24, '#cfc3ab', { map: cobbleTex, roughness: 0.9, castShadow: false });

  // ================= 1. GRAND 2-STORY LUXURY VILLA (0, -34) =================
  const villaGroup = new THREE.Group();
  villaGroup.position.set(0, 0, -34);

  // Raised marble terrace platform & multi-stepped front stairs
  addBox(villaGroup, 0, 0, 1.5, 34, 0.5, 25, '#e2d8c3', { map: cobbleTex });
  addBox(villaGroup, 0, 0.12, 14.5, 8.6, 0.36, 2.2, '#d4c8ae');
  addBox(villaGroup, 0, 0.28, 13.6, 7.6, 0.24, 1.6, '#e7dcc8');

  // Ground floor main structure (28 x 20 x 5.6) + detailed architectural trim + windows on ALL 4 sides
  addBox(villaGroup, 0, 0.5, 0, 28, 5.6, 20, '#f7f1e3', { map: stoneTex, roughness: 0.78 });
  addArchitecturalTrim(villaGroup, 28, 5.6, 20, 0.5, '#dfd3bc', '#b7a98f');

  // Second floor structure (inset with wrap-around terrace!)
  addBox(villaGroup, 0, 6.1, -1.5, 25, 5.0, 17, '#f9f4ea', { map: stoneTex, roughness: 0.75 });
  addArchitecturalTrim(villaGroup, 25, 5.0, 17, 6.1, '#dfd3bc', '#c7baa1');

  // Front & side balconies with balusters
  addBalcony(villaGroup, 0, 6.0, 7.0, 16, 3.4, 0, '#1e293b');
  addBalcony(villaGroup, -12.5, 6.0, -1.5, 8, 2.2, -Math.PI / 2, '#1e293b');
  addBalcony(villaGroup, 12.5, 6.0, -1.5, 8, 2.2, Math.PI / 2, '#1e293b');

  // Grand pitched terracotta tiled roof + dormer & chimney
  addRoofPyramid(villaGroup, 0, 11.1, -1.5, 26.8, 4.4, 18.8, '#9a3412', { map: roofTex });
  addBox(villaGroup, 0, 11.2, 5.2, 4.8, 2.2, 3.6, '#f9f4ea', { map: stoneTex });
  addRoofPyramid(villaGroup, 0, 13.4, 5.2, 5.4, 1.4, 4.0, '#7c2d12');
  addDetailedWindow(villaGroup, 0, 11.7, 7.02, 2.2, 1.3, 0, { lit: true });
  addRooftopDetails(villaGroup, 24, 11.1, 16, 'residential');

  // Portico columns + pediment gable at entrance
  [-4.0, 4.0].forEach((cx) => {
    addBox(villaGroup, cx, 0.5, 11.4, 1.1, 0.5, 1.1, '#d9cfc0');
    addCyl(villaGroup, cx, 1.0, 11.4, 0.36, 0.44, 4.9, '#efe8da', 12);
    addBox(villaGroup, cx, 5.7, 11.4, 1.15, 0.4, 1.15, '#d9cfc0');
  });
  addBox(villaGroup, 0, 6.1, 11.2, 9.6, 0.55, 3.0, '#d4c7b0');
  addRoofPyramid(villaGroup, 0, 6.65, 11.4, 9.8, 1.9, 3.2, '#b45309');

  // Detailed multi-pane shuttered windows across front, sides & back
  addFacadeWindows(villaGroup, 28, 5.6, 20, 0.5, 1, { skipCenterGroundDoor: true, shutterColor: '#0f766e' });
  addFacadeWindows(villaGroup, 25, 5.0, 17, 6.1, 1, { shutterColor: '#0f766e' });

  // Villa name plaque
  createSignBoard(
    villaGroup,
    makeSignTexture('قصرنا العائلي — V15', '#1e293b', '#fbbf24', '#f59e0b'),
    0,
    7.8,
    12.95,
    6.8,
    1.15
  );

  // Hinged double front door
  const villaDoor = createHingedDoor(
    villaGroup,
    'door_home_villa',
    0,
    0.5,
    10.05,
    3.2,
    3.5,
    '#7c2d12',
    0,
    -23.95,
    'دخول القصر العائلي',
    'home_ground'
  );
  doors.push(villaDoor);
  zones.push({
    id: 'enter_home_ground',
    label: 'دخول القصر العائلي (الطابق الأرضي)',
    emoji: '🏰',
    x: 0,
    z: -21.5,
    radius: 4.5,
    action: 'enter:home_ground',
  });

  // ================= 2. ATTACHED GARAGE & AUTOMATED SLIDING GATE (20, -30) =================
  addBox(villaGroup, 20, 0.2, 2, 10.5, 4.6, 12.5, '#e8dfd0', { map: stoneTex });
  addArchitecturalTrim(villaGroup, 10.5, 4.6, 12.5, 0.2, '#d6c8ad', '#a89b84');
  addRoofPyramid(villaGroup, 20, 4.8, 2, 11.2, 2.3, 13.2, '#7c2d12', { map: roofTex });
  addBox(villaGroup, 20, 0.2, 8.3, 6.8, 3.4, 0.25, '#1e293b');
  // Driveway asphalt from garage down to main EW road
  addBox(parent, 20, 0.03, -8, 8.5, 0.05, 26, '#334155', { receiveShadow: true, castShadow: false });

  // Villa Perimeter Stone Wall + Decorative Gate Pillars (clean opening at center & driveway)
  addBox(parent, -26, 0.05, -24, 34, 1.4, 0.65, '#dfd4be', { map: stoneTex });
  addBox(parent, -43, 0.05, -42, 0.65, 1.4, 36, '#dfd4be', { map: stoneTex });
  addBox(parent, 43, 0.05, -42, 0.65, 1.4, 36, '#dfd4be', { map: stoneTex });
  addBox(parent, 0, 0.05, -60, 86, 1.4, 0.65, '#dfd4be', { map: stoneTex });
  addBox(parent, 34, 0.05, -14, 18, 1.4, 0.65, '#dfd4be', { map: stoneTex });
  [-9, 9, 15.5, 24.5].forEach((px) => {
    const pz = px < 12 ? -24 : -14;
    addBox(parent, px, 0.05, pz, 1.3, 2.6, 1.3, '#cfc1a7');
    addRoofPyramid(parent, px, 2.65, pz, 1.6, 0.7, 1.6, '#9a3412');
  });

  // Automated Sliding Driveway Gate at z=-14, x=20
  const gateGroup = new THREE.Group();
  gateGroup.position.set(20, 0.05, -14);
  addBox(gateGroup, 0, 0.1, 0, 8.2, 1.9, 0.35, '#1e293b', { metalness: 0.7, roughness: 0.35 });
  for (let gx = -3.4; gx <= 3.4; gx += 0.85) {
    addBox(gateGroup, gx, 0.2, 0, 0.12, 2.1, 0.4, '#fbbf24', { metalness: 0.8 });
  }
  parent.add(gateGroup);

  const garageGate = {
    mesh: gateGroup,
    isOpen: false,
    closedX: 20,
    openX: 29,
    x: 20,
    z: -14,
  };
  zones.push({
    id: 'gate_home_garage',
    label: 'فتح / إغلاق بوابة الكراج الذكية',
    emoji: '🚧',
    x: 20,
    z: -14,
    radius: 7.5,
    action: 'gate:garage',
  });

  // ================= 3. SWIMMING POOL, FOUNTAIN & BBQ GARDEN (-26, -40) =================
  addBox(villaGroup, -26, 0.04, -5, 14, 0.2, 10, '#cbd5e1');
  addBox(villaGroup, -26, 0.18, -5, 12.2, 0.14, 8.4, '#0ea5e9', { roughness: 0.08, metalness: 0.15, emissive: '#0284c7', emissiveIntensity: 0.22 });
  [-30, -22].forEach((lx) => {
    addBox(villaGroup, lx, 0.24, 2.5, 1.4, 0.35, 2.8, '#f8fafc');
    addBox(villaGroup, lx, 0.56, 1.4, 1.4, 0.45, 0.8, '#38bdf8');
  });
  // BBQ Wooden Pergola with posts & rafters
  addBox(villaGroup, -26, 0.08, -14, 7.6, 0.22, 5.6, '#b45309');
  [[-3.2, -2.2], [3.2, -2.2], [-3.2, 2.2], [3.2, 2.2]].forEach(([px, pz]) => {
    addBox(villaGroup, -26 + px, 0.3, -14 + pz, 0.35, 3.0, 0.35, '#78350f');
  });
  for (let rz = -2.2; rz <= 2.2; rz += 1.1) {
    addBox(villaGroup, -26, 3.3, -14 + rz, 7.4, 0.22, 0.22, '#92400e');
  }
  addBox(villaGroup, -26, 0.3, -14, 2.2, 1.1, 1.1, '#334155');
  addBox(villaGroup, -26, 1.4, -14, 2.0, 0.12, 0.9, '#ef4444', { emissive: '#ea580c', emissiveIntensity: 0.7 });
  zones.push({
    id: 'home_bbq',
    label: 'شواء وحديقة المسبح (استعادة طاقة وشبع)',
    emoji: '🍖',
    x: -26,
    z: -48,
    radius: 4.5,
    action: 'action:bbq',
  });

  parent.add(villaGroup);

  collision.addBox('home_villa_main', 0, -34, 28.5, 20.5, 'building');
  collision.addBox('home_villa_garage', 20, -32, 10.5, 12.5, 'building');
  collision.addBox('home_fence_w', -43, -42, 1.2, 36, 'fence');
  collision.addBox('home_fence_e', 43, -42, 1.2, 36, 'fence');
  collision.addBox('home_fence_n', 0, -60, 86, 1.2, 'fence');

  // ================= 4. RELOCATED SAADOUN HERITAGE MARKET (-54, 18) =================
  const shop = new THREE.Group();
  shop.position.set(-54, 0, 18);
  addBox(shop, 0, 0, 0, 16, 6.4, 12, '#f5e7c9', { map: stoneTex });
  addArchitecturalTrim(shop, 16, 6.4, 12, 0, '#e6d4b3', '#b39d78');
  addRoofPyramid(shop, 0, 6.4, 0, 17.2, 2.8, 13.2, '#b45309', { map: roofTex });
  addFacadeWindows(shop, 16, 6.4, 12, 0, 1, { skipCenterGroundDoor: true, shutterColor: '#b45309' });
  addShopAwning(shop, 0, 3.8, 6.0, 13.5, '#dc2626', '#fef3c7');
  addRooftopDetails(shop, 14, 6.4, 10, 'residential');
  createSignBoard(
    shop,
    makeSignTexture('سوق سعدون التراثي 🏪', '#7c2d12', '#fef3c7', '#fbbf24'),
    0,
    5.4,
    6.35,
    8.5,
    1.2
  );
  doors.push(
    createHingedDoor(shop, 'door_saadoun', 0, 0, 6.05, 2.6, 3.0, '#78350f', -54, 24.05, 'دخول سوق سعدون', 'saadoun_shop')
  );
  parent.add(shop);
  collision.addBox('home_saadoun', -54, 18, 16.5, 12.5, 'building');
  zones.push({
    id: 'enter_saadoun',
    label: 'دخول سوق سعدون التراثي',
    emoji: '🏪',
    x: -54,
    z: 27.5,
    radius: 4.5,
    action: 'enter:saadoun_shop',
  });
  // Market display crates & benches beside Saadoun Market
  [-63, -64.5].forEach((cx, i) => nature.addCrate(cx, 16 + i * 2, 1.0));
  nature.addBench(-43, 22, 0);

  // ================= 5. DIWAN COMMUNITY HALL (56, 18) =================
  const diwan = new THREE.Group();
  diwan.position.set(56, 0, 18);
  addBox(diwan, 0, 0, 0, 16, 6.8, 12, '#efe5d0', { map: stoneTex });
  addArchitecturalTrim(diwan, 16, 6.8, 12, 0, '#ddd0b8', '#a89a82');
  addDome(diwan, 0, 6.8, 0, 4.4, '#0f766e');
  addFacadeWindows(diwan, 16, 6.8, 12, 0, 1, { skipCenterGroundDoor: true, shutterColor: '#0f766e' });
  addBalcony(diwan, 0, 4.2, 6.0, 9, 1.8, 0, '#0f766e');
  createSignBoard(
    diwan,
    makeSignTexture('ديوان القرية والمهام 🎪', '#0f766e', '#fef3c7', '#fbbf24'),
    0,
    5.6,
    6.35,
    8.5,
    1.2
  );
  doors.push(
    createHingedDoor(diwan, 'door_diwan', 0, 0, 6.05, 2.8, 3.1, '#115e59', 56, 24.05, 'فتح سجل المهام والفعاليات', undefined, 'open:quests')
  );
  parent.add(diwan);
  collision.addBox('home_diwan', 56, 18, 16.5, 12.5, 'building');
  zones.push({
    id: 'open_diwan_quests',
    label: 'ديوان المهام والتحديات',
    emoji: '🎯',
    x: 56,
    z: 27.5,
    radius: 4.5,
    action: 'open:quests',
  });

  // ================= 6. DETAILED VILLAGER COTTAGES & SOUTH NEIGHBORHOOD =================
  const cottages = [
    { id: 'cot_1', x: -56, z: 64, wall: '#f3e3c6', roof: '#9a3412' },
    { id: 'cot_2', x: -86, z: 64, wall: '#e2e8f0', roof: '#1d4ed8' },
    { id: 'cot_3', x: 56, z: 64, wall: '#fce7f3', roof: '#be185d' },
    { id: 'cot_4', x: 86, z: 64, wall: '#ecfccb', roof: '#15803d' },
    // South neighborhood homes filling empty Southern green field cleanly below home_south_spur (z=85)
    { id: 'cot_5', x: -52, z: 103, wall: '#fde68a', roof: '#b45309' },
    { id: 'cot_6', x: -24, z: 103, wall: '#e0f2fe', roof: '#0369a1' },
    { id: 'cot_7', x: 26, z: 103, wall: '#f3e8ff', roof: '#7e22ce' },
    { id: 'cot_8', x: 56, z: 103, wall: '#dcfce7', roof: '#0f766e' },
  ];
  cottages.forEach((ct) => {
    const cg = new THREE.Group();
    cg.position.set(ct.x, 0, ct.z);
    addBox(cg, 0, 0, 0, 12, 5.0, 10, ct.wall, { map: stoneTex });
    addArchitecturalTrim(cg, 12, 5.0, 10, 0, '#e5dccb', '#b5a892');
    addRoofPyramid(cg, 0, 5.0, 0, 13.2, 3.0, 11.2, ct.roof, { map: roofTex });
    addBox(cg, 0, 0, 5.1, 2.0, 2.7, 0.22, '#5c3a21');
    addBox(cg, 0, 2.9, 5.5, 3.2, 0.25, 1.4, ct.roof);
    [-3.6, 3.6].forEach((wx) => addDetailedWindow(cg, wx, 1.5, 5.0, 1.8, 1.7, 0, { lit: true, shutterColor: ct.roof }));
    [-3.6, 3.6].forEach((wx) => addDetailedWindow(cg, wx, 1.5, -5.0, 1.8, 1.7, Math.PI, { shutterColor: ct.roof }));
    addDetailedWindow(cg, 6.0, 1.5, 0, 1.8, 1.7, Math.PI / 2, { lit: true });
    addDetailedWindow(cg, -6.0, 1.5, 0, 1.8, 1.7, -Math.PI / 2, { lit: true });
    addRooftopDetails(cg, 10, 5.0, 8, 'residential');
    parent.add(cg);
    collision.addBox(ct.id, ct.x, ct.z, 12.6, 10.6, 'house');
    nature.addFlowerBed(ct.x - 4.2, ct.z + 6.1, 0, Math.abs(ct.x) % 4);
    nature.addFlowerBed(ct.x + 4.2, ct.z + 6.1, 0, (Math.abs(ct.x) + 1) % 4);
  });

  // ================= 7. ORCHARD GAZEBO (NE) + SCENIC PARK POND (NW) + LAKESIDE PIER (SE) =================
  // NE Gazebo Pavilion (76, -34)
  const gazebo = new THREE.Group();
  gazebo.position.set(76, 0, -34);
  addCyl(gazebo, 0, 0, 0, 6.5, 6.8, 0.4, '#d6cbb5', 8);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    addCyl(gazebo, Math.cos(a) * 5.2, 0.4, Math.sin(a) * 5.2, 0.22, 0.26, 3.8, '#f5efe2', 8);
  }
  addRoofPyramid(gazebo, 0, 4.2, 0, 12.5, 3.0, 12.5, '#0f766e');
  addCyl(gazebo, 0, 0.4, 0, 1.4, 1.4, 0.9, '#cbd5e1', 12);
  parent.add(gazebo);
  collision.addCircle('home_ne_gazebo', 76, -34, 6.5, 'prop');
  // Orchard trees surrounding NE Gazebo
  for (let ox = 56; ox <= 102; ox += 15) {
    for (let oz = -64; oz <= -8; oz += 16) {
      if (Math.hypot(ox - 76, oz + 34) < 12) continue;
      nature.addTree(ox, oz, 1.05, (ox + oz) % 2 === 0 ? 'round' : 'cypress');
    }
  }

  // NW Scenic Park Pond & Stone Fountain (-76, -24)
  addCyl(parent, -76, 0.01, -24, 14, 14.5, 0.14, '#cbd5e1', 24);
  addCyl(parent, -76, 0.14, -24, 12.6, 12.6, 0.12, '#0ea5e9', 24, { roughness: 0.08 });
  addCyl(parent, -76, 0.24, -24, 1.2, 1.6, 2.4, '#e2d5b5', 10);
  collision.addCircle('home_nw_pond', -76, -24, 14.2, 'prop');
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    nature.addBench(-76 + Math.cos(a) * 16.5, -24 + Math.sin(a) * 16.5, a + Math.PI / 2);
    nature.addFlowerBed(-76 + Math.cos(a + 0.4) * 16, -24 + Math.sin(a + 0.4) * 16, a, i);
  }
  for (let wx = -108; wx <= -56; wx += 14) {
    for (let wz = -68; wz <= -44; wz += 14) {
      nature.addTree(wx, wz, 1.05, wx % 28 === 0 ? 'pine' : 'round');
    }
  }

  // SE Wooden Pier & Moored Sailboat (128, 72)
  addBox(parent, 134, -0.1, 72, 24, 0.45, 7, '#78350f');
  for (let px = 124; px <= 144; px += 5) {
    addCyl(parent, px, -2.5, 69, 0.25, 0.25, 2.6, '#5c3a21', 6);
    addCyl(parent, px, -2.5, 75, 0.25, 0.25, 2.6, '#5c3a21', 6);
  }
  const boat = new THREE.Group();
  boat.position.set(148, -0.6, 62);
  addBox(boat, 0, 0, 0, 3.6, 1.3, 9.5, '#9a3412');
  addCyl(boat, 0, 1.3, 0, 0.14, 0.18, 7.5, '#78350f', 8);
  addBox(boat, 0, 4.5, 1.2, 0.12, 5.2, 3.8, '#f8fafc');
  parent.add(boat);
  anims.push({ kind: 'bobY', mesh: boat, speed: 1.5, amp: 0.18, baseY: -0.6, phase: 0.2 });

  // ================= 8. GAS & EV STATION ON SOUTH-EAST CORNER (32, 68) =================
  const gas = new THREE.Group();
  gas.position.set(32, 0, 68);
  addBox(gas, 0, 0, 0, 12, 0.25, 8, '#334155');
  addBox(gas, 0, 4.2, 0, 13.5, 0.55, 8.8, '#0284c7');
  addBox(gas, 0, 4.75, 0, 13.7, 0.2, 9.0, '#fbbf24');
  [-5.2, 5.2].forEach((px) => addBox(gas, px, 0.25, 0, 0.55, 4.0, 0.55, '#cbd5e1'));
  addBox(gas, -2.5, 0.25, 0, 1.2, 2.2, 0.9, '#ef4444');
  addBox(gas, 2.5, 0.25, 0, 1.2, 2.2, 0.9, '#10b981');
  createSignBoard(gas, makeSignTexture('محطة وقود وشحن EV ⚡⛽', '#0f172a', '#38bdf8', '#10b981'), 0, 5.4, 4.4, 8.5, 1.0);
  parent.add(gas);
  collision.addBox('gas_home_pumps', 32, 68, 7.5, 2.5, 'station');
  zones.push({
    id: 'gas_home',
    label: 'تزويد الوقود / شحن السيارة الكهربائية',
    emoji: '⛽',
    x: 32,
    z: 62,
    radius: 7.0,
    action: 'gas:gs_home',
  });

  // ================= 9. LUSH PERIMETER TREES, COASTAL ROCKS, BUSHES & ROAD LAMPS =================
  for (let i = 0; i < 64; i++) {
    const a = (i / 64) * Math.PI * 2;
    const r = 112 + (i % 3) * 6;
    const tx = Math.cos(a) * r;
    const tz = Math.sin(a) * r;
    if (Math.abs(tx) < 13 && tz > -5) continue;
    if (Math.abs(tz - 42) < 13) continue;
    if (Math.abs(tz - 85) < 11) continue;
    nature.addTree(tx, tz, 0.95 + (i % 3) * 0.16, i % 4 === 0 ? 'palm' : i % 3 === 0 ? 'cypress' : 'round');
    if (i % 2 === 0) {
      nature.addBush(Math.cos(a) * (r - 6), Math.sin(a) * (r - 6), 1.0);
    }
    if (i % 4 === 0) {
      nature.addRock(Math.cos(a) * 133, Math.sin(a) * 133, 1.2 + (i % 3) * 0.4);
    }
  }

  // Avenue lamps & flower planters strictly outside road clearance (offset >= 8.5m from road centerlines!)
  [-95, -65, -32, 32, 65, 95].forEach((lx) => {
    nature.addLamp(lx, 33.5, 0);
    nature.addLamp(lx, 50.5, Math.PI);
    nature.addFlowerBed(lx + 8, 33.5, 0, Math.abs(lx) % 4);
  });
  [12, 28, 60, 102].forEach((lz) => {
    nature.addLamp(-8.5, lz, Math.PI / 2);
    nature.addLamp(8.5, lz, -Math.PI / 2);
    nature.addBush(-10.5, lz + 6, 0.9);
    nature.addBush(10.5, lz + 6, 0.9);
  });

  return { doors, zones, anims, garageGate };
}
