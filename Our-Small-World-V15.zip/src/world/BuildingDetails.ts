import * as THREE from 'three';
import { addBox, addCyl } from './MeshHelpers';

/**
 * Adds architectural cornice, plinth base, mid-floor belt band, and corner pilasters
 * around a rectangular volume of width W, height H, depth D, starting at baseY.
 */
export function addArchitecturalTrim(
  g: THREE.Object3D,
  W: number,
  H: number,
  D: number,
  baseY = 0,
  trimColor = '#d6c8ad',
  plinthColor = '#a89b84'
): void {
  addBox(g, 0, baseY, 0, W + 0.7, 0.75, D + 0.7, plinthColor, { roughness: 0.85 });
  addBox(g, 0, baseY + H - 0.55, 0, W + 0.9, 0.55, D + 0.9, trimColor, { roughness: 0.72 });
  if (H >= 9) {
    addBox(g, 0, baseY + H * 0.48, 0, W + 0.45, 0.35, D + 0.45, trimColor, { roughness: 0.75 });
  }
  const pW = Math.min(1.1, W * 0.06);
  const pD = Math.min(1.1, D * 0.06);
  [
    [-W / 2 + pW * 0.25, -D / 2 + pD * 0.25],
    [W / 2 - pW * 0.25, -D / 2 + pD * 0.25],
    [-W / 2 + pW * 0.25, D / 2 - pD * 0.25],
    [W / 2 - pW * 0.25, D / 2 - pD * 0.25],
  ].forEach(([px, pz]) => {
    addBox(g, px, baseY + 0.75, pz, pW + 0.35, H - 1.3, pD + 0.35, trimColor, { roughness: 0.74 });
  });
}

/**
 * Lightweight 3D recessed window assembly (3 meshes: projecting sill/frame + glass + optional shutters)
 */
export function addDetailedWindow(
  g: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  ry = 0,
  opts?: { trimColor?: string; shutterColor?: string; lit?: boolean }
): void {
  const win = new THREE.Group();
  win.position.set(x, y, z);
  win.rotation.y = ry;

  const trim = opts?.trimColor || '#e7dcc8';
  addBox(win, 0, -0.15, 0.14, w + 0.45, 0.22, 0.32, trim, { castShadow: false });
  addBox(win, 0, 0, 0.06, w + 0.18, h + 0.1, 0.14, '#334155', { castShadow: false });
  addBox(
    win,
    0,
    0.08,
    0.1,
    w - 0.12,
    h - 0.12,
    0.08,
    '#93c5fd',
    {
      roughness: 0.12,
      metalness: 0.38,
      emissive: '#fef08a',
      emissiveIntensity: opts?.lit ? 0.35 : 0.14,
      castShadow: false,
    }
  );

  if (opts?.shutterColor) {
    addBox(win, -w / 2 - 0.24, 0.05, 0.1, 0.34, h - 0.06, 0.1, opts.shutterColor, { castShadow: false });
    addBox(win, w / 2 + 0.24, 0.05, 0.1, 0.34, h - 0.06, 0.1, opts.shutterColor, { castShadow: false });
  }

  g.add(win);
}

/**
 * Adds 3D recessed windows on the primary front & side hero bays (complementing the detailed
 * 512x512 facade window texture on all walls so buildings have real depth + 60 FPS performance).
 */
export function addFacadeWindows(
  g: THREE.Object3D,
  W: number,
  H: number,
  D: number,
  baseY: number,
  floors: number,
  opts?: { skipCenterGroundDoor?: boolean; shutterColor?: string; trimColor?: string }
): void {
  const floorH = (H - 1.2) / Math.max(1, floors);
  const colsFB = Math.min(4, Math.max(2, Math.floor((W - 4) / 6.2)));

  for (let f = 0; f < floors; f++) {
    const wy = baseY + 1.2 + f * floorH;
    const wh = Math.min(2.2, floorH * 0.56);
    const lit = f % 2 === 0;

    // Front (+Z) 3D hero windows
    for (let c = 0; c < colsFB; c++) {
      const wx = -W / 2 + 3.2 + (c * (W - 6.4)) / Math.max(1, colsFB - 1);
      if (!(f === 0 && opts?.skipCenterGroundDoor && Math.abs(wx) < 3.4)) {
        addDetailedWindow(g, wx, wy, D / 2, 1.85, wh, 0, {
          lit: lit || c % 2 === 0,
          shutterColor: opts?.shutterColor,
          trimColor: opts?.trimColor,
        });
      }
    }
  }
}

export function addShopAwning(
  g: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  colorA = '#dc2626',
  colorB = '#fef3c7'
): void {
  const aw = new THREE.Group();
  aw.position.set(x, y, z);
  const segs = Math.min(6, Math.max(4, Math.floor(w / 2.2)));
  const sw = w / segs;
  for (let i = 0; i < segs; i++) {
    const sx = -w / 2 + (i + 0.5) * sw;
    const stripe = addBox(aw, sx, 0, 1.15, sw, 0.22, 2.3, i % 2 === 0 ? colorA : colorB);
    stripe.rotation.x = 0.25;
  }
  g.add(aw);
}

export function addBalcony(
  g: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  ry = 0,
  railColor = '#1e293b'
): void {
  const b = new THREE.Group();
  b.position.set(x, y, z);
  b.rotation.y = ry;
  addBox(b, 0, 0, d / 2, w, 0.26, d, '#d9cfc0');
  [-w * 0.36, w * 0.36].forEach((bx) => {
    addBox(b, bx, -0.42, d * 0.35, 0.32, 0.42, d * 0.7, '#b5a892');
  });
  // Clean solid+glass balustrade rail
  addBox(b, 0, 0.26, d - 0.08, w, 0.78, 0.1, '#7dd3fc', { transparent: true, opacity: 0.4, castShadow: false });
  addBox(b, 0, 1.04, d - 0.08, w, 0.12, 0.14, railColor, { metalness: 0.6 });
  addBox(b, -w / 2 + 0.06, 0.26, d / 2, 0.14, 0.9, d, railColor, { metalness: 0.6 });
  addBox(b, w / 2 - 0.06, 0.26, d / 2, 0.14, 0.9, d, railColor, { metalness: 0.6 });
  g.add(b);
}

export function addRooftopDetails(
  g: THREE.Object3D,
  W: number,
  topY: number,
  D: number,
  kind: 'civic' | 'commercial' | 'industrial' | 'residential'
): void {
  if (kind === 'commercial' || kind === 'civic') {
    addBox(g, 0, topY, 0, W * 0.34, 0.85, D * 0.3, '#94a3b8');
    addBox(g, 0, topY + 0.85, 0, W * 0.3, 0.6, D * 0.26, '#7dd3fc', {
      roughness: 0.1,
      metalness: 0.4,
      emissive: '#fef3c7',
      emissiveIntensity: 0.18,
    });
    addBox(g, -W * 0.28, topY, -D * 0.22, 2.2, 1.1, 1.8, '#64748b', { metalness: 0.4 });
  } else if (kind === 'industrial') {
    [-W * 0.25, W * 0.25].forEach((vx) => {
      addCyl(g, vx, topY, 0, 0.7, 0.9, 1.6, '#475569', 8);
      addCyl(g, vx, topY + 1.6, 0, 1.05, 0.7, 0.35, '#94a3b8', 8);
    });
    addBox(g, 0, topY + 0.3, -D * 0.28, W * 0.7, 0.55, 0.55, '#cbd5e1', { metalness: 0.65 });
  } else {
    addBox(g, -W * 0.28, topY, -D * 0.18, 1.1, 2.0, 1.1, '#7c2d12');
    addBox(g, -W * 0.28, topY + 2.0, -D * 0.18, 1.35, 0.24, 1.35, '#cbd5e1');
  }
}
