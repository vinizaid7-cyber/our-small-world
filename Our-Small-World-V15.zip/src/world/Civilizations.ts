import * as THREE from 'three';
import { BUILDER_BLUEPRINTS, CROPS } from '../data/catalog';
import {
  BUS_STOPS,
  DIG_SPOTS,
  FARM_PARCELS,
  GAS_STATIONS,
  ISLANDS,
  ROADS,
  SiteDef,
  SITES,
} from '../data/islandsData';
import { GameState } from '../data/storage';
import { SpatialCollisionWorld, distancePointToSegment } from '../engine/CollisionSystem';
import {
  getAsphaltTexture,
  getCobblestoneTexture,
  getFacadeTexture,
  getGlassFacadeTexture,
  getGrassTexture,
  getRoofTileTexture,
  getStoneTexture,
  makeSignTexture,
} from '../engine/Textures';
import {
  addArchitecturalTrim,
  addBalcony,
  addDetailedWindow,
  addFacadeWindows,
  addRooftopDetails,
  addShopAwning,
} from './BuildingDetails';
import {
  addBox,
  addCyl,
  addDome,
  addRoofPyramid,
  AnimatedDoor,
  AnimatedProp,
  createHingedDoor,
  createSignBoard,
  getMat,
  InstancedNatureBuilder,
  InteractiveZone,
} from './MeshHelpers';

export interface CivilizationsRefs {
  doors: AnimatedDoor[];
  zones: InteractiveZone[];
  anims: AnimatedProp[];
  portCraneHook: THREE.Object3D | null;
  portShipGroup: THREE.Group | null;
  cropGroup: THREE.Group;
  placedGroup: THREE.Group;
  islandGroups: Record<string, THREE.Group>;
}

function isZoneClear(x: number, z: number, halfW: number, halfD: number): boolean {
  const rad = Math.max(halfW, halfD) + 3.5;
  for (const rd of ROADS) {
    if (distancePointToSegment(x, z, rd.x0, rd.z0, rd.x1, rd.z1) < rd.width / 2 + rad) {
      return false;
    }
  }
  for (const s of SITES) {
    const rot90 = Math.abs(Math.sin(s.facing)) > 0.7;
    const sw = (rot90 ? s.d : s.w) / 2 + halfW + 4;
    const sd = (rot90 ? s.w : s.d) / 2 + halfD + 4;
    if (Math.abs(x - s.x) < sw && Math.abs(z - s.z) < sd) return false;
  }
  for (const gs of GAS_STATIONS) {
    if (Math.abs(x - gs.x) < halfW + 9 && Math.abs(z - gs.z) < halfD + 8) return false;
  }
  for (const bs of BUS_STOPS) {
    if (Math.abs(x - bs.x) < halfW + 7 && Math.abs(z - bs.z) < halfD + 6) return false;
  }
  for (const ds of DIG_SPOTS) {
    if (Math.hypot(x - ds.x, z - ds.z) < rad + 6) return false;
  }
  for (const fp of FARM_PARCELS) {
    if (Math.abs(x - fp.x) < fp.w / 2 + halfW + 3 && Math.abs(z - fp.z) < fp.d / 2 + halfD + 3) return false;
  }
  return true;
}

function addSecondaryBuilding(
  parent: THREE.Group,
  collision: SpatialCollisionWorld,
  id: string,
  x: number,
  z: number,
  w: number,
  h: number,
  d: number,
  wallColor: string,
  roofColor: string,
  ry: number,
  kind: 'townhouse' | 'warehouse' | 'office' | 'stall',
  stoneTex: THREE.CanvasTexture,
  roofTex: THREE.CanvasTexture,
  facadeTex: THREE.CanvasTexture
): void {
  const rot90 = Math.abs(Math.sin(ry)) > 0.7;
  const checkW = rot90 ? d / 2 : w / 2;
  const checkD = rot90 ? w / 2 : d / 2;
  if (!isZoneClear(x, z, checkW, checkD)) return;

  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = ry;

  if (kind === 'stall') {
    addBox(g, 0, 0, 0, w, 0.3, d, '#cbb99a');
    [-w / 2 + 0.3, w / 2 - 0.3].forEach((px) =>
      [-d / 2 + 0.3, d / 2 - 0.3].forEach((pz) => addBox(g, px, 0.3, pz, 0.25, 2.8, 0.25, '#78350f'))
    );
    addShopAwning(g, 0, 3.0, -d / 2, w + 0.6, roofColor, '#fef3c7');
    addBox(g, 0, 0.3, 0, w * 0.8, 1.0, d * 0.45, '#b45309');
  } else if (kind === 'warehouse') {
    addBox(g, 0, 0, 0, w, h, d, wallColor, { map: stoneTex });
    addArchitecturalTrim(g, w, h, d, 0, '#94a3b8', '#475569');
    addRoofPyramid(g, 0, h, 0, w + 0.8, 2.2, d + 0.8, roofColor);
    addBox(g, 0, 0, d / 2 + 0.08, Math.min(w * 0.45, 5), Math.min(h * 0.7, 3.6), 0.14, '#334155');
    addRooftopDetails(g, w, h, d, 'industrial');
  } else {
    addBox(g, 0, 0, 0, w, h, d, wallColor, { map: facadeTex });
    addArchitecturalTrim(g, w, h, d, 0, '#e5dcc8', '#b5a78f');
    if (kind === 'office') {
      addBox(g, 0, h, 0, w + 0.4, 0.6, d + 0.4, roofColor);
      addRooftopDetails(g, w, h + 0.6, d, 'commercial');
    } else {
      addRoofPyramid(g, 0, h, 0, w + 1.0, 2.6, d + 1.0, roofColor, { map: roofTex });
      addRooftopDetails(g, w, h, d, 'residential');
    }
    addBox(g, 0, 0, d / 2 + 0.08, 2.0, 2.8, 0.16, '#5c3a21');
    if (h >= 7) {
      addBalcony(g, 0, h * 0.48, d / 2, Math.min(w * 0.5, 5), 1.4, 0);
    }
  }

  parent.add(g);
  collision.addBox(id, x, z, checkW * 2 + 0.5, checkD * 2 + 0.5, 'building');
}

export function buildAllCivilizations(
  parent: THREE.Group,
  collision: SpatialCollisionWorld,
  nature: InstancedNatureBuilder
): CivilizationsRefs {
  const doors: AnimatedDoor[] = [];
  const zones: InteractiveZone[] = [];
  const anims: AnimatedProp[] = [];
  let portCraneHook: THREE.Object3D | null = null;
  let portShipGroup: THREE.Group | null = null;

  const islandGroups: Record<string, THREE.Group> = {};
  const stoneTex = getStoneTexture('#e6dcc8', 4);
  const darkStoneTex = getStoneTexture('#a8a29e', 4);
  const cobbleTex = getCobblestoneTexture('#cfc2aa', 10);
  const roofTex = getRoofTileTexture('#9a3412', 5);
  const facadeWarm = getFacadeTexture('#efe3cb', '#d4c3a3', '#60a5fa', 3, 4, 2, 1);
  const facadeUrban = getFacadeTexture('#dce4ec', '#b8c4d0', '#38bdf8', 4, 5, 2, 2);
  const glassTex = getGlassFacadeTexture('#38bdf8');
  const asphaltTex = getAsphaltTexture();

  // 1. Build Stepped Island Terrain (ZERO Z-fighting between beach rim, ground disc, water & sidewalks!)
  Object.values(ISLANDS).forEach((isl) => {
    const grp = new THREE.Group();
    grp.name = isl.id;
    islandGroups[isl.id] = grp;

    // Sandy beach / submerged cliff skirt (top strictly at y = -0.14, well below terrain y = 0.0!)
    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(isl.radius + 3.5, isl.radius + 11, 2.4, 48),
      getMat(isl.rimColor, { roughness: 0.92 })
    );
    rim.position.set(isl.cx, -1.34, isl.cz);
    rim.receiveShadow = true;
    grp.add(rim);

    // Coastal stone seawall / embankment collar at edge
    const wall = new THREE.Mesh(
      new THREE.CylinderGeometry(isl.radius + 1.2, isl.radius + 2.4, 0.4, 48),
      getMat('#9c917e', { roughness: 0.88 })
    );
    wall.position.set(isl.cx, -0.22, isl.cz);
    wall.receiveShadow = true;
    grp.add(wall);

    // Subtle seafoam surf ring at ocean level (y = -0.82)
    const foam = new THREE.Mesh(
      new THREE.RingGeometry(isl.radius + 5.5, isl.radius + 8.5, 48),
      getMat('#e0f2fe', { transparent: true, opacity: 0.42, roughness: 0.3 })
    );
    foam.rotation.x = -Math.PI / 2;
    foam.position.set(isl.cx, -0.81, isl.cz);
    grp.add(foam);

    // Main island terrain plateau (top strictly at y = 0.0)
    const groundMat =
      isl.id === 'ISL_HOME' || isl.id === 'ISL_AGRI' || isl.id === 'ISL_LIFE'
        ? getMat(isl.groundColor, { map: getGrassTexture(isl.groundColor, 14), roughness: 0.88 })
        : getMat(isl.groundColor, { map: getCobblestoneTexture(isl.groundColor, 16), roughness: 0.84 });

    const disc = new THREE.Mesh(new THREE.CylinderGeometry(isl.radius, isl.radius + 0.5, 0.7, 48), groundMat);
    disc.position.set(isl.cx, -0.35, isl.cz);
    disc.receiveShadow = true;
    grp.add(disc);

    // Paved District Central Boulevard Plaza (top at y = 0.04, neatly below road deck y = 0.11!)
    if (isl.id !== 'ISL_HOME') {
      const plazaMat = getMat('#cfc2aa', { map: cobbleTex, roughness: 0.86 });
      const plazaRadius = isl.id === 'ISL_CITY' || isl.id === 'ISL_BUSINESS' ? 76 : 46;
      const plaza = new THREE.Mesh(new THREE.CylinderGeometry(plazaRadius, plazaRadius, 0.04, 32), plazaMat);
      plaza.position.set(isl.cx, 0.02, isl.cz);
      plaza.receiveShadow = true;
      grp.add(plaza);
    }

    parent.add(grp);
  });

  // 2. Build Flush Roads, Sidewalk Curbs & Bridges (Road surface top strictly at y = 0.10!)
  const roadGroup = new THREE.Group();
  ROADS.forEach((r) => {
    const dx = r.x1 - r.x0;
    const dz = r.z1 - r.z0;
    const len = Math.hypot(dx, dz);
    const angle = Math.atan2(dx, dz);
    const cx = (r.x0 + r.x1) / 2;
    const cz = (r.z0 + r.z1) / 2;

    const segGroup = new THREE.Group();
    segGroup.position.set(cx, 0, cz);
    segGroup.rotation.y = angle;

    const tex = asphaltTex.clone();
    tex.repeat.set(1, Math.max(1, Math.round(len / 14)));
    tex.needsUpdate = true;

    if (!r.isBridge) {
      // Paved stone sidewalk aprons flanking the road (top at y = 0.05)
      addBox(segGroup, 0, 0.0, 0, r.width + 4.4, 0.05, len + 3, '#cbd5e1', {
        map: cobbleTex,
        castShadow: false,
      });
    }

    const deck = new THREE.Mesh(
      new THREE.BoxGeometry(r.width, r.isBridge ? 0.5 : 0.05, len + 2),
      getMat('#2c3037', { map: tex, roughness: 0.85 })
    );
    deck.position.y = r.isBridge ? -0.15 : 0.075;
    deck.receiveShadow = true;
    segGroup.add(deck);

    if (r.isBridge) {
      // Outer bridge guardrails + bridge light stanchions strictly outside driving lane
      [-r.width / 2 - 0.38, r.width / 2 + 0.38].forEach((gx) => {
        addBox(segGroup, gx, 0.05, 0, 0.5, 0.95, len, '#cbd5e1', { metalness: 0.35 });
        for (let lz = -len / 2 + 18; lz < len / 2; lz += 34) {
          addCyl(segGroup, gx, 0.95, lz, 0.1, 0.14, 3.6, '#334155', 6);
          addBox(segGroup, gx, 4.55, lz, 0.35, 0.35, 0.35, '#fef08a', { emissive: '#fde047', emissiveIntensity: 0.8 });
        }
      });
      for (let pz = -len / 2 + 24; pz < len / 2; pz += 32) {
        addCyl(segGroup, -r.width / 2 + 1, -7.5, pz, 0.95, 1.3, 7.5, '#64748b', 8);
        addCyl(segGroup, r.width / 2 - 1, -7.5, pz, 0.95, 1.3, 7.5, '#64748b', 8);
      }
    }
    roadGroup.add(segGroup);
  });
  parent.add(roadGroup);

  // 3. Build Each Civilization's Main Landmarks & Enterable Sites (with High Architectural Detail!)
  SITES.forEach((s) => {
    if (s.islandId === 'ISL_HOME') return;
    const grp = islandGroups[s.islandId] || parent;
    buildCivilizationSite(
      s,
      grp,
      collision,
      doors,
      zones,
      anims,
      stoneTex,
      darkStoneTex,
      roofTex,
      facadeWarm,
      facadeUrban,
      glassTex
    );
  });

  // 4. Populate Dense Civilization Neighborhoods, Monuments, Markets & Parks (Filling Empty Spaces!)
  // 4A. ISL_BUSINESS: Financial Plaza, Merchant Townhouses, Guild Halls & Monument
  const bizGrp = islandGroups.ISL_BUSINESS;
  if (bizGrp) {
    // Twin reflecting pools & ornate fountains flanking the plaza
    [
      [-370, 140],
      [-470, 140],
    ].forEach(([px, pz]) => {
      addCyl(bizGrp, px, 0, pz, 5.2, 5.5, 0.65, '#d6cbb5', 18);
      addCyl(bizGrp, px, 0.65, pz, 4.5, 4.5, 0.16, '#38bdf8', 18, { roughness: 0.08 });
      addCyl(bizGrp, px, 0.65, pz, 0.65, 0.85, 3.8, '#efe8da', 12);
      addCyl(bizGrp, px, 3.8, pz, 1.6, 0.5, 0.45, '#d6cbb5', 12);
      collision.addCircle(`biz_fountain_${px}`, px, pz, 5.6, 'prop');
    });

    // Secondary Accounting Offices, Guild Houses & Banks framing biz_ew & biz_ns
    const bizBlocks: Array<[number, number, number, number, number, string, string, number, 'townhouse' | 'office']> = [
      [-535, 175, 22, 13, 16, '#efe3cc', '#1e3a5f', 0, 'office'],
      [-310, 175, 22, 11, 16, '#e7dfd1', '#92400e', 0, 'townhouse'],
      [-555, 285, 22, 10, 18, '#f3ead8', '#0f766e', Math.PI, 'townhouse'],
      [-455, 345, 20, 12, 16, '#cbd5e1', '#334155', Math.PI / 2, 'office'],
      [-385, 345, 20, 10, 16, '#f4e7ce', '#b45309', -Math.PI / 2, 'townhouse'],
      [-310, 325, 22, 11, 16, '#e6dcc8', '#1e3a5f', Math.PI, 'office'],
    ];
    bizBlocks.forEach(([bx, bz, bw, bh, bd, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(bizGrp, collision, `biz_sub_${idx}`, bx, bz, bw, bh, bd, wc, rc, ry, kind, stoneTex, roofTex, facadeWarm);
    });
    // Trade Obelisk / Monument in SW Plaza
    if (isZoneClear(-465, 265, 4, 4)) {
      addBox(bizGrp, -465, 0, 265, 6, 1.2, 6, '#d6cbb5');
      addCyl(bizGrp, -465, 1.2, 265, 0.7, 1.4, 10, '#e8dec9', 4);
      addRoofPyramid(bizGrp, -465, 11.2, 265, 1.4, 1.8, 1.4, '#fbbf24');
      collision.addBox('biz_monument', -465, 265, 6.2, 6.2, 'prop');
    }
  }

  // 4B. ISL_PORT: Harbor Quays, 2 Piers, Moving Crane, Cargo Ship, Fishing Dhows, Warehouses & Market Stalls
  const portGrp = islandGroups.ISL_PORT;
  if (portGrp) {
    addBox(portGrp, -590, -0.2, 1110, 40, 1.2, 160, '#78716c', { map: cobbleTex });
    [-40, 45].forEach((dz) => {
      addBox(portGrp, -635, -0.1, 1110 + dz, 78, 0.9, 19, '#a8a29e', { map: cobbleTex });
      collision.addBox(`port_pier_${dz}`, -635, 1110 + dz, 78, 19, 'pier');
      // Mooring bollards along pier edges
      for (let bx = -670; bx <= -605; bx += 12) {
        addCyl(portGrp, bx, 0.8, 1110 + dz - 8.2, 0.25, 0.3, 0.9, '#1e293b', 8);
        addCyl(portGrp, bx, 0.8, 1110 + dz + 8.2, 0.25, 0.3, 0.9, '#1e293b', 8);
      }
    });

    // Animated Port Crane
    const crane = new THREE.Group();
    crane.position.set(-602, 0.3, 1070);
    [-4, 4].forEach((sx) =>
      [-4, 4].forEach((sz) => addBox(crane, sx, 0, sz, 0.9, 18, 0.9, '#e2e8f0'))
    );
    addBox(crane, 0, 18, 0, 10, 1.4, 10, '#f97316');
    addBox(crane, -12, 19.4, 0, 38, 1.6, 3.2, '#ea580c');
    const trolley = new THREE.Group();
    trolley.position.set(-22, 17, 0);
    addCyl(trolley, 0, -5, 0, 0.12, 0.12, 5, '#1e293b', 6);
    addBox(trolley, 0, -6.4, 0, 3.4, 1.4, 6.2, '#fbbf24');
    crane.add(trolley);
    portCraneHook = trolley;
    portGrp.add(crane);
    collision.addBox('port_crane', -602, 1070, 10, 10, 'crane');

    // Giant Cargo Ship at berth
    const ship = new THREE.Group();
    ship.position.set(-638, 0, 1110);
    addBox(ship, 0, -1.5, 0, 16, 4.2, 68, '#1e3a5f');
    addBox(ship, 0, 2.7, 0, 16.4, 0.4, 68.4, '#b91c1c');
    addBox(ship, 0, 3.1, 24, 12, 8, 10, '#f8fafc', { map: facadeWarm });
    addBox(ship, 0, 11.1, 24, 8, 3, 7, '#0f172a');
    addCyl(ship, 0, 14.1, 24, 1.2, 1.4, 4, '#dc2626', 10);
    ['#dc2626', '#0284c7', '#eab308', '#16a34a', '#9333ea', '#ea580c'].forEach((col, i) => {
      addBox(ship, i % 2 ? 3.2 : -3.2, 3.1 + Math.floor(i / 2) * 2.6, -16 + (i % 3) * 10, 4.8, 2.4, 8.5, col);
    });
    portGrp.add(ship);
    portShipGroup = ship;
    anims.push({ kind: 'bobY', mesh: ship, speed: 1.4, amp: 0.25, baseY: 0, phase: 0.5 });

    // 2 Wooden Traditional Sailing Dhows docked south & north
    [-635, -630].forEach((sx, idx) => {
      const sz = idx === 0 ? 1178 : 1038;
      const dhow = new THREE.Group();
      dhow.position.set(sx, -0.5, sz);
      addBox(dhow, 0, 0, 0, 4.4, 1.8, 14, '#78350f');
      addCyl(dhow, 0, 1.8, 0, 0.16, 0.22, 10, '#5c3a21', 8);
      addBox(dhow, 0, 6.2, 1.5, 0.14, 7.2, 5.2, '#fef3c7');
      portGrp.add(dhow);
      anims.push({ kind: 'bobY', mesh: dhow, speed: 1.7, amp: 0.2, baseY: -0.5, phase: idx * 1.4 });
    });

    // Container yard stacks (NE quadrant)
    for (let i = 0; i < 8; i++) {
      const cx = -355 + (i % 4) * 12;
      const cz = 1020 + Math.floor(i / 4) * 14;
      const col = ['#dc2626', '#2563eb', '#16a34a', '#d97706', '#0891b2', '#7c3aed', '#e11d48', '#0f766e'][i];
      if (!isZoneClear(cx, cz, 4.5, 2)) continue;
      addBox(portGrp, cx, 0, cz, 8, 2.7, 3.2, col);
      addBox(portGrp, cx, 2.7, cz, 8, 2.7, 3.2, '#cbd5e1');
      collision.addBox(`port_cont_${i}`, cx, cz, 8.2, 3.5, 'container');
    }

    // Secondary Port Warehouses, Sailor Inns & Maritime Market Stalls
    const portExtras: Array<[number, number, number, number, number, string, string, number, 'warehouse' | 'townhouse' | 'stall']> = [
      [-340, 1210, 26, 8, 16, '#cbd5e1', '#1e3a5f', Math.PI, 'warehouse'],
      [-515, 1185, 24, 9, 16, '#e2d9c5', '#0e7490', Math.PI, 'townhouse'],
      [-405, 1215, 22, 9, 16, '#f3ead8', '#b45309', Math.PI, 'townhouse'],
      [-310, 1065, 24, 8, 16, '#94a3b8', '#0369a1', 0, 'warehouse'],
      [-495, 1142, 7, 3.5, 4, '#f8fafc', '#dc2626', Math.PI, 'stall'],
      [-482, 1142, 7, 3.5, 4, '#f8fafc', '#0284c7', Math.PI, 'stall'],
      [-469, 1142, 7, 3.5, 4, '#f8fafc', '#d97706', Math.PI, 'stall'],
    ];
    portExtras.forEach(([x, z, w, h, d, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(portGrp, collision, `port_sub_${idx}`, x, z, w, h, d, wc, rc, ry, kind, stoneTex, roofTex, facadeWarm);
    });

    // Crates & cargo stacks near harbor
    for (let i = 0; i < 16; i++) {
      const cx = -575 + (i % 4) * 4;
      const cz = 1055 + Math.floor(i / 4) * 32;
      if (isZoneClear(cx, cz, 1, 1)) nature.addCrate(cx, cz, 1.1);
    }

    zones.push({
      id: 'port_export_terminal',
      label: 'منصة التصدير والشحن البحري المباشر',
      emoji: '🚢',
      x: -510,
      z: 1086,
      radius: 5.5,
      action: 'open:port',
    });
  }

  // 4C. ISL_AGRI: Irrigation Canals, Wooden Bridges, Aqueduct, Windmill, Norias, Cottages, Barn & Orchards
  const agriGrp = islandGroups.ISL_AGRI;
  if (agriGrp) {
    // Blue irrigation canals (y top = 0.05) + stone banks
    [580, 760].forEach((cz) => {
      addBox(agriGrp, -480, 0.0, cz, 330, 0.04, 6.2, '#a8a29e');
      addBox(agriGrp, -480, 0.02, cz, 326, 0.04, 4.4, '#0ea5e9', { roughness: 0.08 });
    });
    // Spinning Noria waterwheels
    [-540, -570].forEach((nx, idx) => {
      const noria = new THREE.Group();
      noria.position.set(nx, 4.5, 725);
      for (let s = 0; s < 8; s++) {
        const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.35, 8.2, 0.45), getMat('#78350f', { roughness: 0.8 }));
        spoke.rotation.z = (s * Math.PI) / 4;
        noria.add(spoke);
      }
      noria.add(new THREE.Mesh(new THREE.TorusGeometry(4.1, 0.25, 8, 24), getMat('#92400e')));
      agriGrp.add(noria);
      anims.push({ kind: 'spinZ', mesh: noria, speed: 0.75 + idx * 0.15 });
    });

    // Windmill blades on AGRI_VILLAGE
    const blades = new THREE.Group();
    blades.position.set(-420, 12.5, 636);
    for (let i = 0; i < 4; i++) {
      const arm = new THREE.Group();
      arm.rotation.z = (i * Math.PI) / 2;
      addBox(arm, 0, 0, 0, 0.4, 6.2, 0.18, '#78350f');
      addBox(arm, 0.9, 1.5, 0.08, 1.4, 4.4, 0.06, '#fef3c7');
      blades.add(arm);
    }
    agriGrp.add(blades);
    anims.push({ kind: 'spinZ', mesh: blades, speed: 0.9 });

    // Visual 3D Cows & Sheep in pasture
    for (let i = 0; i < 8; i++) {
      const ax = -575 + (i % 4) * 12;
      const az = 590 + Math.floor(i / 4) * 10;
      const animal = new THREE.Group();
      animal.position.set(ax, 0, az);
      animal.rotation.y = i * 1.1;
      const isCow = i < 4;
      addBox(animal, 0, 0.65, 0, isCow ? 1.1 : 0.7, isCow ? 0.95 : 0.65, isCow ? 2.0 : 1.2, isCow ? '#f8fafc' : '#fef3c7');
      addBox(animal, 0, 1.1, isCow ? 1.15 : 0.7, 0.55, 0.55, 0.6, isCow ? '#3f2e21' : '#1e293b');
      agriGrp.add(animal);
      anims.push({ kind: 'sway', mesh: animal, speed: 1.5, amp: 0.15, phase: i });
    }

    // Farmer Village Cottages, Grain Silos & Produce Market Stalls filling Agri center & outskirts
    const agriSubs: Array<[number, number, number, number, number, string, string, number, 'townhouse' | 'warehouse' | 'stall']> = [
      [-365, 625, 14, 5.5, 12, '#efe2c8', '#b45309', 0, 'townhouse'],
      [-335, 625, 14, 5.5, 12, '#f5ebd6', '#15803d', 0, 'townhouse'],
      [-365, 710, 15, 6, 12, '#fde68a', '#9a3412', Math.PI, 'townhouse'],
      [-610, 625, 16, 6.5, 14, '#efe2c8', '#78350f', 0, 'warehouse'],
      [-450, 815, 16, 6, 12, '#f3ead8', '#b45309', Math.PI, 'townhouse'],
      [-515, 815, 16, 6, 12, '#ecfccb', '#15803d', Math.PI, 'townhouse'],
      [-440, 646, 6, 3.2, 3.6, '#f8fafc', '#16a34a', 0, 'stall'],
      [-452, 646, 6, 3.2, 3.6, '#f8fafc', '#d97706', 0, 'stall'],
    ];
    agriSubs.forEach(([x, z, w, h, d, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(agriGrp, collision, `agri_sub_${idx}`, x, z, w, h, d, wc, rc, ry, kind, stoneTex, roofTex, facadeWarm);
    });
    // Orchard rows on Eastern & Southern slopes of ISL_AGRI
    for (let ox = -345; ox <= -285; ox += 15) {
      for (let oz = 510; oz <= 830; oz += 22) {
        if (isZoneClear(ox, oz, 3, 3)) nature.addTree(ox, oz, 1.1, 'round');
      }
    }
  }

  // 4D. ISL_INDUSTRY: Power Plant, Cooling Towers, Water Tower, Warehouses, Pipe Racks & Raw Material Yards
  const indGrp = islandGroups.ISL_INDUSTRY;
  if (indGrp) {
    [495, 520].forEach((tx) => {
      addCyl(indGrp, tx, 0, 65, 7.5, 4.8, 20, '#cbd5e1', 16);
      addCyl(indGrp, tx, 20, 65, 4.8, 5.4, 4, '#94a3b8', 16);
      collision.addCircle(`ind_cool_${tx}`, tx, 65, 7.8, 'power');
    });
    // Electrical Substation beside cooling towers
    if (isZoneClear(455, 55, 8, 6)) {
      addBox(indGrp, 455, 0, 55, 14, 1.0, 10, '#64748b');
      addBox(indGrp, 452, 1.0, 55, 4, 4.2, 4, '#334155', { metalness: 0.6 });
      addBox(indGrp, 458, 1.0, 55, 4, 4.2, 4, '#334155', { metalness: 0.6 });
      addCyl(indGrp, 455, 5.2, 55, 0.25, 0.35, 6, '#fbbf24', 6);
      collision.addBox('ind_substation', 455, 55, 14.5, 10.5, 'power');
    }
    // Water tower
    addCyl(indGrp, 240, 0, 55, 1.2, 1.8, 16, '#64748b', 8);
    addCyl(indGrp, 240, 16, 55, 5.2, 5.2, 5.5, '#0284c7', 16);
    addDome(indGrp, 240, 21.5, 55, 5.2, '#0369a1');
    collision.addCircle('ind_water_tower', 240, 55, 4.5, 'water');

    // Secondary Industrial Logistics Warehouses & Worker Canteen
    const indSubs: Array<[number, number, number, number, number, string, string, number, 'warehouse' | 'office']> = [
      [255, 250, 22, 8.5, 16, '#94a3b8', '#334155', Math.PI, 'warehouse'],
      [485, 245, 22, 8.5, 16, '#cbd5e1', '#0369a1', Math.PI, 'warehouse'],
      [360, 25, 28, 9.5, 14, '#e2e8f0', '#475569', 0, 'office'],
      [230, 10, 22, 8, 16, '#78716c', '#1e293b', 0, 'warehouse'],
    ];
    indSubs.forEach(([x, z, w, h, d, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(indGrp, collision, `ind_sub_${idx}`, x, z, w, h, d, wc, rc, ry, kind, darkStoneTex, roofTex, facadeUrban);
    });
  }

  // 4E. ISL_CITY: Dense Capital City Blocks, Central Park, Monument Square & Urban Towers
  const cityGrp = islandGroups.ISL_CITY;
  if (cityGrp) {
    // Central Park on SE quadrant with pond, pavilion & benches
    addBox(cityGrp, 390, 0.02, 740, 54, 0.05, 42, '#4ade80', { map: getGrassTexture('#4ade80', 6), castShadow: false });
    addCyl(cityGrp, 390, 0.08, 740, 8.5, 8.8, 0.65, '#cbd5e1', 18);
    addCyl(cityGrp, 390, 0.72, 740, 7.6, 7.6, 0.14, '#38bdf8', 18, { roughness: 0.08 });
    addCyl(cityGrp, 390, 0.72, 740, 0.9, 1.3, 4.5, '#e2d5b5', 10);
    collision.addCircle('city_park_fountain', 390, 740, 8.8, 'fountain');
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      nature.addBench(390 + Math.cos(a) * 11.5, 740 + Math.sin(a) * 11.5, a + Math.PI / 2);
      nature.addFlowerBed(390 + Math.cos(a + 0.5) * 14, 740 + Math.sin(a + 0.5) * 14, a, i);
    }

    // 10 Urban Apartment & Ministry Blocks framing Capital avenues so ISL_CITY feels like a REAL bustling Capital!
    const cityBlocks: Array<[number, number, number, number, number, string, string, number, 'office' | 'townhouse']> = [
      [145, 440, 26, 18, 18, '#dce4ec', '#1e3a5f', 0, 'office'],
      [205, 440, 24, 15, 18, '#efe3cc', '#9a3412', 0, 'townhouse'],
      [335, 440, 24, 16, 18, '#cbd5e1', '#0f766e', 0, 'office'],
      [395, 440, 26, 20, 18, '#e2e8f0', '#334155', 0, 'office'],
      [115, 545, 24, 14, 20, '#f3ead8', '#b45309', Math.PI / 2, 'townhouse'],
      [415, 545, 24, 16, 20, '#e2e8f0', '#1d4ed8', -Math.PI / 2, 'office'],
      [140, 660, 24, 15, 20, '#f5ebd6', '#7c2d12', Math.PI / 2, 'townhouse'],
      [405, 660, 24, 18, 20, '#cbd5e1', '#0f172a', -Math.PI / 2, 'office'],
      [145, 725, 24, 13, 18, '#efe3cc', '#0f766e', Math.PI, 'townhouse'],
      [205, 775, 22, 14, 18, '#e2e8f0', '#1e3a5f', Math.PI, 'townhouse'],
    ];
    cityBlocks.forEach(([x, z, w, h, d, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(cityGrp, collision, `city_blk_${idx}`, x, z, w, h, d, wc, rc, ry, kind, stoneTex, roofTex, facadeUrban);
    });
  }

  // 4F. ISL_LIFE: Ferris Wheel, Carousel, Botanical Dome, Amphitheater, Carnival Tents & Beach Boardwalk
  const lifeGrp = islandGroups.ISL_LIFE;
  if (lifeGrp) {
    // Ferris wheel
    const fx = 785;
    const fz = 675;
    addBox(lifeGrp, fx, 0, fz, 12, 0.8, 10, '#64748b');
    [-2.5, 2.5].forEach((sz) => addBox(lifeGrp, fx, 0.8, fz + sz, 1.0, 18, 0.8, '#fbbf24'));
    const wheel = new THREE.Group();
    wheel.position.set(fx, 18, fz);
    wheel.add(new THREE.Mesh(new THREE.TorusGeometry(13, 0.35, 8, 28), getMat('#f43f5e')));
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      const spoke = new THREE.Mesh(new THREE.BoxGeometry(26, 0.22, 0.22), getMat('#f8fafc'));
      spoke.rotation.z = a;
      wheel.add(spoke);
      const cabin = new THREE.Mesh(
        new THREE.BoxGeometry(2.1, 2.2, 2.2),
        getMat(['#38bdf8', '#fbbf24', '#10b981', '#a855f7', '#f97316'][i % 5])
      );
      cabin.position.set(Math.cos(a) * 13, Math.sin(a) * 13, 0);
      wheel.add(cabin);
    }
    lifeGrp.add(wheel);
    anims.push({ kind: 'spinZ', mesh: wheel, speed: 0.25 });
    collision.addBox('life_ferris_base', fx, fz, 13, 11, 'ride');

    // Carousel
    const carGrp = new THREE.Group();
    carGrp.position.set(735, 0, 725);
    addCyl(carGrp, 0, 0, 0, 7.5, 7.5, 0.5, '#e2d5b5', 18);
    const carouselSpin = new THREE.Group();
    addCyl(carouselSpin, 0, 0.5, 0, 1.0, 1.0, 6.2, '#fbbf24', 10);
    addRoofPyramid(carouselSpin, 0, 6.7, 0, 14, 3.2, 14, '#e11d48');
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      addCyl(carouselSpin, Math.cos(a) * 4.5, 0.5, Math.sin(a) * 4.5, 0.12, 0.12, 6, '#fbbf24', 6);
      addBox(carouselSpin, Math.cos(a) * 4.5, 1.6, Math.sin(a) * 4.5, 0.9, 1.1, 1.8, '#f8fafc');
    }
    carGrp.add(carouselSpin);
    lifeGrp.add(carGrp);
    anims.push({ kind: 'spinY', mesh: carouselSpin, speed: 0.65 });
    collision.addCircle('life_carousel', 735, 725, 7.6, 'ride');

    // Botanical Glass Dome Conservatory on NW lawn (565, 515)
    if (isZoneClear(565, 515, 12, 12)) {
      addCyl(lifeGrp, 565, 0, 515, 11.5, 12.2, 1.2, '#d6cbb5', 20);
      const bDome = new THREE.Mesh(
        new THREE.SphereGeometry(10.5, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2),
        getMat('#7dd3fc', { transparent: true, opacity: 0.52, roughness: 0.12, metalness: 0.25 })
      );
      bDome.position.set(565, 1.2, 515);
      lifeGrp.add(bDome);
      collision.addCircle('life_botanical_dome', 565, 515, 12, 'landmark');
    }

    // University Dorms & Philosophy Courtyard Buildings
    const lifeSubs: Array<[number, number, number, number, number, string, string, number, 'townhouse' | 'stall']> = [
      [560, 665, 22, 10, 16, '#efe2c9', '#1e40af', Math.PI, 'townhouse'],
      [630, 475, 24, 11, 16, '#f4e7ce', '#0f766e', 0, 'townhouse'],
      [740, 632, 7, 3.4, 4, '#f8fafc', '#f43f5e', Math.PI, 'stall'],
      [755, 632, 7, 3.4, 4, '#f8fafc', '#f59e0b', Math.PI, 'stall'],
    ];
    lifeSubs.forEach(([x, z, w, h, d, wc, rc, ry, kind], idx) => {
      addSecondaryBuilding(lifeGrp, collision, `life_sub_${idx}`, x, z, w, h, d, wc, rc, ry, kind, stoneTex, roofTex, facadeWarm);
    });

    // Ancient Obelisks & Glowing Braziers outside Sun Temple
    [762, 808].forEach((ox) => {
      addBox(lifeGrp, ox, 0, 564, 2.8, 0.8, 2.8, '#cbb68e');
      addCyl(lifeGrp, ox, 0.8, 564, 0.55, 0.95, 7.5, '#d9c39e', 4);
      addRoofPyramid(lifeGrp, ox, 8.3, 564, 1.1, 1.5, 1.1, '#fbbf24');
    });

    // Beach, Boardwalk & Umbrellas on Eastern Shore (855, 600)
    addBox(lifeGrp, 855, 0.02, 600, 38, 0.06, 72, '#fde68a', { castShadow: false });
    addBox(lifeGrp, 834, 0.06, 600, 4, 0.14, 72, '#78350f');
    for (let i = 0; i < 6; i++) {
      const uz = 568 + i * 13;
      addCyl(lifeGrp, 858, 0.08, uz, 0.1, 0.1, 2.8, '#78350f', 6);
      const umb = new THREE.Mesh(
        new THREE.ConeGeometry(2.4, 0.8, 8),
        getMat(['#ef4444', '#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'][i])
      );
      umb.position.set(858, 2.9, uz);
      lifeGrp.add(umb);
    }
  }

  // 5. Gas/EV Stations, Bus Stops & Archaeology Dig Spots across all 6 islands
  GAS_STATIONS.forEach((gs) => {
    if (gs.islandId === 'ISL_HOME') return;
    const grp = islandGroups[gs.islandId] || parent;
    const st = new THREE.Group();
    st.position.set(gs.x, 0, gs.z);
    addBox(st, 0, 0, 0, 10, 0.25, 6.5, '#334155');
    addBox(st, 0, 3.8, 0, 11.4, 0.5, 7.2, '#0284c7');
    addBox(st, 0, 4.3, 0, 11.6, 0.2, 7.4, '#fbbf24');
    [-4.2, 4.2].forEach((px) => addBox(st, px, 0.25, 0, 0.48, 3.6, 0.48, '#cbd5e1'));
    if (gs.hasGas) addBox(st, -2, 0.25, 0, 1.1, 2.0, 0.8, '#ef4444');
    if (gs.hasEV) addBox(st, 2, 0.25, 0, 1.1, 2.0, 0.8, '#10b981');
    createSignBoard(st, makeSignTexture(gs.name, '#0f172a', '#fbbf24'), 0, 4.8, 3.5, 7.5, 0.9);
    grp.add(st);
    collision.addBox(`gs_${gs.id}`, gs.x, gs.z, 6, 2.5, 'station');
    zones.push({
      id: `zone_${gs.id}`,
      label: `تعبئة وقود / شحن EV — ${gs.name}`,
      emoji: '⛽',
      x: gs.x,
      z: gs.z + 5,
      radius: 7.0,
      action: `gas:${gs.id}`,
    });
  });

  BUS_STOPS.forEach((bs) => {
    const grp = islandGroups[bs.islandId] || parent;
    const g = new THREE.Group();
    g.position.set(bs.x, 0, bs.z);
    addBox(g, 0, 0, 0, 6.5, 0.18, 2.8, '#cbd5e1');
    addBox(g, 0, 2.7, 0, 7.0, 0.28, 3.2, '#0284c7');
    addBox(g, 0, 0.18, -1.2, 6.2, 2.5, 0.14, '#93c5fd', { transparent: true, opacity: 0.45 });
    createSignBoard(g, makeSignTexture('🚌 ' + bs.name, '#0369a1', '#ffffff'), 0, 3.3, 1.5, 5.2, 0.75);
    grp.add(g);
    collision.addBox(`bs_${bs.id}`, bs.x, bs.z, 6.5, 2.5, 'busstop');
  });

  DIG_SPOTS.forEach((ds) => {
    const grp = islandGroups[ds.islandId] || parent;
    const g = new THREE.Group();
    g.position.set(ds.x, 0, ds.z);
    addCyl(g, 0, 0, 0, 3.2, 3.8, 0.45, '#b48a5a', 12);
    addBox(g, -1.6, 0.45, 0.6, 1.2, 0.9, 1.0, '#d6c3a1');
    addBox(g, 1.4, 0.45, -0.8, 0.9, 1.2, 0.9, '#c29b61');
    createSignBoard(g, makeSignTexture('⛏️ موقع تنقيب أثري', '#78350f', '#fde68a'), 0, 2.4, 0, 4.4, 0.75);
    grp.add(g);
    zones.push({
      id: `dig_${ds.id}`,
      label: `تنقيب أثري: ${ds.name}`,
      emoji: '⛏️',
      x: ds.x,
      z: ds.z,
      radius: 5.5,
      action: `dig:${ds.id}`,
    });
  });

  // 6. Populate Rich Scenic Groves, Hedges, Flowerbeds, Coastal Boulders, Benches & Lamps across ALL 6 Civilizations!
  Object.values(ISLANDS).forEach((isl) => {
    if (isl.id === 'ISL_HOME') return;
    const isPalm = isl.id === 'ISL_PORT' || isl.id === 'ISL_CITY' || isl.id === 'ISL_BUSINESS';

    // Dense scenic groves on outer ring + mid-field clearings
    for (let ring = 0; ring < 3; ring++) {
      const count = 46 - ring * 10;
      const baseR = isl.radius - 12 - ring * 34;
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2 + ring * 0.4 + (isl.cx % 3);
        const r = baseR + ((i % 3) - 1) * 7;
        const tx = isl.cx + Math.cos(a) * r;
        const tz = isl.cz + Math.sin(a) * r;
        if (!isZoneClear(tx, tz, 2.2, 2.2)) continue;
        const kind = isPalm
          ? i % 3 === 0
            ? 'cypress'
            : 'palm'
          : i % 4 === 0
          ? 'pine'
          : i % 3 === 0
          ? 'cypress'
          : 'round';
        nature.addTree(tx, tz, 0.92 + (i % 3) * 0.18, kind);
        if (ring === 0 && i % 2 === 0) {
          nature.addBush(isl.cx + Math.cos(a + 0.05) * (r - 6), isl.cz + Math.sin(a + 0.05) * (r - 6), 1.0);
        }
        if (ring === 0 && i % 5 === 0) {
          nature.addRock(isl.cx + Math.cos(a) * (isl.radius + 1.5), isl.cz + Math.sin(a) * (isl.radius + 1.5), 1.3 + (i % 2) * 0.5);
        }
      }
    }

    // Boulevard streetlamps, flowerbeds & benches along BOTH sides of E-W & N-S avenues
    [-110, -70, -35, 35, 70, 110].forEach((off, idx) => {
      const lx = isl.cx + off;
      [isl.cz - 10.5, isl.cz + 10.5].forEach((lz, side) => {
        if (isZoneClear(lx, lz, 1.5, 1.5)) {
          nature.addLamp(lx, lz, side === 0 ? Math.PI : 0);
          if (idx % 2 === 0) nature.addFlowerBed(lx + 7, lz, 0, idx + side);
          if (idx % 3 === 0 && isZoneClear(lx - 7, lz + (side === 0 ? -1.5 : 1.5), 1.5, 1.5)) {
            nature.addBench(lx - 7, lz + (side === 0 ? -1.5 : 1.5), side === 0 ? 0 : Math.PI);
          }
        }
      });
    });
    [-110, -70, -35, 35, 70, 110].forEach((off) => {
      const lz = isl.cz + off;
      [isl.cx - 10.5, isl.cx + 10.5].forEach((lx, side) => {
        if (isZoneClear(lx, lz, 1.5, 1.5)) {
          nature.addLamp(lx, lz, side === 0 ? Math.PI / 2 : -Math.PI / 2);
        }
      });
    });
  });

  const cropGroup = new THREE.Group();
  cropGroup.name = 'DynamicFarmCrops';
  parent.add(cropGroup);

  const placedGroup = new THREE.Group();
  placedGroup.name = 'DynamicPlacedBuildings';
  parent.add(placedGroup);

  return {
    doors,
    zones,
    anims,
    portCraneHook,
    portShipGroup,
    cropGroup,
    placedGroup,
    islandGroups,
  };
}

function buildCivilizationSite(
  s: SiteDef,
  parent: THREE.Group,
  collision: SpatialCollisionWorld,
  doors: AnimatedDoor[],
  zones: InteractiveZone[],
  anims: AnimatedProp[],
  stoneTex: THREE.CanvasTexture,
  darkStoneTex: THREE.CanvasTexture,
  roofTex: THREE.CanvasTexture,
  facadeWarm: THREE.CanvasTexture,
  facadeUrban: THREE.CanvasTexture,
  glassTex: THREE.CanvasTexture
): void {
  const g = new THREE.Group();
  g.position.set(s.x, 0, s.z);
  g.rotation.y = s.facing;

  const W = s.w;
  const D = s.d;
  const H = s.h;

  if (s.style === 'neoclassical_exchange' || s.style === 'central_bank') {
    // Stepped marble plinth + stairs
    addBox(g, 0, 0, 0, W + 3, 0.9, D + 3, '#d4c8ae', { map: stoneTex });
    addBox(g, 0, 0.15, D / 2 + 2.2, 11, 0.45, 2.2, '#e2d7c2');
    addBox(g, 0, 0.9, 0, W, H - 4.2, D, s.wallColor, { map: facadeWarm });
    addArchitecturalTrim(g, W, H - 4.2, D, 0.9, '#efe5d0', '#b7a88e');
    addDome(g, 0, H - 3.3, 0, Math.min(W, D) * 0.36, s.roofColor);
    // Classical front colonnade with bases & capitals
    for (let cx = -W / 2 + 3; cx <= W / 2 - 3; cx += 4.6) {
      addBox(g, cx, 0.9, D / 2 + 1.5, 1.4, 0.5, 1.4, '#d9cfc0');
      addCyl(g, cx, 1.4, D / 2 + 1.5, 0.5, 0.62, H - 5.8, '#f5efe2', 12);
      addBox(g, cx, H - 4.4, D / 2 + 1.5, 1.45, 0.45, 1.45, '#d9cfc0');
    }
    // Pediment frieze + triangular roof crest
    addBox(g, 0, H - 4.0, D / 2 + 1.5, W + 0.8, 1.5, 3.4, '#e8dec9');
    addRoofPyramid(g, 0, H - 2.5, D / 2 + 1.4, W + 1.2, 2.6, 3.6, s.roofColor);
    addFacadeWindows(g, W, H - 4.2, D, 0.9, 2, { skipCenterGroundDoor: true });
    addRooftopDetails(g, W, H - 3.3, D, 'civic');
  } else if (s.style === 'hq_tower' || s.style === 'hotel') {
    // Double-height grand lobby podium with glazed entrance awning
    addBox(g, 0, 0, 0, W + 1.4, 4.8, D + 1.4, '#cbd5e1', { map: stoneTex });
    addArchitecturalTrim(g, W + 1.4, 4.8, D + 1.4, 0, '#e2e8f0', '#64748b');
    addBox(g, 0, 3.6, D / 2 + 1.8, 10, 0.35, 3.2, '#38bdf8', { transparent: true, opacity: 0.55 });
    // Main glass curtain wall shaft + structural corner mullions
    const midH = (H - 4.8) * 0.72;
    addBox(g, 0, 4.8, 0, W - 1.6, midH, D - 1.6, s.wallColor, { map: glassTex, roughness: 0.16, metalness: 0.45 });
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
      addBox(g, sx * ((W - 1.6) / 2), 4.8, sz * ((D - 1.6) / 2), 0.9, midH, 0.9, '#94a3b8');
    });
    // Setback executive upper tier
    const topH = (H - 4.8) * 0.28;
    addBox(g, 0, 4.8 + midH, 0, W - 4.8, topH, D - 4.8, s.wallColor, { map: glassTex, roughness: 0.16, metalness: 0.5 });
    addBox(g, 0, H, 0, W - 4.0, 1.3, D - 4.0, s.roofColor);
    if (s.style === 'hq_tower') {
      addCyl(g, 0, H + 1.3, 0, 6.0, 6.0, 0.3, '#334155', 18);
      addCyl(g, 0, H + 1.6, 0, 4.8, 4.8, 0.08, '#fbbf24', 18);
      addCyl(g, 0, H + 1.6, 0, 0.25, 0.4, 7.5, '#fbbf24', 8);
    } else {
      addDome(g, 0, H + 1.3, 0, 5.2, '#b45309');
    }
  } else if (s.style === 'glass_factory') {
    // Flagship Al-Noor Glass Factory exterior!
    addBox(g, 0, 0, 0, W, H * 0.72, D, '#e2e8f0', { map: facadeUrban });
    addArchitecturalTrim(g, W, H * 0.72, D, 0, '#94a3b8', '#475569');
    // Structural steel vertical buttresses along front & back
    for (let bx = -W / 2 + 4; bx <= W / 2 - 4; bx += 7.5) {
      addBox(g, bx, 0, D / 2 + 0.2, 0.7, H * 0.72, 0.5, '#334155', { metalness: 0.65 });
      addBox(g, bx, 0, -D / 2 - 0.2, 0.7, H * 0.72, 0.5, '#334155', { metalness: 0.65 });
    }
    // Sawtooth skylight roof bays with glowing glass monitors
    const bays = 4;
    for (let i = 0; i < bays; i++) {
      const bx = -W / 2 + (i + 0.5) * (W / bays);
      addRoofPyramid(g, bx, H * 0.72, 0, W / bays - 0.4, 4.4, D - 0.8, '#0284c7');
      addBox(g, bx, H * 0.72 + 1.2, D / 2 - 1.2, W / bays - 2.2, 1.4, 0.3, '#7dd3fc', { emissive: '#fef3c7', emissiveIntensity: 0.35 });
    }
    // Twin towering furnace smokestacks with heat rings & glowing furnace viewing windows
    [-12, 12].forEach((sx) => {
      addCyl(g, sx, 0, -D / 2 + 4, 1.3, 2.0, H + 12, '#475569', 12);
      addCyl(g, sx, H + 9.5, -D / 2 + 4, 1.5, 1.5, 1.2, '#f97316', 12);
      addBox(g, sx, 1.4, D / 2 + 0.25, 6.6, 3.2, 0.35, '#f97316', { emissive: '#ea580c', emissiveIntensity: 0.85 });
      addBox(g, sx, 1.4, D / 2 + 0.4, 6.9, 0.35, 0.4, '#1e293b');
    });
    // Raw Silica Silos with catwalk pipe bridge
    [-5, 5].forEach((sz) => {
      addCyl(g, -W / 2 - 4.5, 0, sz, 3.4, 3.4, 13.5, '#cbd5e1', 14);
      addDome(g, -W / 2 - 4.5, 13.5, sz, 3.4, '#f59e0b');
    });
    addBox(g, -W / 2 - 2.2, 11.2, 0, 5.5, 0.6, 12, '#64748b', { metalness: 0.6 });
    addBox(g, 11, 3.8, D / 2 + 1.8, 10, 0.4, 4.2, '#94a3b8');
  } else if (s.style.endsWith('_factory') || s.style === 'garage') {
    addBox(g, 0, 0, 0, W, H * 0.78, D, s.wallColor, { map: facadeUrban });
    addArchitecturalTrim(g, W, H * 0.78, D, 0, '#94a3b8', '#475569');
    addRoofPyramid(g, 0, H * 0.78, 0, W + 1.5, 3.8, D + 1.5, s.roofColor, { map: roofTex });
    addRooftopDetails(g, W, H * 0.78, D, 'industrial');
    addFacadeWindows(g, W, H * 0.78, D, 0, 1, { skipCenterGroundDoor: true });
    if (s.style === 'steel_factory' || s.style === 'pottery_factory') {
      addCyl(g, -W / 3, 0, -D / 3, 1.2, 1.8, H + 10, '#334155', 10);
      addCyl(g, W / 3, 0, -D / 3, 1.2, 1.8, H + 8, '#334155', 10);
    } else if (s.style === 'elec_factory') {
      addDome(g, 0, H * 0.78 + 1.5, 0, 4.2, '#38bdf8');
    } else if (s.style === 'food_factory') {
      addCyl(g, W / 2 + 3.5, 0, -3, 2.8, 2.8, 11, '#fef3c7', 12);
      addDome(g, W / 2 + 3.5, 11, -3, 2.8, '#b45309');
    }
  } else if (s.style === 'lighthouse') {
    addBox(g, 0, 0, 0, 14, 1.4, 14, '#cbd5e1', { map: stoneTex });
    addCyl(g, 0, 1.4, 0, 4.2, 6.2, H - 7.4, '#f8fafc', 16);
    addCyl(g, 0, H * 0.42, 0, 5.0, 5.4, 4.2, '#dc2626', 16);
    // Gallery balcony around lantern
    addCyl(g, 0, H - 6.3, 0, 5.4, 4.6, 0.6, '#1e293b', 16);
    addCyl(g, 0, H - 5.7, 0, 3.2, 3.2, 4.2, '#fef08a', 12, { emissive: '#fde047', emissiveIntensity: 1.2 });
    addRoofPyramid(g, 0, H - 1.5, 0, 7.6, 3.6, 7.6, '#dc2626');
    const beacon = new THREE.Group();
    beacon.position.set(0, H - 3.6, 0);
    const beam = new THREE.Mesh(
      new THREE.ConeGeometry(4.5, 24, 12),
      getMat('#fef08a', { transparent: true, opacity: 0.16, emissive: '#fef08a', emissiveIntensity: 0.7 })
    );
    beam.rotation.z = Math.PI / 2;
    beam.position.x = 12;
    beacon.add(beam);
    g.add(beacon);
    anims.push({ kind: 'spinY', mesh: beacon, speed: 1.1 });
  } else if (s.style === 'temple' || s.style === 'colonnade' || s.style === 'museum') {
    addBox(g, 0, 0, 0, W + 4, 1.3, D + 4, '#cbb68e', { map: stoneTex });
    addBox(g, 0, 0.25, D / 2 + 2.4, 10, 0.6, 2.2, '#d8c5a0');
    addBox(g, 0, 1.3, 0, W - 4, H - 4.2, D - 4, s.wallColor, { map: stoneTex });
    addArchitecturalTrim(g, W - 4, H - 4.2, D - 4, 1.3, '#e5d4b0', '#b79f78');
    for (let cx = -W / 2 + 2; cx <= W / 2 - 2; cx += 4.2) {
      addBox(g, cx, 1.3, D / 2 + 0.2, 1.3, 0.45, 1.3, '#d6c19b');
      addCyl(g, cx, 1.75, D / 2 + 0.2, 0.52, 0.68, H - 4.8, '#efe2c6', 10);
      addCyl(g, cx, 1.75, -D / 2 - 0.2, 0.52, 0.68, H - 4.8, '#efe2c6', 10);
    }
    addRoofPyramid(g, 0, H - 2.9, 0, W + 2, 3.8, D + 2, s.roofColor, { map: roofTex });
    if (s.style === 'museum') {
      addDome(g, 0, H - 2.9, 0, 5.2, '#38bdf8');
    }
  } else if (s.style === 'palace' || s.style === 'university' || s.style === 'library') {
    addBox(g, 0, 0, 0, W + 2, 0.9, D + 2, '#d4c8ae');
    addBox(g, 0, 0.9, 0, W, H * 0.65, D, s.wallColor, { map: facadeWarm });
    addArchitecturalTrim(g, W, H * 0.65, D, 0.9, '#e7dcc8', '#b7a88e');
    addDome(g, 0, H * 0.65 + 0.9, 0, Math.min(W, D) * 0.36, s.roofColor);
    [-W * 0.34, W * 0.34].forEach((wx) => {
      addBox(g, wx, 0.9, 0, 8.5, H * 0.62, D + 1.2, s.wallColor, { map: facadeWarm });
      addArchitecturalTrim(g, 8.5, H * 0.62, D + 1.2, 0.9, '#e7dcc8', '#b7a88e');
      addDome(g, wx, H * 0.62 + 0.9, 0, 3.8, s.roofColor);
    });
    addFacadeWindows(g, W, H * 0.65, D, 0.9, 2, { skipCenterGroundDoor: true });
    addBalcony(g, 0, H * 0.36, D / 2, 10, 2.2, 0, '#fbbf24');
  } else {
    // Rich detailed Civic, Commercial, Hospital, Police, Mall, Barn, Customs, Market, Restaurant
    addBox(g, 0, 0, 0, W, H * 0.78, D, s.wallColor, { map: s.kind === 'commercial' ? facadeUrban : facadeWarm });
    addArchitecturalTrim(g, W, H * 0.78, D, 0, '#dfd4be', '#9c8f78');
    addRoofPyramid(g, 0, H * 0.78, 0, W + 1.4, 3.4, D + 1.4, s.roofColor, { map: roofTex });
    addFacadeWindows(g, W, H * 0.78, D, 0, H > 12 ? 2 : 1, { skipCenterGroundDoor: true });
    addRooftopDetails(g, W, H * 0.78, D, s.kind === 'commercial' ? 'commercial' : 'civic');

    if (s.kind === 'market' || s.style === 'restaurant' || s.style === 'mall') {
      addShopAwning(g, 0, 3.8, D / 2, W * 0.75, s.roofColor, '#fef3c7');
    }
    if (s.style === 'hospital') {
      // Glowing Red Cross rooftop sign + front ambulance canopy
      addBox(g, 0, H * 0.78 + 2.8, D / 2 - 1, 5.2, 1.4, 0.4, '#ef4444', { emissive: '#ef4444', emissiveIntensity: 0.5 });
      addBox(g, 0, H * 0.78 + 1.2, D / 2 - 1, 1.4, 4.8, 0.4, '#ef4444', { emissive: '#ef4444', emissiveIntensity: 0.5 });
    } else if (s.style === 'police') {
      // Twin blue/red roof beacons
      addBox(g, -2.5, H * 0.78 + 2.4, D / 2 - 2, 1.8, 0.8, 1.8, '#2563eb', { emissive: '#3b82f6', emissiveIntensity: 0.9 });
      addBox(g, 2.5, H * 0.78 + 2.4, D / 2 - 2, 1.8, 0.8, 1.8, '#dc2626', { emissive: '#ef4444', emissiveIntensity: 0.9 });
    } else if (s.style === 'windmill_village') {
      addCyl(g, 0, 0, 0, 4.8, 6.2, H, '#efe2c8', 12, { map: stoneTex });
      addDome(g, 0, H, 0, 4.9, '#b45309');
    }
  }

  // Prominent Arabic Signboard above entrance
  createSignBoard(
    g,
    makeSignTexture(`${s.emoji} ${s.name}`, '#0f172a', '#fbbf24', '#f59e0b'),
    0,
    Math.min(H - 1.2, 7.8),
    D / 2 + 0.55,
    Math.min(W * 0.78, 16),
    1.8
  );

  // Hinged Animated Door & Interactive Zone
  if (s.interiorId || s.actionType) {
    const door = createHingedDoor(
      g,
      `door_${s.id}`,
      0,
      0.1,
      D / 2 + 0.14,
      3.4,
      3.8,
      '#5c3a21',
      s.doorX,
      s.doorZ,
      s.interiorId ? `دخول ${s.name}` : s.name,
      s.interiorId,
      s.actionType
    );
    doors.push(door);
    zones.push({
      id: `zone_${s.id}`,
      label: s.interiorId ? `دخول ${s.name}` : s.name,
      emoji: s.emoji,
      x: s.frontX,
      z: s.frontZ,
      radius: 5.5,
      action: s.interiorId ? `enter:${s.interiorId}` : s.actionType!,
    });
  }

  parent.add(g);

  const rot90 = Math.abs(Math.sin(s.facing)) > 0.7;
  collision.addBox(`site_${s.id}`, s.x, s.z, rot90 ? D + 0.6 : W + 0.6, rot90 ? W + 0.6 : D + 0.6, 'building');
}

export function syncDynamicWorldMeshes(
  cropGroup: THREE.Group,
  placedGroup: THREE.Group,
  collision: SpatialCollisionWorld,
  state: GameState
): void {
  while (cropGroup.children.length > 0) cropGroup.remove(cropGroup.children[0]);
  const now = Date.now();

  FARM_PARCELS.forEach((p) => {
    const owned = state.ownedParcels.includes(p.id);
    const activePlot = state.farmPlots[p.id];

    const soil = new THREE.Mesh(
      new THREE.BoxGeometry(p.w, 0.14, p.d),
      getMat(owned ? '#6b4423' : '#a39678', { roughness: 0.92 })
    );
    soil.position.set(p.x, 0.07, p.z);
    soil.receiveShadow = true;
    cropGroup.add(soil);

    // Low wooden parcel border rails
    addBox(cropGroup, p.x, 0.14, p.z - p.d / 2 + 0.15, p.w, 0.35, 0.25, '#78350f');
    addBox(cropGroup, p.x, 0.14, p.z + p.d / 2 - 0.15, p.w, 0.35, 0.25, '#78350f');

    if (activePlot) {
      const crop = CROPS[activePlot.cropId] || CROPS.wheat;
      const pct = Math.min(1, Math.max(0.15, (now - activePlot.plantedAt) / (activePlot.growSec * 1000)));
      const h = 0.45 + pct * 1.45;
      for (let rx = -8; rx <= 8; rx += 5.5) {
        const rowMesh = new THREE.Mesh(
          new THREE.BoxGeometry(2.2, h, p.d - 4),
          getMat(pct >= 1 ? crop.color : '#4d7c0f', { roughness: 0.75 })
        );
        rowMesh.position.set(p.x + rx, 0.14 + h / 2, p.z);
        rowMesh.castShadow = true;
        cropGroup.add(rowMesh);
      }
    }
  });

  while (placedGroup.children.length > 0) placedGroup.remove(placedGroup.children[0]);
  collision.removeByIdPrefix('placed_');

  state.placedBuildings.forEach((b) => {
    const bp = BUILDER_BLUEPRINTS.find((x) => x.id === b.blueprintId);
    if (!bp) return;
    const g = new THREE.Group();
    g.position.set(b.x, 0, b.z);
    g.rotation.y = b.ry;

    if (b.stage === 1) {
      addBox(g, 0, 0, 0, bp.w, 0.5, bp.d, '#94a3b8');
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
        addBox(g, sx * (bp.w / 2 - 0.5), 0.5, sz * (bp.d / 2 - 0.5), 0.4, 4.5, 0.4, '#f59e0b');
      });
    } else if (b.stage === 2) {
      addBox(g, 0, 0, 0, bp.w, bp.h * 0.6, bp.d, bp.color, { transparent: true, opacity: 0.85 });
    } else {
      addBox(g, 0, 0, 0, bp.w, bp.h, bp.d, bp.color);
      addArchitecturalTrim(g, bp.w, bp.h, bp.d, 0);
      addFacadeWindows(g, bp.w, bp.h, bp.d, 0, 1, { skipCenterGroundDoor: true });
      addRoofPyramid(g, 0, bp.h, 0, bp.w + 0.8, 2.5, bp.d + 0.8, bp.roofColor);
      addBox(g, 0, 0, bp.d / 2 + 0.1, 2.2, 2.8, 0.15, '#5c3a21');
    }

    placedGroup.add(g);
    collision.addBox(`placed_${b.uid}`, b.x, b.z, bp.w + 0.4, bp.d + 0.4, 'placed_building');
  });
}
