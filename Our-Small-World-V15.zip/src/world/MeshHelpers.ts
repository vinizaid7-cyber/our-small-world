import * as THREE from 'three';

export interface AnimatedDoor {
  id: string;
  pivot: THREE.Group;
  closedAngle: number;
  openAngle: number;
  isOpen: boolean;
  worldX: number;
  worldZ: number;
  interiorId?: string;
  actionType?: string;
  label: string;
}

export interface AnimatedProp {
  kind: 'spinZ' | 'spinY' | 'bobY' | 'orbit' | 'sway';
  mesh: THREE.Object3D;
  speed: number;
  amp?: number;
  baseY?: number;
  phase?: number;
}

export interface InteractiveZone {
  id: string;
  label: string;
  emoji: string;
  x: number;
  z: number;
  radius: number;
  action: string;
}

const matCache = new Map<string, THREE.Material>();

export function getMat(
  color: string | number,
  opts?: {
    roughness?: number;
    metalness?: number;
    transparent?: boolean;
    opacity?: number;
    emissive?: string | number;
    emissiveIntensity?: number;
    map?: THREE.Texture;
  }
): THREE.MeshStandardMaterial {
  const key = JSON.stringify({ c: color, ...opts, map: opts?.map?.uuid });
  const existing = matCache.get(key);
  if (existing) return existing as THREE.MeshStandardMaterial;
  const mat = new THREE.MeshStandardMaterial({
    color,
    roughness: opts?.roughness ?? 0.72,
    metalness: opts?.metalness ?? 0.08,
    transparent: opts?.transparent ?? false,
    opacity: opts?.opacity ?? 1,
    emissive: opts?.emissive ?? 0x000000,
    emissiveIntensity: opts?.emissiveIntensity ?? 0,
    map: opts?.map ?? null,
  });
  matCache.set(key, mat);
  return mat;
}

export function addBox(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  color: string | number,
  opts?: Parameters<typeof getMat>[1] & { castShadow?: boolean; receiveShadow?: boolean }
): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), getMat(color, opts));
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = opts?.castShadow ?? true;
  mesh.receiveShadow = opts?.receiveShadow ?? true;
  parent.add(mesh);
  return mesh;
}

export function addCyl(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  rTop: number,
  rBot: number,
  h: number,
  color: string | number,
  seg = 12,
  opts?: Parameters<typeof getMat>[1] & { castShadow?: boolean; receiveShadow?: boolean }
): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, h, seg), getMat(color, opts));
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = opts?.castShadow ?? true;
  mesh.receiveShadow = opts?.receiveShadow ?? true;
  parent.add(mesh);
  return mesh;
}

export function addRoofPyramid(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  color: string | number,
  opts?: Parameters<typeof getMat>[1]
): THREE.Mesh {
  const mesh = new THREE.Mesh(
    new THREE.ConeGeometry(Math.max(w, d) * 0.72, h, 4),
    getMat(color, { roughness: 0.72, ...opts })
  );
  mesh.position.set(x, y + h / 2, z);
  mesh.rotation.y = Math.PI / 4;
  mesh.scale.set(w / Math.max(w, d), 1, d / Math.max(w, d));
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

export function addDome(
  parent: THREE.Object3D,
  x: number,
  y: number,
  z: number,
  radius: number,
  color: string | number,
  finial = true
): THREE.Mesh {
  const geom = new THREE.SphereGeometry(radius, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2);
  const mesh = new THREE.Mesh(geom, getMat(color, { roughness: 0.35, metalness: 0.32 }));
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  parent.add(mesh);

  // Decorative collar ring & golden spire finial
  if (finial) {
    addCyl(parent, x, y - 0.35, z, radius * 1.04, radius * 1.06, 0.55, '#e7dcc8', 18);
    addCyl(parent, x, y + radius * 0.94, z, 0.08, 0.16, Math.max(1.2, radius * 0.35), '#fbbf24', 8, {
      metalness: 0.85,
      roughness: 0.2,
    });
    const orb = new THREE.Mesh(
      new THREE.SphereGeometry(Math.max(0.24, radius * 0.09), 10, 10),
      getMat('#fbbf24', { metalness: 0.9, roughness: 0.18 })
    );
    orb.position.set(x, y + radius * 0.96, z);
    parent.add(orb);
  }
  return mesh;
}

export function createHingedDoor(
  parent: THREE.Object3D,
  id: string,
  localX: number,
  localY: number,
  localZ: number,
  w: number,
  h: number,
  doorColor: string,
  worldX: number,
  worldZ: number,
  label: string,
  interiorId?: string,
  actionType?: string
): AnimatedDoor {
  // Ornate architrave stone/wood frame
  addBox(parent, localX - w / 2 - 0.18, localY, localZ, 0.34, h + 0.35, 0.44, '#5c3a21');
  addBox(parent, localX + w / 2 + 0.18, localY, localZ, 0.34, h + 0.35, 0.44, '#5c3a21');
  addBox(parent, localX, localY + h, localZ, w + 0.72, 0.38, 0.52, '#784826');
  // Side wall lanterns
  [-w / 2 - 0.55, w / 2 + 0.55].forEach((lx) => {
    addBox(parent, localX + lx, localY + h * 0.65, localZ + 0.2, 0.22, 0.36, 0.22, '#fef08a', {
      emissive: '#fbbf24',
      emissiveIntensity: 0.75,
    });
  });

  const pivot = new THREE.Group();
  pivot.position.set(localX - w / 2, localY, localZ);
  const leaf = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, 0.16),
    getMat(doorColor, { roughness: 0.45, metalness: 0.15 })
  );
  leaf.position.set(w / 2, h / 2, 0);
  leaf.castShadow = true;
  pivot.add(leaf);

  // Decorative recessed trim panel on door leaf
  const trim = new THREE.Mesh(
    new THREE.BoxGeometry(w * 0.72, h * 0.75, 0.04),
    getMat('#9a6234', { roughness: 0.55 })
  );
  trim.position.set(w / 2, h / 2, 0.09);
  pivot.add(trim);

  // Brass handle
  const handle = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 8, 8),
    getMat('#fbbf24', { metalness: 0.88, roughness: 0.2 })
  );
  handle.position.set(w - 0.28, h * 0.48, 0.14);
  pivot.add(handle);

  parent.add(pivot);

  return {
    id,
    pivot,
    closedAngle: 0,
    openAngle: -Math.PI * 0.56,
    isOpen: false,
    worldX,
    worldZ,
    interiorId,
    actionType,
    label,
  };
}

export function createSignBoard(
  parent: THREE.Object3D,
  texture: THREE.CanvasTexture,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  ry = 0
): THREE.Mesh {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, 0.22),
    [
      getMat('#1e293b'),
      getMat('#1e293b'),
      getMat('#1e293b'),
      getMat('#1e293b'),
      new THREE.MeshStandardMaterial({ map: texture, roughness: 0.4 }),
      new THREE.MeshStandardMaterial({ map: texture, roughness: 0.4 }),
    ]
  );
  mesh.position.set(x, y, z);
  mesh.rotation.y = ry;
  parent.add(mesh);
  return mesh;
}

export class InstancedNatureBuilder {
  private roundTrees: Array<{ x: number; z: number; s: number }> = [];
  private palmTrees: Array<{ x: number; z: number; s: number }> = [];
  private pineTrees: Array<{ x: number; z: number; s: number }> = [];
  private cypressTrees: Array<{ x: number; z: number; s: number }> = [];
  private lamps: Array<{ x: number; z: number; ry: number }> = [];
  private bushes: Array<{ x: number; z: number; s: number }> = [];
  private flowerBeds: Array<{ x: number; z: number; ry: number; colorIdx: number }> = [];
  private rocks: Array<{ x: number; z: number; s: number }> = [];
  private benches: Array<{ x: number; z: number; ry: number }> = [];
  private crates: Array<{ x: number; z: number; s: number }> = [];

  public addTree(x: number, z: number, scale = 1, kind: 'round' | 'palm' | 'pine' | 'cypress' = 'round'): void {
    if (kind === 'palm') this.palmTrees.push({ x, z, s: scale });
    else if (kind === 'pine') this.pineTrees.push({ x, z, s: scale });
    else if (kind === 'cypress') this.cypressTrees.push({ x, z, s: scale });
    else this.roundTrees.push({ x, z, s: scale });
  }

  public addLamp(x: number, z: number, ry = 0): void {
    this.lamps.push({ x, z, ry });
  }

  public addBush(x: number, z: number, s = 1): void {
    this.bushes.push({ x, z, s });
  }

  public addFlowerBed(x: number, z: number, ry = 0, colorIdx = 0): void {
    this.flowerBeds.push({ x, z, ry, colorIdx });
  }

  public addRock(x: number, z: number, s = 1): void {
    this.rocks.push({ x, z, s });
  }

  public addBench(x: number, z: number, ry = 0): void {
    this.benches.push({ x, z, ry });
  }

  public addCrate(x: number, z: number, s = 1): void {
    this.crates.push({ x, z, s });
  }

  public build(group: THREE.Group): { lampBulbMat: THREE.MeshStandardMaterial } {
    const dummy = new THREE.Object3D();

    // 1. Multi-layered lush Round Trees
    if (this.roundTrees.length > 0) {
      const trunkGeo = new THREE.CylinderGeometry(0.24, 0.42, 2.7, 7);
      const crownGeo1 = new THREE.DodecahedronGeometry(1.75, 1);
      const crownGeo2 = new THREE.DodecahedronGeometry(1.3, 1);
      const trunks = new THREE.InstancedMesh(trunkGeo, getMat('#664021', { roughness: 0.9 }), this.roundTrees.length);
      const crowns1 = new THREE.InstancedMesh(crownGeo1, getMat('#2d7a31', { roughness: 0.8 }), this.roundTrees.length);
      const crowns2 = new THREE.InstancedMesh(crownGeo2, getMat('#3d9640', { roughness: 0.78 }), this.roundTrees.length);
      trunks.castShadow = true;
      crowns1.castShadow = true;
      crowns2.castShadow = true;
      this.roundTrees.forEach((t, i) => {
        dummy.position.set(t.x, 1.35 * t.s, t.z);
        dummy.scale.set(t.s, t.s, t.s);
        dummy.rotation.set(0, (i * 1.1) % Math.PI, 0);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 3.4 * t.s, t.z);
        dummy.scale.set(t.s, t.s * 0.92, t.s);
        dummy.updateMatrix();
        crowns1.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x + 0.55 * t.s, 4.15 * t.s, t.z + 0.35 * t.s);
        dummy.scale.set(t.s, t.s, t.s);
        dummy.updateMatrix();
        crowns2.setMatrixAt(i, dummy.matrix);
      });
      group.add(trunks, crowns1, crowns2);
    }

    // 2. Palm Trees (trunk + layered frond crown + coconuts)
    if (this.palmTrees.length > 0) {
      const trunkGeo = new THREE.CylinderGeometry(0.2, 0.38, 5.8, 7);
      const frondGeo = new THREE.ConeGeometry(2.5, 1.4, 7);
      const topFrondGeo = new THREE.ConeGeometry(1.8, 1.1, 6);
      const trunks = new THREE.InstancedMesh(trunkGeo, getMat('#8c6239', { roughness: 0.9 }), this.palmTrees.length);
      const fronds = new THREE.InstancedMesh(frondGeo, getMat('#3b8d3f', { roughness: 0.78 }), this.palmTrees.length);
      const topFronds = new THREE.InstancedMesh(topFrondGeo, getMat('#4da350', { roughness: 0.75 }), this.palmTrees.length);
      trunks.castShadow = true;
      fronds.castShadow = true;
      this.palmTrees.forEach((t, i) => {
        dummy.position.set(t.x, 2.9 * t.s, t.z);
        dummy.scale.set(t.s, t.s, t.s);
        dummy.rotation.set(0.06, (i * 1.7) % 6.28, 0.04);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 5.7 * t.s, t.z);
        dummy.rotation.set(0, (i * 0.9) % 6.28, 0);
        dummy.updateMatrix();
        fronds.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 6.25 * t.s, t.z);
        dummy.rotation.set(0, (i * 0.9 + 0.4) % 6.28, 0);
        dummy.updateMatrix();
        topFronds.setMatrixAt(i, dummy.matrix);
      });
      group.add(trunks, fronds, topFronds);
    }

    // 3. Tiered Pine Trees
    if (this.pineTrees.length > 0) {
      const trunkGeo = new THREE.CylinderGeometry(0.2, 0.34, 2.2, 6);
      const cone1Geo = new THREE.ConeGeometry(1.9, 3.0, 7);
      const cone2Geo = new THREE.ConeGeometry(1.35, 2.6, 7);
      const trunks = new THREE.InstancedMesh(trunkGeo, getMat('#5b3a1f'), this.pineTrees.length);
      const cones1 = new THREE.InstancedMesh(cone1Geo, getMat('#1f5e3b'), this.pineTrees.length);
      const cones2 = new THREE.InstancedMesh(cone2Geo, getMat('#277349'), this.pineTrees.length);
      cones1.castShadow = true;
      cones2.castShadow = true;
      this.pineTrees.forEach((t, i) => {
        dummy.position.set(t.x, 1.1 * t.s, t.z);
        dummy.scale.set(t.s, t.s, t.s);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 3.0 * t.s, t.z);
        dummy.updateMatrix();
        cones1.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 4.6 * t.s, t.z);
        dummy.updateMatrix();
        cones2.setMatrixAt(i, dummy.matrix);
      });
      group.add(trunks, cones1, cones2);
    }

    // 4. Mediterranean Cypress Trees (tall slim architectural accent)
    if (this.cypressTrees.length > 0) {
      const trunkGeo = new THREE.CylinderGeometry(0.16, 0.24, 1.4, 6);
      const bodyGeo = new THREE.ConeGeometry(0.9, 6.2, 8);
      const trunks = new THREE.InstancedMesh(trunkGeo, getMat('#5b3a1f'), this.cypressTrees.length);
      const bodies = new THREE.InstancedMesh(bodyGeo, getMat('#1b4d32', { roughness: 0.85 }), this.cypressTrees.length);
      bodies.castShadow = true;
      this.cypressTrees.forEach((t, i) => {
        dummy.position.set(t.x, 0.7 * t.s, t.z);
        dummy.scale.set(t.s, t.s, t.s);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);

        dummy.position.set(t.x, 4.1 * t.s, t.z);
        dummy.updateMatrix();
        bodies.setMatrixAt(i, dummy.matrix);
      });
      group.add(trunks, bodies);
    }

    // 5. Hedges / Bushes
    if (this.bushes.length > 0) {
      const geo = new THREE.DodecahedronGeometry(0.85, 1);
      const mesh = new THREE.InstancedMesh(geo, getMat('#368038', { roughness: 0.85 }), this.bushes.length);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.bushes.forEach((b, i) => {
        dummy.position.set(b.x, 0.52 * b.s, b.z);
        dummy.scale.set(b.s * 1.15, b.s * 0.78, b.s);
        dummy.rotation.set(0, i * 0.7, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      });
      group.add(mesh);
    }

    // 6. Manicured Flowerbeds (stone planter + green bed + colorful blossoms)
    if (this.flowerBeds.length > 0) {
      const planterGeo = new THREE.BoxGeometry(3.2, 0.42, 1.4);
      const bloomGeo = new THREE.BoxGeometry(2.8, 0.36, 1.0);
      const planters = new THREE.InstancedMesh(planterGeo, getMat('#d6cbb5', { roughness: 0.8 }), this.flowerBeds.length);
      const blooms = new THREE.InstancedMesh(bloomGeo, getMat('#f43f5e', { roughness: 0.7 }), this.flowerBeds.length);
      const palette = [new THREE.Color('#f43f5e'), new THREE.Color('#f59e0b'), new THREE.Color('#a855f7'), new THREE.Color('#ec4899')];
      this.flowerBeds.forEach((fb, i) => {
        dummy.position.set(fb.x, 0.21, fb.z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, fb.ry, 0);
        dummy.updateMatrix();
        planters.setMatrixAt(i, dummy.matrix);

        dummy.position.set(fb.x, 0.52, fb.z);
        dummy.updateMatrix();
        blooms.setMatrixAt(i, dummy.matrix);
        blooms.setColorAt(i, palette[fb.colorIdx % palette.length]);
      });
      if (blooms.instanceColor) blooms.instanceColor.needsUpdate = true;
      group.add(planters, blooms);
    }

    // 7. Coastal & Scenic Rocks / Boulders
    if (this.rocks.length > 0) {
      const rockGeo = new THREE.DodecahedronGeometry(1.1, 0);
      const mesh = new THREE.InstancedMesh(rockGeo, getMat('#78716c', { roughness: 0.92 }), this.rocks.length);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.rocks.forEach((r, i) => {
        dummy.position.set(r.x, 0.4 * r.s, r.z);
        dummy.scale.set(r.s * 1.3, r.s * 0.72, r.s);
        dummy.rotation.set(i * 0.3, i * 1.1, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
      });
      group.add(mesh);
    }

    // 8. Park Benches
    if (this.benches.length > 0) {
      const seatGeo = new THREE.BoxGeometry(2.4, 0.16, 0.8);
      const backGeo = new THREE.BoxGeometry(2.4, 0.55, 0.12);
      const seats = new THREE.InstancedMesh(seatGeo, getMat('#7c3f16', { roughness: 0.7 }), this.benches.length);
      const backs = new THREE.InstancedMesh(backGeo, getMat('#5c2e0f', { roughness: 0.75 }), this.benches.length);
      seats.castShadow = true;
      this.benches.forEach((bn, i) => {
        dummy.position.set(bn.x, 0.48, bn.z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, bn.ry, 0);
        dummy.updateMatrix();
        seats.setMatrixAt(i, dummy.matrix);

        const bx = bn.x - Math.sin(bn.ry) * 0.35;
        const bz = bn.z - Math.cos(bn.ry) * 0.35;
        dummy.position.set(bx, 0.82, bz);
        dummy.updateMatrix();
        backs.setMatrixAt(i, dummy.matrix);
      });
      group.add(seats, backs);
    }

    // 9. Wooden Crates / Cargo Props
    if (this.crates.length > 0) {
      const crateGeo = new THREE.BoxGeometry(1.2, 1.1, 1.2);
      const cratesMesh = new THREE.InstancedMesh(crateGeo, getMat('#9a6532', { roughness: 0.85 }), this.crates.length);
      cratesMesh.castShadow = true;
      this.crates.forEach((c, i) => {
        dummy.position.set(c.x, 0.55 * c.s, c.z);
        dummy.scale.set(c.s, c.s, c.s);
        dummy.rotation.set(0, (i * 0.5) % Math.PI, 0);
        dummy.updateMatrix();
        cratesMesh.setMatrixAt(i, dummy.matrix);
      });
      group.add(cratesMesh);
    }

    // 10. Ornate Streetlamps (base plinth + fluted pole + crossarm + glowing lantern)
    const lampBulbMat = getMat('#fff3c4', { emissive: '#ffdf85', emissiveIntensity: 0.3 });
    if (this.lamps.length > 0) {
      const baseGeo = new THREE.CylinderGeometry(0.24, 0.34, 0.7, 8);
      const poleGeo = new THREE.CylinderGeometry(0.11, 0.16, 4.7, 8);
      const armGeo = new THREE.BoxGeometry(1.1, 0.12, 0.12);
      const bulbGeo = new THREE.SphereGeometry(0.32, 8, 8);
      const ironMat = getMat('#1f2937', { metalness: 0.65, roughness: 0.38 });
      const bases = new THREE.InstancedMesh(baseGeo, ironMat, this.lamps.length);
      const poles = new THREE.InstancedMesh(poleGeo, ironMat, this.lamps.length);
      const arms = new THREE.InstancedMesh(armGeo, ironMat, this.lamps.length);
      const bulbs = new THREE.InstancedMesh(bulbGeo, lampBulbMat, this.lamps.length);
      poles.castShadow = true;
      this.lamps.forEach((l, i) => {
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, l.ry, 0);

        dummy.position.set(l.x, 0.35, l.z);
        dummy.updateMatrix();
        bases.setMatrixAt(i, dummy.matrix);

        dummy.position.set(l.x, 2.7, l.z);
        dummy.updateMatrix();
        poles.setMatrixAt(i, dummy.matrix);

        dummy.position.set(l.x, 5.05, l.z);
        dummy.updateMatrix();
        arms.setMatrixAt(i, dummy.matrix);

        dummy.position.set(l.x, 5.3, l.z);
        dummy.updateMatrix();
        bulbs.setMatrixAt(i, dummy.matrix);
      });
      group.add(bases, poles, arms, bulbs);
    }

    return { lampBulbMat };
  }
}
