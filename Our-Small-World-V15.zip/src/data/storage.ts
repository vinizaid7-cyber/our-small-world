import { ARTIFACTS, BUILDER_BLUEPRINTS, CROPS, FACTORIES, FACTORY_RECIPES, FARM_ANIMALS, STOCK_COMPANIES, TECH_TREE, VEHICLES } from './catalog';
import { FARM_PARCELS } from './islandsData';

export interface PlayerProfile {
  id: string;
  name: string;
  color: string;
  hair: string;
  gender: 'boy' | 'girl';
  hairStyle: 'short' | 'long' | 'ponytail' | 'cap';
  outfit: string;
}

export interface GameEventRecord {
  id: string;
  created_at: string;
  author: string;
  house: string;
  title: string;
  body: string;
}

export interface FactoryRuntime {
  id: string;
  built: boolean;
  level: number;
  workers: number;
  machines: number;
  activeJob: {
    recipeId: string;
    startAt: number;
    endAt: number;
  } | null;
  autoRepeat: boolean;
}

export interface OwnedVehicle {
  uid: string;
  defId: string;
  color: string;
  fuel: number;
  health: number; // 0..100
  x: number;
  z: number;
  ry: number;
  mileage: number;
}

export interface PlacedBuilding {
  uid: string;
  blueprintId: string;
  islandId: string;
  x: number;
  z: number;
  ry: number;
  stage: number; // 1..maxStages
  builtAt: number;
}

export interface PortShipment {
  id: string;
  itemKey: string;
  qty: number;
  destination: string;
  payout: number;
  startAt: number;
  endAt: number;
  claimed: boolean;
}

export interface CityMetrics {
  population: number;
  happiness: number;
  jobs: number;
  powerCapacity: number;
  powerUsed: number;
  waterCapacity: number;
  waterUsed: number;
  pollution: number;
  trafficScore: number;
}

export interface GameState {
  version: 15;
  coins: number;
  bankBalance: number;
  bankLoan: number;
  xp: number;
  energy: number;
  hunger: number;
  thirst: number;
  inventory: Record<string, number>;
  fridge: Record<string, number>;
  outfitsOwned: string[];
  furniturePlaced: Array<{ id: string; item: string; x: number; z: number; ry: number; floor: number }>;
  pets: Array<{ id: string; kind: string; name: string; mode: 'follow' | 'stay' | 'home' }>;
  farmPlots: Record<string, { cropId: string; plantedAt: number; growSec: number }>;
  ownedParcels: string[];
  farmAnimals: Array<{ id: string; kind: string; lastCollectAt: number; fedAt: number; health: number }>;
  factories: Record<string, FactoryRuntime>;
  stocksOwned: Record<string, number>;
  stockPrices: Record<string, number>;
  stockHistory: Record<string, number[]>;
  vehicles: OwnedVehicle[];
  activeVehicleUid: string | null;
  shipments: PortShipment[];
  placedBuildings: PlacedBuilding[];
  zonedCells: Record<string, 'res' | 'com' | 'ind' | 'park'>;
  techUnlocked: string[];
  artifactsFound: Record<string, number>;
  artifactsExhibited: string[];
  questsCompleted: string[];
  finesUnpaid: number;
  ticketsPaid: number;
  thievesCaught: number;
  hotelRoomBookedUntil: number;
  activeEvent: { id: string; title: string; desc: string; endsAt: number } | null;
  cityMetrics: CityMetrics;
  legacyNotes: string[];
}

export interface DemoStore {
  users: PlayerProfile[];
  entries: GameEventRecord[];
  kv: Record<string, unknown>;
}

const DEMO_KEY = 'osw_demo_v1';
const UID_KEY = 'osw_uid';

export function createInitialGameState(): GameState {
  const factories: Record<string, FactoryRuntime> = {};
  Object.values(FACTORIES).forEach((f) => {
    factories[f.id] = {
      id: f.id,
      built: f.id === 'glass' || f.id === 'wood',
      level: 1,
      workers: f.id === 'glass' ? 4 : 2,
      machines: f.id === 'glass' ? 2 : 1,
      activeJob: null,
      autoRepeat: false,
    };
  });

  const stockPrices: Record<string, number> = {};
  const stockHistory: Record<string, number[]> = {};
  STOCK_COMPANIES.forEach((c) => {
    stockPrices[c.ticker] = c.basePrice;
    stockHistory[c.ticker] = [
      c.basePrice * 0.96,
      c.basePrice * 0.99,
      c.basePrice * 0.97,
      c.basePrice * 1.01,
      c.basePrice,
    ];
  });

  const farmPlots: Record<string, { cropId: string; plantedAt: number; growSec: number }> = {};
  const ownedParcels: string[] = [];
  FARM_PARCELS.slice(0, 6).forEach((p, idx) => {
    ownedParcels.push(p.id);
    if (idx < 3) {
      farmPlots[p.id] = {
        cropId: p.defaultCrop,
        plantedAt: Date.now() - 40000,
        growSec: CROPS[p.defaultCrop]?.growSec || 40,
      };
    }
  });

  return {
    version: 15,
    coins: 2800,
    bankBalance: 1200,
    bankLoan: 0,
    xp: 0,
    energy: 95,
    hunger: 88,
    thirst: 90,
    inventory: {
      silica_sand: 16,
      soda_ash: 8,
      limestone: 8,
      iron_ore: 6,
      coal: 6,
      timber_log: 8,
      raw_clay: 8,
      cotton_wool: 6,
      wheat: 10,
      tomato: 4,
      silicon_wafer: 2,
      copper: 4,
      glass_sheet: 4,
    },
    fridge: {
      wheat: 4,
      tomato: 3,
      milk: 3,
    },
    outfitsOwned: ['casual'],
    furniturePlaced: [
      { id: 'f_init_sofa', item: 'sofa_royal', x: -3.5, z: -2.0, ry: 0, floor: 0 },
      { id: 'f_init_tv', item: 'tv_oled', x: -3.5, z: -6.5, ry: 0, floor: 0 },
      { id: 'f_init_plant', item: 'plant_ficus', x: 5.5, z: -6.5, ry: 0, floor: 0 },
    ],
    pets: [{ id: 'pet_1', kind: 'dog', name: 'بندق', mode: 'follow' }],
    farmPlots,
    ownedParcels,
    farmAnimals: [
      { id: 'ani_cow_1', kind: 'cow', lastCollectAt: Date.now() - 60000, fedAt: Date.now(), health: 100 },
      { id: 'ani_sheep_1', kind: 'sheep', lastCollectAt: Date.now() - 60000, fedAt: Date.now(), health: 100 },
    ],
    factories,
    stocksOwned: { ALNOOR: 5 },
    stockPrices,
    stockHistory,
    vehicles: [
      {
        uid: 'veh_starter_sedan',
        defId: 'sedan',
        color: '#2563eb',
        fuel: 52,
        health: 100,
        x: 20,
        z: -4,
        ry: 0,
        mileage: 12,
      },
      {
        uid: 'veh_starter_ev',
        defId: 'ev_sedan',
        color: '#06b6d4',
        fuel: 95,
        health: 100,
        x: -18,
        z: -4,
        ry: 0,
        mileage: 4,
      },
    ],
    activeVehicleUid: null,
    shipments: [],
    placedBuildings: [],
    zonedCells: {},
    techUnlocked: [],
    artifactsFound: { art_clay_tablet: 1 },
    artifactsExhibited: ['art_clay_tablet'],
    questsCompleted: [],
    finesUnpaid: 0,
    ticketsPaid: 0,
    thievesCaught: 0,
    hotelRoomBookedUntil: 0,
    activeEvent: null,
    cityMetrics: {
      population: 148,
      happiness: 84,
      jobs: 92,
      powerCapacity: 140,
      powerUsed: 85,
      waterCapacity: 130,
      waterUsed: 68,
      pollution: 18,
      trafficScore: 86,
    },
    legacyNotes: [],
  };
}

export function loadDemoStore(): DemoStore {
  try {
    const raw = localStorage.getItem(DEMO_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DemoStore;
      if (parsed && Array.isArray(parsed.users) && Array.isArray(parsed.entries)) {
        return parsed;
      }
    }
  } catch {
    // ignore corrupt localStorage
  }
  const initial: DemoStore = {
    users: [
      {
        id: 'p1',
        name: 'زيد',
        color: '#2563eb',
        hair: '#1e1b18',
        gender: 'boy',
        hairStyle: 'short',
        outfit: 'casual',
      },
      {
        id: 'p2',
        name: 'لينا',
        color: '#e11d48',
        hair: '#3b2416',
        gender: 'girl',
        hairStyle: 'long',
        outfit: 'casual',
      },
    ],
    entries: [],
    kv: {},
  };
  saveDemoStore(initial);
  return initial;
}

export function saveDemoStore(store: DemoStore): void {
  try {
    localStorage.setItem(DEMO_KEY, JSON.stringify(store));
  } catch {
    // ignore storage quota
  }
}

export function getActiveUid(store: DemoStore): string {
  try {
    const u = sessionStorage.getItem(UID_KEY);
    if (u && store.users.some((x) => x.id === u)) return u;
  } catch {
    // ignore
  }
  return store.users[0]?.id || 'p1';
}

export function setActiveUid(uid: string): void {
  try {
    sessionStorage.setItem(UID_KEY, uid);
  } catch {
    // ignore
  }
}

/**
 * Folds ALL V14 legacy events + V15 events deterministically so existing V14 saves
 * (osw_demo_v1) load cleanly without losing coins, vehicles, crops, furniture, or progress.
 */
export function foldGameState(entries: GameEventRecord[]): GameState {
  const S = createInitialGameState();
  const sorted = entries
    .filter((e) => e.house === 'game')
    .slice()
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  for (const e of sorted) {
    let d: Record<string, any> = {};
    try {
      d = JSON.parse(e.body || '{}');
    } catch {
      continue;
    }
    const t = new Date(e.created_at).getTime() || Date.now();
    const ty = e.title;

    // ---- V14 Legacy Compatible Event Folding ----
    if (ty === 'sys_cheat_coins' && typeof d.amount === 'number') {
      S.coins += d.amount;
    } else if (ty === 'buy' && d.item) {
      const qty = Math.max(1, Number(d.qty || 1));
      const cost = Number(d.cost || 10) * qty;
      if (S.coins >= cost) {
        S.coins -= cost;
        S.inventory[d.item] = (S.inventory[d.item] || 0) + qty;
      }
    } else if (ty === 'sell' && d.item) {
      const qty = Math.max(1, Number(d.qty || 1));
      const have = S.inventory[d.item] || 0;
      const take = Math.min(have, qty);
      if (take > 0) {
        S.inventory[d.item] -= take;
        S.coins += Number(d.price || CROPS[d.item]?.sellPrice || 15) * take;
      }
    } else if (ty === 'plant' && d.plot != null && d.crop) {
      const parcelId = typeof d.plot === 'number' ? `FARM_P${String(d.plot + 1).padStart(2, '0')}` : String(d.plot);
      const crop = CROPS[d.crop];
      if (crop && S.coins >= crop.seedPrice) {
        S.coins -= crop.seedPrice;
        S.farmPlots[parcelId] = { cropId: crop.id, plantedAt: t, growSec: crop.growSec };
      }
    } else if (ty === 'harvest' && d.plot != null) {
      const parcelId = typeof d.plot === 'number' ? `FARM_P${String(d.plot + 1).padStart(2, '0')}` : String(d.plot);
      const plot = S.farmPlots[parcelId];
      if (plot) {
        S.inventory[plot.cropId] = (S.inventory[plot.cropId] || 0) + 3;
        delete S.farmPlots[parcelId];
        S.xp += 10;
      }
    } else if (ty === 'land_buy' && d.id) {
      // V14 Island 1 clutter plots removed visually in V15, migrate cleanly to Agri farmland
      const idx = parseInt(String(d.id).replace(/\D/g, ''), 10) || 7;
      const mapped = `FARM_P${String(Math.min(36, idx + 6)).padStart(2, '0')}`;
      if (!S.ownedParcels.includes(mapped)) S.ownedParcels.push(mapped);
    } else if (ty === 'cbuy' && d.car) {
      const def = VEHICLES[d.car] || VEHICLES.sedan;
      const price = def.price;
      if (S.coins >= price) {
        S.coins -= price;
        S.vehicles.push({
          uid: `veh_${e.id}`,
          defId: def.id,
          color: d.color || def.defaultColor,
          fuel: def.tankSize,
          health: 100,
          x: 18 + (S.vehicles.length % 3) * 4,
          z: -15,
          ry: 0,
          mileage: 0,
        });
      }
    } else if (ty === 'furn_place' && d.item) {
      S.furniturePlaced.push({
        id: e.id,
        item: d.item,
        x: Number(d.x || 0),
        z: Number(d.z || 0),
        ry: Number(d.ry || 0),
        floor: Number(d.floor || 0),
      });
    } else if (ty === 'abuy' && d.kind) {
      const def = FARM_ANIMALS.find((x) => x.id === d.kind);
      if (def && S.coins >= def.price) {
        S.coins -= def.price;
        S.farmAnimals.push({ id: `ani_${e.id}`, kind: def.id, lastCollectAt: t, fedAt: t, health: 100 });
      }
    } else if (ty === 'together' || ty === 'story' || ty === 'gift') {
      S.coins += 5;
      S.xp += 5;
    }

    // ---- V15 Events ----
    else if (ty === 'v15_factory_start' && d.factoryId && d.recipeId) {
      const f = S.factories[d.factoryId];
      const rec = FACTORY_RECIPES[d.recipeId];
      if (f && f.built && rec && !f.activeJob && f.workers >= rec.minWorkers) {
        const can = Object.entries(rec.inputs).every(([k, q]) => (S.inventory[k] || 0) >= q);
        if (can) {
          Object.entries(rec.inputs).forEach(([k, q]) => {
            S.inventory[k] -= q;
          });
          const speedBoost = 1 + (f.machines - 1) * 0.25 + (f.workers - rec.minWorkers) * 0.08 + (S.techUnlocked.includes('automation') ? 0.25 : 0);
          const durMs = Math.max(4000, Math.round((rec.durationSec * 1000) / speedBoost));
          f.activeJob = { recipeId: rec.id, startAt: t, endAt: t + durMs };
        }
      }
    } else if (ty === 'v15_factory_collect' && d.factoryId) {
      const f = S.factories[d.factoryId];
      if (f && f.activeJob) {
        const rec = FACTORY_RECIPES[f.activeJob.recipeId];
        if (rec) {
          Object.entries(rec.outputs).forEach(([k, q]) => {
            S.inventory[k] = (S.inventory[k] || 0) + q;
          });
          S.xp += 25;
        }
        f.activeJob = null;
      }
    } else if (ty === 'v15_factory_upgrade' && d.factoryId) {
      const f = S.factories[d.factoryId];
      const def = FACTORIES[d.factoryId];
      if (f && def) {
        if (d.kind === 'build' && !f.built && S.coins >= def.buildCost) {
          S.coins -= def.buildCost;
          f.built = true;
        } else if (d.kind === 'worker' && f.workers < def.maxWorkers && S.coins >= 85) {
          S.coins -= 85;
          f.workers += 1;
        } else if (d.kind === 'machine' && f.machines < def.maxMachines && S.coins >= 160) {
          S.coins -= 160;
          f.machines += 1;
        }
      }
    } else if (ty === 'v15_buy_mat' && d.item) {
      const qty = Math.max(1, Number(d.qty || 1));
      const cost = Number(d.unitPrice || 15) * qty;
      if (S.coins >= cost) {
        S.coins -= cost;
        S.inventory[d.item] = (S.inventory[d.item] || 0) + qty;
      }
    } else if (ty === 'v15_sell_item' && d.item) {
      const qty = Math.max(1, Number(d.qty || 1));
      const have = S.inventory[d.item] || 0;
      const take = Math.min(have, qty);
      if (take > 0) {
        S.inventory[d.item] -= take;
        S.coins += Number(d.unitPrice || 20) * take;
      }
    } else if (ty === 'v15_stock_buy' && d.ticker) {
      const qty = Math.max(1, Number(d.qty || 1));
      const price = Number(d.price || S.stockPrices[d.ticker] || 50);
      const cost = Math.round(price * qty);
      if (S.coins >= cost) {
        S.coins -= cost;
        S.stocksOwned[d.ticker] = (S.stocksOwned[d.ticker] || 0) + qty;
        S.xp += 12;
      }
    } else if (ty === 'v15_stock_sell' && d.ticker) {
      const qty = Math.max(1, Number(d.qty || 1));
      const have = S.stocksOwned[d.ticker] || 0;
      const take = Math.min(have, qty);
      const price = Number(d.price || S.stockPrices[d.ticker] || 50);
      if (take > 0) {
        S.stocksOwned[d.ticker] -= take;
        S.coins += Math.round(price * take);
      }
    } else if (ty === 'v15_bank' && d.op) {
      const amt = Math.max(0, Math.round(Number(d.amount || 0)));
      if (d.op === 'deposit' && S.coins >= amt) {
        S.coins -= amt;
        S.bankBalance += amt;
      } else if (d.op === 'withdraw' && S.bankBalance >= amt) {
        S.bankBalance -= amt;
        S.coins += amt;
      } else if (d.op === 'loan' && amt > 0 && S.bankLoan + amt <= 5000) {
        S.bankLoan += Math.round(amt * 1.1);
        S.coins += amt;
      } else if (d.op === 'repay' && S.coins >= amt && S.bankLoan > 0) {
        const pay = Math.min(amt, S.bankLoan);
        S.coins -= pay;
        S.bankLoan -= pay;
      }
    } else if (ty === 'v15_export_launch' && d.itemKey) {
      const qty = Math.max(1, Number(d.qty || 1));
      if ((S.inventory[d.itemKey] || 0) >= qty) {
        S.inventory[d.itemKey] -= qty;
        S.shipments.push({
          id: e.id,
          itemKey: d.itemKey,
          qty,
          destination: d.destination || 'ميناء الشرق',
          payout: Number(d.payout || qty * 95),
          startAt: t,
          endAt: t + 22000,
          claimed: false,
        });
      }
    } else if (ty === 'v15_export_claim' && d.shipmentId) {
      const sh = S.shipments.find((x) => x.id === d.shipmentId);
      if (sh && !sh.claimed) {
        sh.claimed = true;
        S.coins += sh.payout;
        S.xp += 35;
      }
    } else if (ty === 'v15_build_place' && d.blueprintId) {
      const bp = BUILDER_BLUEPRINTS.find((x) => x.id === d.blueprintId);
      if (bp && S.coins >= bp.cost) {
        S.coins -= bp.cost;
        S.placedBuildings.push({
          uid: e.id,
          blueprintId: bp.id,
          islandId: d.islandId || 'ISL_CITY',
          x: Number(d.x || 0),
          z: Number(d.z || 0),
          ry: Number(d.ry || 0),
          stage: 1,
          builtAt: t,
        });
        S.xp += 30;
      }
    } else if (ty === 'v15_build_advance' && d.uid) {
      const b = S.placedBuildings.find((x) => x.uid === d.uid);
      const bp = b && BUILDER_BLUEPRINTS.find((x) => x.id === b.blueprintId);
      if (b && bp && b.stage < bp.stages) {
        const canMat = Object.entries(bp.materialsReq).every(([k, q]) => (S.inventory[k] || 0) >= q);
        if (canMat || b.stage > 1) {
          if (b.stage === 1) {
            Object.entries(bp.materialsReq).forEach(([k, q]) => {
              S.inventory[k] -= q;
            });
          }
          b.stage += 1;
          S.xp += 20;
        }
      }
    } else if (ty === 'v15_zone_paint' && d.cellKey && d.zone) {
      S.zonedCells[d.cellKey] = d.zone;
    } else if (ty === 'v15_tech_unlock' && d.techId) {
      const node = TECH_TREE.find((x) => x.id === d.techId);
      if (node && !S.techUnlocked.includes(node.id) && S.coins >= node.cost) {
        S.coins -= node.cost;
        S.techUnlocked.push(node.id);
        S.xp += 45;
      }
    } else if (ty === 'v15_veh_refuel' && d.vehUid) {
      const v = S.vehicles.find((x) => x.uid === d.vehUid);
      const def = v && VEHICLES[v.defId];
      if (v && def) {
        const cost = Number(d.cost || 25);
        if (S.coins >= cost) {
          S.coins -= cost;
          v.fuel = def.tankSize;
        }
      }
    } else if (ty === 'v15_veh_repair' && d.vehUid) {
      const v = S.vehicles.find((x) => x.uid === d.vehUid);
      if (v) {
        const cost = Number(d.cost || 45);
        if (S.coins >= cost) {
          S.coins -= cost;
          v.health = 100;
        }
      }
    } else if (ty === 'v15_veh_damage' && d.vehUid) {
      const v = S.vehicles.find((x) => x.uid === d.vehUid);
      if (v) {
        v.health = Math.max(10, v.health - Number(d.amount || 12));
      }
    } else if (ty === 'v15_excavate' && d.artifactId) {
      const art = ARTIFACTS.find((x) => x.id === d.artifactId);
      if (art) {
        S.artifactsFound[art.id] = (S.artifactsFound[art.id] || 0) + 1;
        S.xp += 30;
      }
    } else if (ty === 'v15_exhibit' && d.artifactId) {
      if ((S.artifactsFound[d.artifactId] || 0) > 0 && !S.artifactsExhibited.includes(d.artifactId)) {
        S.artifactsExhibited.push(d.artifactId);
      }
    } else if (ty === 'v15_quest_done' && d.questId) {
      if (!S.questsCompleted.includes(d.questId)) {
        S.questsCompleted.push(d.questId);
        S.coins += Number(d.rewardCoins || 100);
        S.xp += Number(d.rewardXp || 40);
      }
    } else if (ty === 'v15_parcel_buy' && d.parcelId) {
      const p = FARM_PARCELS.find((x) => x.id === d.parcelId);
      if (p && !S.ownedParcels.includes(p.id) && S.coins >= p.price) {
        S.coins -= p.price;
        S.ownedParcels.push(p.id);
      }
    } else if (ty === 'v15_animal_collect' && d.animalId) {
      const a = S.farmAnimals.find((x) => x.id === d.animalId);
      const def = a && FARM_ANIMALS.find((x) => x.id === a.kind);
      if (a && def) {
        a.lastCollectAt = t;
        if (def.product === 'ride') S.coins += def.productVal;
        else S.inventory[def.product] = (S.inventory[def.product] || 0) + 2;
      }
    } else if (ty === 'v15_animal_care' && d.animalId) {
      const a = S.farmAnimals.find((x) => x.id === d.animalId);
      if (a && S.coins >= 10) {
        S.coins -= 10;
        a.fedAt = t;
        a.health = 100;
      }
    } else if (ty === 'v15_sleep') {
      S.energy = 100;
    } else if (ty === 'v15_eat_meal') {
      const cost = Number(d.cost || 0);
      if (S.coins >= cost) {
        S.coins -= cost;
        S.hunger = Math.min(100, S.hunger + Number(d.food || 35));
        S.thirst = Math.min(100, S.thirst + Number(d.drink || 20));
        S.energy = Math.min(100, S.energy + 12);
      }
    } else if (ty === 'v15_hospital_heal') {
      if (S.coins >= 25) {
        S.coins -= 25;
        S.energy = 100;
        S.hunger = 100;
        S.thirst = 100;
      }
    } else if (ty === 'v15_ticket_fine') {
      S.finesUnpaid += Number(d.amount || 65);
    } else if (ty === 'v15_ticket_pay') {
      if (S.finesUnpaid > 0 && S.coins >= S.finesUnpaid) {
        S.coins -= S.finesUnpaid;
        S.ticketsPaid += 1;
        S.finesUnpaid = 0;
      }
    } else if (ty === 'v15_thief_catch') {
      S.thievesCaught += 1;
      S.coins += 120;
      S.xp += 35;
    } else if (ty === 'v15_outfit_buy' && d.outfitId) {
      const cost = Number(d.price || 100);
      if (!S.outfitsOwned.includes(d.outfitId) && S.coins >= cost) {
        S.coins -= cost;
        S.outfitsOwned.push(d.outfitId);
      }
    } else if (ty === 'v15_hotel_book') {
      const cost = Number(d.price || 60);
      if (S.coins >= cost) {
        S.coins -= cost;
        S.hotelRoomBookedUntil = t + 3600000;
        S.energy = 100;
      }
    }
  }

  // Compute live city metrics from placed buildings + zoned cells + tech
  let pop = 148;
  let jobs = 92;
  let happy = 84;
  let pollution = 18;
  let powerCap = S.techUnlocked.includes('grid_power') ? 240 : 140;
  let powerUsed = 85;
  let waterCap = S.techUnlocked.includes('water_grid') ? 220 : 130;
  let waterUsed = 68;

  for (const b of S.placedBuildings) {
    const bp = BUILDER_BLUEPRINTS.find((x) => x.id === b.blueprintId);
    if (!bp) continue;
    const ratio = b.stage / bp.stages;
    pop += Math.round(bp.popDelta * ratio);
    jobs += Math.round(bp.jobsDelta * ratio);
    happy += Math.round(bp.happyDelta * ratio);
    pollution += Math.round(bp.pollutionDelta * ratio);
    if (bp.powerNeed < 0) powerCap += Math.round(-bp.powerNeed * ratio);
    else powerUsed += Math.round(bp.powerNeed * ratio);
    waterUsed += Math.round(bp.waterNeed * ratio);
  }
  Object.values(S.zonedCells).forEach((z) => {
    if (z === 'res') { pop += 12; happy += 1; }
    else if (z === 'com') { jobs += 8; happy += 2; }
    else if (z === 'ind') { jobs += 14; pollution += 4; happy -= 1; }
    else if (z === 'park') { happy += 6; pollution -= 3; }
  });
  if (S.techUnlocked.includes('ev_infra')) pollution = Math.max(2, pollution - 8);
  if (S.techUnlocked.includes('smart_transit')) happy += 6;

  S.cityMetrics = {
    population: pop,
    happiness: Math.max(15, Math.min(100, happy)),
    jobs,
    powerCapacity: powerCap,
    powerUsed,
    waterCapacity: waterCap,
    waterUsed,
    pollution: Math.max(0, Math.min(100, pollution)),
    trafficScore: S.techUnlocked.includes('smart_transit') ? 94 : 82,
  };

  return S;
}
