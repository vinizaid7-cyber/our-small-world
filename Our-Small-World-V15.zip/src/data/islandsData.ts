export type IslandId =
  | 'ISL_HOME'
  | 'ISL_BUSINESS'
  | 'ISL_PORT'
  | 'ISL_AGRI'
  | 'ISL_INDUSTRY'
  | 'ISL_CITY'
  | 'ISL_LIFE';

export interface IslandDef {
  id: IslandId;
  name: string;
  civTitle: string;
  eraDesc: string;
  emoji: string;
  cx: number;
  cz: number;
  radius: number;
  groundColor: string;
  rimColor: string;
  accentColor: string;
}

export interface RoadSegment {
  id: string;
  islandId: IslandId | 'BRIDGE';
  x0: number;
  z0: number;
  x1: number;
  z1: number;
  width: number;
  isBridge?: boolean;
  label?: string;
}

export interface SiteDef {
  id: string;
  islandId: IslandId;
  name: string;
  emoji: string;
  kind: 'landmark' | 'factory' | 'civic' | 'commercial' | 'market' | 'farm' | 'station' | 'temple' | 'leisure';
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  facing: number; // radians: 0 = +Z, PI = -Z, PI/2 = +X, -PI/2 = -X
  doorX: number;
  doorZ: number;
  frontX: number;
  frontZ: number;
  interiorId?: string;
  actionType?: string;
  wallColor: string;
  roofColor: string;
  style: string;
}

export interface FarmParcelDef {
  id: string;
  index: number;
  x: number;
  z: number;
  w: number;
  d: number;
  defaultCrop: string;
  price: number;
}

export interface GasStationDef {
  id: string;
  name: string;
  islandId: IslandId;
  x: number;
  z: number;
  hasEV: boolean;
  hasGas: boolean;
}

export interface BusStopDef {
  id: string;
  name: string;
  islandId: IslandId;
  x: number;
  z: number;
}

export interface DigSpotDef {
  id: string;
  name: string;
  islandId: IslandId;
  x: number;
  z: number;
  era: 'ancient' | 'classical' | 'islamic' | 'medieval';
  hint: string;
}

export const ISLANDS: Record<IslandId, IslandDef> = {
  ISL_HOME: {
    id: 'ISL_HOME',
    name: 'جزيرة الوطن والقصر',
    civTitle: 'موطن اللاعبين والقرية التراثية',
    eraDesc: 'القصر الفاخر ذو الطابقين وسوق سعدون وبيوت الجوار',
    emoji: '🏡',
    cx: 0,
    cz: 0,
    radius: 135,
    groundColor: '#5ea155',
    rimColor: '#e5d4a1',
    accentColor: '#f59e0b',
  },
  ISL_BUSINESS: {
    id: 'ISL_BUSINESS',
    name: 'جزيرة الأعمال والتجارة',
    civTitle: 'الحضارة التجارية والمالية',
    eraDesc: 'البورصة المركزية، البنك المركزي، المقر الإداري، ومعرض السيارات',
    emoji: '🏛️',
    cx: -420,
    cz: 230,
    radius: 185,
    groundColor: '#a7a08d',
    rimColor: '#e2d5b5',
    accentColor: '#38bdf8',
  },
  ISL_PORT: {
    id: 'ISL_PORT',
    name: 'جزيرة الميناء والملاحة',
    civTitle: 'الحضارة البحرية والتجارة الدولية',
    eraDesc: 'المنارة الكبرى، أحواض السفن، الرافعات، الجمارك والتصدير',
    emoji: '⚓',
    cx: -440,
    cz: 1110,
    radius: 195,
    groundColor: '#8d928f',
    rimColor: '#d4c8a6',
    accentColor: '#0284c7',
  },
  ISL_AGRI: {
    id: 'ISL_AGRI',
    name: 'الجزيرة الزراعية',
    civTitle: 'حضارة الأنهار والنواعير والريف',
    eraDesc: 'قنوات الري، النواعير الدوارة، السد، الطاحونة، 36 مزرعة وعيادة البيطرة',
    emoji: '🌾',
    cx: -480,
    cz: 670,
    radius: 225,
    groundColor: '#69a84f',
    rimColor: '#dcc896',
    accentColor: '#84cc16',
  },
  ISL_INDUSTRY: {
    id: 'ISL_INDUSTRY',
    name: 'جزيرة الصناعة والإنتاج',
    civTitle: 'عصر الثورة الصناعية والتقنية',
    eraDesc: 'مصنع النور للزجاج و6 مصانع متخصصة، محطة الطاقة وكراج التصليح',
    emoji: '🏭',
    cx: 360,
    cz: 130,
    radius: 205,
    groundColor: '#767a7d',
    rimColor: '#b9b4a4',
    accentColor: '#f97316',
  },
  ISL_CITY: {
    id: 'ISL_CITY',
    name: 'المدينة الكبرى (العاصمة)',
    civTitle: 'الحضارة الحضرية والعاصمة الملكية',
    eraDesc: 'قصر الحاكم، البلدية، المستشفى، الشرطة، المجمّع، الفندق والمطاعم',
    emoji: '🏙️',
    cx: 270,
    cz: 600,
    radius: 215,
    groundColor: '#8b8f94',
    rimColor: '#dcd2b8',
    accentColor: '#a855f7',
  },
  ISL_LIFE: {
    id: 'ISL_LIFE',
    name: 'جزيرة العلم والحياة والآثار',
    civTitle: 'حضارة الحكمة والفنون والمعابد القديمة',
    eraDesc: 'الجامعة، بيت الحكمة، المرصد، المعبد الغارق، الملاهي والشاطئ',
    emoji: '🎓',
    cx: 700,
    cz: 600,
    radius: 205,
    groundColor: '#68ad64',
    rimColor: '#eddca8',
    accentColor: '#ec4899',
  },
};

/**
 * Unified unobstructed road & bridge network.
 * IMPORTANT: No buildings, trees, fountains, or lamp poles may intersect any road corridor!
 */
export const ROADS: RoadSegment[] = [
  // ISL_HOME clean avenues (strictly clear of trees/fountains!)
  { id: 'home_ns', islandId: 'ISL_HOME', x0: 0, z0: 2, x1: 0, z1: 130, width: 12 },
  { id: 'home_ew', islandId: 'ISL_HOME', x0: -130, z0: 42, x1: 130, z1: 42, width: 12 },
  { id: 'home_south_spur', islandId: 'ISL_HOME', x0: -80, z0: 85, x1: 80, z1: 85, width: 10 },

  // Bridges connecting Home <-> Industry, Home <-> Business, Home <-> City
  { id: 'brg_home_ind', islandId: 'BRIDGE', x0: 130, z0: 42, x1: 195, z1: 130, width: 14, isBridge: true, label: 'جسر الصناعة' },
  { id: 'brg_home_biz', islandId: 'BRIDGE', x0: -130, z0: 42, x1: -265, z1: 230, width: 14, isBridge: true, label: 'جسر المال والتجارة' },
  { id: 'brg_home_city', islandId: 'BRIDGE', x0: 0, z0: 130, x1: 270, z1: 405, width: 14, isBridge: true, label: 'الطريق السريع للعاصمة' },

  // Inter-island bridges along West & East corridors
  { id: 'brg_biz_agri', islandId: 'BRIDGE', x0: -420, z0: 405, x1: -480, z1: 460, width: 14, isBridge: true, label: 'جسر الوادي الأخضر' },
  { id: 'brg_agri_port', islandId: 'BRIDGE', x0: -480, z0: 880, x1: -440, z1: 925, width: 14, isBridge: true, label: 'جسر الميناء' },
  { id: 'brg_city_agri', islandId: 'BRIDGE', x0: 70, z0: 600, x1: -265, z1: 670, width: 14, isBridge: true, label: 'جسر الحقول' },
  { id: 'brg_city_ind', islandId: 'BRIDGE', x0: 270, z0: 400, x1: 360, z1: 325, width: 14, isBridge: true, label: 'جسر المصانع' },
  { id: 'brg_city_life', islandId: 'BRIDGE', x0: 475, z0: 600, x1: 505, z1: 600, width: 14, isBridge: true, label: 'جسر الحكمة والحياة' },

  // ISL_BUSINESS grid
  { id: 'biz_ew', islandId: 'ISL_BUSINESS', x0: -580, z0: 230, x1: -260, z1: 230, width: 14 },
  { id: 'biz_ns', islandId: 'ISL_BUSINESS', x0: -420, z0: 174, x1: -420, z1: 410, width: 14 },

  // ISL_AGRI grid
  { id: 'agri_ew', islandId: 'ISL_AGRI', x0: -680, z0: 670, x1: -260, z1: 670, width: 14 },
  { id: 'agri_ns', islandId: 'ISL_AGRI', x0: -480, z0: 455, x1: -480, z1: 885, width: 14 },

  // ISL_PORT grid
  { id: 'port_ew', islandId: 'ISL_PORT', x0: -590, z0: 1110, x1: -265, z1: 1110, width: 14 },
  { id: 'port_ns', islandId: 'ISL_PORT', x0: -440, z0: 920, x1: -440, z1: 1270, width: 14 },

  // ISL_INDUSTRY grid
  { id: 'ind_ew', islandId: 'ISL_INDUSTRY', x0: 185, z0: 130, x1: 540, z1: 130, width: 14 },
  { id: 'ind_ns', islandId: 'ISL_INDUSTRY', x0: 360, z0: -50, x1: 360, z1: 330, width: 14 },

  // ISL_CITY grid
  { id: 'city_ew', islandId: 'ISL_CITY', x0: 65, z0: 600, x1: 480, z1: 600, width: 14 },
  { id: 'city_ns', islandId: 'ISL_CITY', x0: 270, z0: 395, x1: 270, z1: 758, width: 14 },
  { id: 'city_north_ew', islandId: 'ISL_CITY', x0: 130, z0: 480, x1: 410, z1: 480, width: 11 },

  // ISL_LIFE grid
  { id: 'life_ew', islandId: 'ISL_LIFE', x0: 500, z0: 600, x1: 885, z1: 600, width: 14 },
  { id: 'life_ns', islandId: 'ISL_LIFE', x0: 700, z0: 420, x1: 700, z1: 785, width: 14 },
];

export const SITES: SiteDef[] = [
  // ============ ISL_HOME ============
  {
    id: 'HOME_VILLA',
    islandId: 'ISL_HOME',
    name: 'القصر العائلي الفاخر',
    emoji: '🏰',
    kind: 'landmark',
    x: 0,
    z: -34,
    w: 28,
    d: 20,
    h: 13,
    facing: 0,
    doorX: 0,
    doorZ: -24,
    frontX: 0,
    frontZ: -19,
    interiorId: 'home_ground',
    wallColor: '#f6efe2',
    roofColor: '#9a3412',
    style: 'villa',
  },
  {
    id: 'HOME_SAADOUN',
    islandId: 'ISL_HOME',
    name: 'سوق سعدون التراثي',
    emoji: '🏪',
    kind: 'market',
    x: -54,
    z: 18,
    w: 16,
    d: 12,
    h: 6.5,
    facing: 0,
    doorX: -54,
    doorZ: 24,
    frontX: -54,
    frontZ: 28,
    interiorId: 'saadoun_shop',
    wallColor: '#f4e3c1',
    roofColor: '#b45309',
    style: 'heritage_shop',
  },
  {
    id: 'HOME_HALL',
    islandId: 'ISL_HOME',
    name: 'ديوان القرية والفعاليات',
    emoji: '🎪',
    kind: 'civic',
    x: 56,
    z: 18,
    w: 16,
    d: 12,
    h: 7,
    facing: 0,
    doorX: 56,
    doorZ: 24,
    frontX: 56,
    frontZ: 28,
    actionType: 'open:quests',
    wallColor: '#e9dcc6',
    roofColor: '#0f766e',
    style: 'diwan',
  },

  // ============ ISL_BUSINESS ============
  {
    id: 'BIZ_EXCH',
    islandId: 'ISL_BUSINESS',
    name: 'البورصة التجارية المركزية',
    emoji: '📈',
    kind: 'commercial',
    x: -420,
    z: 155,
    w: 38,
    d: 28,
    h: 22,
    facing: 0,
    doorX: -420,
    doorZ: 169,
    frontX: -420,
    frontZ: 174,
    interiorId: 'biz_exchange',
    wallColor: '#e6dcc8',
    roofColor: '#1e3a5f',
    style: 'neoclassical_exchange',
  },
  {
    id: 'BIZ_BANK',
    islandId: 'ISL_BUSINESS',
    name: 'البنك المركزي والخزينة',
    emoji: '🏦',
    kind: 'commercial',
    x: -355,
    z: 190,
    w: 32,
    d: 24,
    h: 18,
    facing: -Math.PI / 2,
    doorX: -371,
    doorZ: 190,
    frontX: -376,
    frontZ: 190,
    interiorId: 'biz_bank',
    wallColor: '#f1ece1',
    roofColor: '#b45309',
    style: 'central_bank',
  },
  {
    id: 'BIZ_HQ',
    islandId: 'ISL_BUSINESS',
    name: 'برج إدارة الشركات (5 طوابق)',
    emoji: '🏢',
    kind: 'commercial',
    x: -485,
    z: 185,
    w: 28,
    d: 24,
    h: 42,
    facing: Math.PI / 2,
    doorX: -471,
    doorZ: 185,
    frontX: -466,
    frontZ: 185,
    interiorId: 'biz_hq',
    wallColor: '#334155',
    roofColor: '#0f172a',
    style: 'hq_tower',
  },
  {
    id: 'BIZ_DEALER',
    islandId: 'ISL_BUSINESS',
    name: 'معرض السيارات الفاخر',
    emoji: '🚘',
    kind: 'commercial',
    x: -360,
    z: 275,
    w: 34,
    d: 24,
    h: 10,
    facing: Math.PI,
    doorX: -360,
    doorZ: 263,
    frontX: -360,
    frontZ: 258,
    interiorId: 'biz_dealer',
    wallColor: '#e2e8f0',
    roofColor: '#0284c7',
    style: 'showroom',
  },
  {
    id: 'BIZ_RUIN',
    islandId: 'ISL_BUSINESS',
    name: 'رواق التجارة الأثري',
    emoji: '🏛️',
    kind: 'temple',
    x: -495,
    z: 295,
    w: 28,
    d: 22,
    h: 11,
    facing: Math.PI,
    doorX: -495,
    doorZ: 284,
    frontX: -495,
    frontZ: 279,
    actionType: 'open:archaeology',
    wallColor: '#d6c3a1',
    roofColor: '#92400e',
    style: 'colonnade',
  },

  // ============ ISL_PORT ============
  {
    id: 'PORT_LIGHTHOUSE',
    islandId: 'ISL_PORT',
    name: 'منارة الميناء التاريخية',
    emoji: '🚨',
    kind: 'landmark',
    x: -555,
    z: 1015,
    w: 14,
    d: 14,
    h: 36,
    facing: 0,
    doorX: -555,
    doorZ: 1022,
    frontX: -555,
    frontZ: 1027,
    actionType: 'open:port',
    wallColor: '#f8fafc',
    roofColor: '#dc2626',
    style: 'lighthouse',
  },
  {
    id: 'PORT_CUST',
    islandId: 'ISL_PORT',
    name: 'مركز الجمارك والاستيراد',
    emoji: '🛃',
    kind: 'civic',
    x: -380,
    z: 1065,
    w: 26,
    d: 20,
    h: 10,
    facing: 0,
    doorX: -380,
    doorZ: 1075,
    frontX: -380,
    frontZ: 1080,
    interiorId: 'port_customs',
    wallColor: '#e2d9c5',
    roofColor: '#1e3a5f',
    style: 'customs',
  },
  {
    id: 'PORT_TERM',
    islandId: 'ISL_PORT',
    name: 'محطة الشحن والتصدير',
    emoji: '🚢',
    kind: 'commercial',
    x: -510,
    z: 1070,
    w: 30,
    d: 22,
    h: 11,
    facing: 0,
    doorX: -510,
    doorZ: 1081,
    frontX: -510,
    frontZ: 1086,
    interiorId: 'port_warehouse',
    wallColor: '#cbd5e1',
    roofColor: '#0369a1',
    style: 'port_terminal',
  },
  {
    id: 'PORT_MKT',
    islandId: 'ISL_PORT',
    name: 'سوق الأسماك والملاحين',
    emoji: '🐟',
    kind: 'market',
    x: -365,
    z: 1155,
    w: 26,
    d: 20,
    h: 9,
    facing: Math.PI,
    doorX: -365,
    doorZ: 1145,
    frontX: -365,
    frontZ: 1140,
    interiorId: 'port_market',
    wallColor: '#f3ead8',
    roofColor: '#0e7490',
    style: 'maritime_market',
  },

  // ============ ISL_AGRI ============
  {
    id: 'AGRI_VILLAGE',
    islandId: 'ISL_AGRI',
    name: 'قرية الفلاحين التراثية والطاحونة',
    emoji: '🏡',
    kind: 'farm',
    x: -420,
    z: 625,
    w: 26,
    d: 20,
    h: 14,
    facing: 0,
    doorX: -420,
    doorZ: 635,
    frontX: -420,
    frontZ: 640,
    actionType: 'open:farm',
    wallColor: '#efe2c8',
    roofColor: '#b45309',
    style: 'windmill_village',
  },
  {
    id: 'AGRI_VET',
    islandId: 'ISL_AGRI',
    name: 'حظيرة المواشي والعيادة البيطرية',
    emoji: '🐄',
    kind: 'farm',
    x: -545,
    z: 625,
    w: 28,
    d: 22,
    h: 8,
    facing: 0,
    doorX: -545,
    doorZ: 636,
    frontX: -545,
    frontZ: 641,
    interiorId: 'agri_vet',
    wallColor: '#dc2626',
    roofColor: '#7f1d1d',
    style: 'barn_vet',
  },
  {
    id: 'AGRI_DAM',
    islandId: 'ISL_AGRI',
    name: 'سد الري والنواعير الكبرى',
    emoji: '🎡',
    kind: 'landmark',
    x: -555,
    z: 725,
    w: 36,
    d: 26,
    h: 12,
    facing: Math.PI,
    doorX: -555,
    doorZ: 712,
    frontX: -555,
    frontZ: 707,
    actionType: 'open:farm',
    wallColor: '#a8a29e',
    roofColor: '#0284c7',
    style: 'dam_noria',
  },

  // ============ ISL_INDUSTRY ============
  {
    id: 'IND_GLASS',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع النور لصناعة الزجاج',
    emoji: '🪟',
    kind: 'factory',
    x: 315,
    z: 75,
    w: 44,
    d: 30,
    h: 16,
    facing: 0,
    doorX: 315,
    doorZ: 90,
    frontX: 315,
    frontZ: 95,
    interiorId: 'ind_glass',
    wallColor: '#e2e8f0',
    roofColor: '#0369a1',
    style: 'glass_factory',
  },
  {
    id: 'IND_STEEL',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع الفولاذ والصلب الثقيل',
    emoji: '⚙️',
    kind: 'factory',
    x: 425,
    z: 75,
    w: 38,
    d: 28,
    h: 18,
    facing: 0,
    doorX: 425,
    doorZ: 89,
    frontX: 425,
    frontZ: 94,
    interiorId: 'ind_steel',
    wallColor: '#64748b',
    roofColor: '#334155',
    style: 'steel_factory',
  },
  {
    id: 'IND_WOOD',
    islandId: 'ISL_INDUSTRY',
    name: 'منجرة وورش الأخشاب',
    emoji: '🪵',
    kind: 'factory',
    x: 265,
    z: 180,
    w: 30,
    d: 22,
    h: 10,
    facing: Math.PI,
    doorX: 265,
    doorZ: 169,
    frontX: 265,
    frontZ: 164,
    interiorId: 'ind_wood',
    wallColor: '#d97706',
    roofColor: '#78350f',
    style: 'wood_factory',
  },
  {
    id: 'IND_POTTERY',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع الخزف والفخار الملكي',
    emoji: '🏺',
    kind: 'factory',
    x: 325,
    z: 180,
    w: 28,
    d: 22,
    h: 10,
    facing: Math.PI,
    doorX: 325,
    doorZ: 169,
    frontX: 325,
    frontZ: 164,
    interiorId: 'ind_pottery',
    wallColor: '#ea580c',
    roofColor: '#9a3412',
    style: 'pottery_factory',
  },
  {
    id: 'IND_TEXTILE',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع المنسوجات والحرير',
    emoji: '🧵',
    kind: 'factory',
    x: 410,
    z: 180,
    w: 30,
    d: 22,
    h: 11,
    facing: Math.PI,
    doorX: 410,
    doorZ: 169,
    frontX: 410,
    frontZ: 164,
    interiorId: 'ind_textile',
    wallColor: '#a855f7',
    roofColor: '#581c87',
    style: 'textile_factory',
  },
  {
    id: 'IND_FOOD',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع الأغذية والمخابز',
    emoji: '🥖',
    kind: 'factory',
    x: 475,
    z: 180,
    w: 30,
    d: 22,
    h: 11,
    facing: Math.PI,
    doorX: 475,
    doorZ: 169,
    frontX: 475,
    frontZ: 164,
    interiorId: 'ind_food',
    wallColor: '#fef3c7',
    roofColor: '#b45309',
    style: 'food_factory',
  },
  {
    id: 'IND_ELEC',
    islandId: 'ISL_INDUSTRY',
    name: 'مصنع الإلكترونيات والروبوتات',
    emoji: '🤖',
    kind: 'factory',
    x: 425,
    z: 245,
    w: 34,
    d: 24,
    h: 14,
    facing: -Math.PI / 2,
    doorX: 408,
    doorZ: 245,
    frontX: 403,
    frontZ: 245,
    interiorId: 'ind_elec',
    wallColor: '#dbeafe',
    roofColor: '#1e3a8a',
    style: 'elec_factory',
  },
  {
    id: 'IND_GARAGE',
    islandId: 'ISL_INDUSTRY',
    name: 'ورشة وكراج تصليح المركبات',
    emoji: '🔧',
    kind: 'civic',
    x: 310,
    z: 245,
    w: 24,
    d: 18,
    h: 9,
    facing: Math.PI / 2,
    doorX: 322,
    doorZ: 245,
    frontX: 327,
    frontZ: 245,
    interiorId: 'ind_garage',
    wallColor: '#f97316',
    roofColor: '#334155',
    style: 'garage',
  },

  // ============ ISL_CITY ============
  {
    id: 'CITY_PALACE',
    islandId: 'ISL_CITY',
    name: 'قصر الحاكم ومجلس المدينة',
    emoji: '👑',
    kind: 'civic',
    x: 270,
    z: 778,
    w: 44,
    d: 28,
    h: 22,
    facing: Math.PI,
    doorX: 270,
    doorZ: 764,
    frontX: 270,
    frontZ: 758,
    interiorId: 'city_palace',
    wallColor: '#f5ebd6',
    roofColor: '#b45309',
    style: 'palace',
  },
  {
    id: 'CITY_HOSP',
    islandId: 'ISL_CITY',
    name: 'مستشفى العاصمة المركزي',
    emoji: '🏥',
    kind: 'civic',
    x: 350,
    z: 545,
    w: 34,
    d: 26,
    h: 20,
    facing: -Math.PI / 2,
    doorX: 333,
    doorZ: 545,
    frontX: 328,
    frontZ: 545,
    interiorId: 'city_hospital',
    wallColor: '#f8fafc',
    roofColor: '#ef4444',
    style: 'hospital',
  },
  {
    id: 'CITY_POLICE',
    islandId: 'ISL_CITY',
    name: 'مركز الشرطة والمرور',
    emoji: '🚓',
    kind: 'civic',
    x: 210,
    z: 660,
    w: 30,
    d: 22,
    h: 13,
    facing: Math.PI / 2,
    doorX: 225,
    doorZ: 660,
    frontX: 230,
    frontZ: 660,
    interiorId: 'city_police',
    wallColor: '#cbd5e1',
    roofColor: '#1e3a8a',
    style: 'police',
  },
  {
    id: 'CITY_MALL',
    islandId: 'ISL_CITY',
    name: 'مجمّع العاصمة التجاري',
    emoji: '🛍️',
    kind: 'commercial',
    x: 185,
    z: 545,
    w: 38,
    d: 30,
    h: 16,
    facing: Math.PI / 2,
    doorX: 204,
    doorZ: 545,
    frontX: 209,
    frontZ: 545,
    interiorId: 'city_mall',
    wallColor: '#e7dfd1',
    roofColor: '#9f1239',
    style: 'mall',
  },
  {
    id: 'CITY_HOTEL',
    islandId: 'ISL_CITY',
    name: 'فندق الواحة الملكي',
    emoji: '🏨',
    kind: 'commercial',
    x: 335,
    z: 660,
    w: 32,
    d: 24,
    h: 34,
    facing: -Math.PI / 2,
    doorX: 319,
    doorZ: 660,
    frontX: 314,
    frontZ: 660,
    interiorId: 'city_hotel',
    wallColor: '#efe3cc',
    roofColor: '#92400e',
    style: 'hotel',
  },
  {
    id: 'CITY_RESTO',
    islandId: 'ISL_CITY',
    name: 'مطعم الديوان الشرقي',
    emoji: '🍽️',
    kind: 'commercial',
    x: 210,
    z: 720,
    w: 24,
    d: 18,
    h: 9,
    facing: Math.PI / 2,
    doorX: 222,
    doorZ: 720,
    frontX: 227,
    frontZ: 720,
    interiorId: 'city_resto',
    wallColor: '#f6e4cc',
    roofColor: '#c2410c',
    style: 'restaurant',
  },
  {
    id: 'CITY_MUSEUM',
    islandId: 'ISL_CITY',
    name: 'متحف الحضارات الوطني',
    emoji: '🏺',
    kind: 'temple',
    x: 335,
    z: 720,
    w: 30,
    d: 22,
    h: 14,
    facing: -Math.PI / 2,
    doorX: 320,
    doorZ: 720,
    frontX: 315,
    frontZ: 720,
    interiorId: 'city_museum',
    wallColor: '#f3ead8',
    roofColor: '#b45309',
    style: 'museum',
  },

  // ============ ISL_LIFE ============
  {
    id: 'LIFE_UNI',
    islandId: 'ISL_LIFE',
    name: 'جامعة العلوم والهندسة',
    emoji: '🎓',
    kind: 'civic',
    x: 630,
    z: 540,
    w: 36,
    d: 26,
    h: 16,
    facing: 0,
    doorX: 630,
    doorZ: 553,
    frontX: 630,
    frontZ: 558,
    interiorId: 'life_uni',
    wallColor: '#efe2c9',
    roofColor: '#1e40af',
    style: 'university',
  },
  {
    id: 'LIFE_LIB',
    islandId: 'ISL_LIFE',
    name: 'بيت الحكمة والمكتبة الكبرى',
    emoji: '📚',
    kind: 'civic',
    x: 630,
    z: 660,
    w: 32,
    d: 24,
    h: 15,
    facing: Math.PI,
    doorX: 630,
    doorZ: 648,
    frontX: 630,
    frontZ: 643,
    interiorId: 'life_lib',
    wallColor: '#f4e7ce',
    roofColor: '#0f766e',
    style: 'library',
  },
  {
    id: 'LIFE_TEMPLE',
    islandId: 'ISL_LIFE',
    name: 'معبد الشمس والغرفة السرية',
    emoji: '🏛️',
    kind: 'temple',
    x: 785,
    z: 540,
    w: 34,
    d: 28,
    h: 16,
    facing: 0,
    doorX: 785,
    doorZ: 554,
    frontX: 785,
    frontZ: 559,
    interiorId: 'life_temple',
    wallColor: '#d9c39e',
    roofColor: '#92400e',
    style: 'temple',
  },
  {
    id: 'LIFE_AMUSE',
    islandId: 'ISL_LIFE',
    name: 'مدينة الملاهي والمرصد',
    emoji: '🎡',
    kind: 'leisure',
    x: 785,
    z: 675,
    w: 44,
    d: 36,
    h: 28,
    facing: Math.PI,
    doorX: 785,
    doorZ: 657,
    frontX: 785,
    frontZ: 652,
    actionType: 'open:leisure',
    wallColor: '#f43f5e',
    roofColor: '#f59e0b',
    style: 'amusement',
  },
];

// 36 Agricultural parcels neatly organized into 4 quadrants on ISL_AGRI (clear of roads at x=-480 and z=670)
export const FARM_PARCELS: FarmParcelDef[] = (() => {
  const list: FarmParcelDef[] = [];
  const defaultCrops = ['wheat', 'corn', 'tomato', 'cucumber', 'carrot', 'sunflower', 'strawberry', 'lemon', 'olive', 'grapes', 'watermelon'];
  // Quadrant 1: North-East of ISL_AGRI crossroad (3x3)
  // Quadrant 2: South-East (3x3)
  // Quadrant 3: South-West (3x3)
  // Quadrant 4: North-West outer (3x3)
  const quads = [
    { ox: -450, oz: 500 },
    { ox: -450, oz: 705 },
    { ox: -630, oz: 705 },
    { ox: -630, oz: 500 },
  ];
  let idx = 0;
  quads.forEach((q) => {
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        const id = `FARM_P${String(idx + 1).padStart(2, '0')}`;
        list.push({
          id,
          index: idx,
          x: q.ox + c * 32,
          z: q.oz + r * 32,
          w: 24,
          d: 24,
          defaultCrop: defaultCrops[idx % defaultCrops.length],
          price: idx < 6 ? 0 : 120 + idx * 15,
        });
        idx++;
      }
    }
  });
  return list;
})();

export const GAS_STATIONS: GasStationDef[] = [
  { id: 'gs_home', name: 'محطة وقود وشحن القرية', islandId: 'ISL_HOME', x: 32, z: 68, hasEV: true, hasGas: true },
  { id: 'gs_ind', name: 'محطة وقود المنطقة الصناعية', islandId: 'ISL_INDUSTRY', x: 250, z: 100, hasEV: true, hasGas: true },
  { id: 'gs_city', name: 'محطة العاصمة الكهربائية والوقود', islandId: 'ISL_CITY', x: 240, z: 580, hasEV: true, hasGas: true },
  { id: 'gs_port', name: 'محطة ديزل الميناء', islandId: 'ISL_PORT', x: -415, z: 1090, hasEV: false, hasGas: true },
];

export const BUS_STOPS: BusStopDef[] = [
  { id: 'bs_home', name: 'موقف القرية الرئيسي', islandId: 'ISL_HOME', x: -22, z: 56 },
  { id: 'bs_biz', name: 'موقف البورصة والبنك', islandId: 'ISL_BUSINESS', x: -405, z: 245 },
  { id: 'bs_agri', name: 'موقف القرية الزراعية', islandId: 'ISL_AGRI', x: -465, z: 685 },
  { id: 'bs_port', name: 'موقف الميناء البحري', islandId: 'ISL_PORT', x: -425, z: 1125 },
  { id: 'bs_ind', name: 'موقف مصنع النور', islandId: 'ISL_INDUSTRY', x: 345, z: 145 },
  { id: 'bs_city', name: 'موقف ميدان العاصمة', islandId: 'ISL_CITY', x: 255, z: 615 },
  { id: 'bs_life', name: 'موقف الجامعة والمعبد', islandId: 'ISL_LIFE', x: 685, z: 615 },
];

export const DIG_SPOTS: DigSpotDef[] = [
  { id: 'dig_home_shore', name: 'شاطئ القرية الشمالي الغربي', islandId: 'ISL_HOME', x: -86, z: -72, era: 'ancient', hint: 'آثار مدفونة في رمال الشاطئ قرب القصر' },
  { id: 'dig_biz_ruin', name: 'رواق التجارة القديم', islandId: 'ISL_BUSINESS', x: -495, z: 295, era: 'classical', hint: 'عملات وأمفورات تحت الرواق الحجري' },
  { id: 'dig_agri_mound', name: 'تل السد التراثي', islandId: 'ISL_AGRI', x: -575, z: 755, era: 'ancient', hint: 'ألواح زراعية قديمة بجانب النواعير' },
  { id: 'dig_port_cove', name: 'مرسى القوارب الغارق', islandId: 'ISL_PORT', x: -535, z: 1190, era: 'medieval', hint: 'بوصلات وكنوز سفن قديمة' },
  { id: 'dig_temple_inner', name: 'حرم معبد الشمس', islandId: 'ISL_LIFE', x: 785, z: 540, era: 'ancient', hint: 'كنوز ملكية مخبأة داخل المعبد' },
];

export function islandAtPoint(x: number, z: number): IslandDef {
  let best = ISLANDS.ISL_HOME;
  let bestDist = Infinity;
  for (const isl of Object.values(ISLANDS)) {
    const d = Math.hypot(x - isl.cx, z - isl.cz);
    if (d <= isl.radius + 15 && d < bestDist) {
      bestDist = d;
      best = isl;
    }
  }
  return best;
}
