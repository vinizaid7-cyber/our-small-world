export type FuelType = 'gas' | 'ev' | 'diesel';

export interface CropDef {
  id: string;
  name: string;
  emoji: string;
  seedPrice: number;
  sellPrice: number;
  growSec: number;
  color: string;
}

export interface VehicleDef {
  id: string;
  name: string;
  emoji: string;
  category: 'compact' | 'sedan' | 'suv' | 'sport' | 'truck' | 'transit' | 'service' | 'ev' | 'farm';
  price: number;
  topSpeed: number; // m/s
  accel: number;
  length: number;
  width: number;
  height: number;
  fuelType: FuelType;
  tankSize: number;
  fuelBurnPerSec: number;
  seats: number;
  defaultColor: string;
  desc: string;
}

export interface FactoryRecipe {
  id: string;
  factoryId: string;
  name: string;
  emoji: string;
  inputs: Record<string, number>;
  outputs: Record<string, number>;
  durationSec: number;
  minWorkers: number;
  powerKw: number;
  sellValue: number;
}

export interface FactoryDef {
  id: string;
  siteId: string;
  interiorId: string;
  name: string;
  subtitle: string;
  emoji: string;
  zone: 'heavy' | 'light';
  buildCost: number;
  maxWorkers: number;
  maxMachines: number;
  storageCap: number;
  color: string;
  roofColor: string;
  recipes: string[];
}

export interface StockCompany {
  ticker: string;
  name: string;
  sector: string;
  emoji: string;
  basePrice: number;
  linkedFactoryId?: string;
  linkedSector: 'glass' | 'steel' | 'agri' | 'port' | 'bank' | 'tech' | 'food' | 'heritage';
  dividendRate: number;
}

export interface TechNode {
  id: string;
  name: string;
  emoji: string;
  cost: number;
  prereq: string[];
  desc: string;
  unlocks: string;
}

export interface ArtifactDef {
  id: string;
  name: string;
  emoji: string;
  era: 'ancient' | 'classical' | 'islamic' | 'medieval';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  value: number;
  dailyTourism: number;
  color: string;
}

export interface BuilderBlueprint {
  id: string;
  name: string;
  emoji: string;
  category: 'home' | 'commercial' | 'industrial' | 'civic' | 'park';
  cost: number;
  w: number;
  d: number;
  h: number;
  color: string;
  roofColor: string;
  popDelta: number;
  jobsDelta: number;
  happyDelta: number;
  pollutionDelta: number;
  powerNeed: number;
  waterNeed: number;
  materialsReq: Record<string, number>;
  stages: number; // e.g., 3 stages: Foundation -> Structure -> Finish
}

export interface QuestStep {
  id: string;
  title: string;
  hint: string;
  islandId: string;
  targetX: number;
  targetZ: number;
  checkType: 'visit_site' | 'enter_interior' | 'factory_batch' | 'buy_stock' | 'port_export' | 'harvest_crop' | 'excavate' | 'build_place' | 'refuel';
  targetId?: string;
  rewardCoins: number;
  rewardXp: number;
}

export const CROPS: Record<string, CropDef> = {
  wheat: { id: 'wheat', name: 'قمح ذهبي', emoji: '🌾', seedPrice: 6, sellPrice: 16, growSec: 35, color: '#eab308' },
  corn: { id: 'corn', name: 'ذرة حلوة', emoji: '🌽', seedPrice: 9, sellPrice: 24, growSec: 45, color: '#facc15' },
  tomato: { id: 'tomato', name: 'طماطم', emoji: '🍅', seedPrice: 8, sellPrice: 22, growSec: 40, color: '#ef4444' },
  cucumber: { id: 'cucumber', name: 'خيار', emoji: '🥒', seedPrice: 7, sellPrice: 19, growSec: 35, color: '#22c55e' },
  carrot: { id: 'carrot', name: 'جزر', emoji: '🥕', seedPrice: 8, sellPrice: 21, growSec: 40, color: '#f97316' },
  sunflower: { id: 'sunflower', name: 'دوار الشمس', emoji: '🌻', seedPrice: 12, sellPrice: 32, growSec: 55, color: '#f59e0b' },
  strawberry: { id: 'strawberry', name: 'فراولة', emoji: '🍓', seedPrice: 15, sellPrice: 40, growSec: 60, color: '#e11d48' },
  lemon: { id: 'lemon', name: 'ليمون', emoji: '🍋', seedPrice: 18, sellPrice: 46, growSec: 70, color: '#fde047' },
  olive: { id: 'olive', name: 'زيتون مبارك', emoji: '🫒', seedPrice: 20, sellPrice: 52, growSec: 75, color: '#65a30d' },
  grapes: { id: 'grapes', name: 'عنب', emoji: '🍇', seedPrice: 22, sellPrice: 58, growSec: 80, color: '#9333ea' },
  watermelon: { id: 'watermelon', name: 'بطيخ', emoji: '🍉', seedPrice: 24, sellPrice: 64, growSec: 85, color: '#16a34a' },
};

export const MATERIALS_META: Record<string, { name: string; emoji: string; basePrice: number }> = {
  silica_sand: { name: 'رمل السيليكا النقي', emoji: '🏜️', basePrice: 12 },
  soda_ash: { name: 'كربونات الصوديوم', emoji: '🧪', basePrice: 16 },
  limestone: { name: 'حجر جيري', emoji: '🪨', basePrice: 10 },
  iron_ore: { name: 'خام الحديد', emoji: '⛏️', basePrice: 18 },
  coal: { name: 'فحم حراري', emoji: '🖤', basePrice: 14 },
  timber_log: { name: 'جذوع خشب الأرز', emoji: '🪵', basePrice: 15 },
  raw_clay: { name: 'طين خزفي', emoji: '🧱', basePrice: 11 },
  cotton_wool: { name: 'قطن وحرير خام', emoji: '🧶', basePrice: 17 },
  silicon_wafer: { name: 'رقائق السيليكون', emoji: '💾', basePrice: 35 },
  copper: { name: 'أسلاك نحاسية', emoji: '🔌', basePrice: 22 },
  // Manufactured goods
  glass_sheet: { name: 'ألواح زجاج معماري', emoji: '🪟', basePrice: 68 },
  glass_bottle: { name: 'قوارير زجاجية مصقولة', emoji: '🍾', basePrice: 54 },
  stained_glass: { name: 'زجاج معشّق فني', emoji: '🎨', basePrice: 115 },
  steel_beam: { name: 'عوارض فولاذية', emoji: '🏗️', basePrice: 95 },
  wood_plank: { name: 'ألواح خشبية فاخرة', emoji: '🪑', basePrice: 62 },
  royal_pottery: { name: 'خزف وفخار مزجّج', emoji: '🏺', basePrice: 78 },
  silk_fabric: { name: 'أقمشة حريرية فاخرة', emoji: '🧵', basePrice: 88 },
  artisan_bread: { name: 'مخبوزات وأغذية معلبة', emoji: '🥖', basePrice: 52 },
  smart_chip: { name: 'معالجات ووحدات روبوت', emoji: '🤖', basePrice: 185 },
};

export const FACTORIES: Record<string, FactoryDef> = {
  glass: {
    id: 'glass',
    siteId: 'IND_GLASS',
    interiorId: 'ind_glass',
    name: 'مصنع النور لصناعة الزجاج',
    subtitle: 'أفران صهر 1500°م · خط تلدين · قص وفحص جودة',
    emoji: '🪟',
    zone: 'heavy',
    buildCost: 0,
    maxWorkers: 12,
    maxMachines: 4,
    storageCap: 120,
    color: '#0ea5e9',
    roofColor: '#1e3a5f',
    recipes: ['rec_glass_sheet', 'rec_glass_bottle', 'rec_stained_glass'],
  },
  steel: {
    id: 'steel',
    siteId: 'IND_STEEL',
    interiorId: 'ind_steel',
    name: 'مصنع الفولاذ والصلب الثقيل',
    subtitle: 'فرن صهر لافح · درفلة عوارض الإنشاءات',
    emoji: '⚙️',
    zone: 'heavy',
    buildCost: 850,
    maxWorkers: 10,
    maxMachines: 3,
    storageCap: 100,
    color: '#64748b',
    roofColor: '#334155',
    recipes: ['rec_steel_beam'],
  },
  wood: {
    id: 'wood',
    siteId: 'IND_WOOD',
    interiorId: 'ind_wood',
    name: 'منجرة وورش الأخشاب',
    subtitle: 'مناشير آلية · تجفيف ومعالجة الأثاث',
    emoji: '🪵',
    zone: 'light',
    buildCost: 500,
    maxWorkers: 8,
    maxMachines: 3,
    storageCap: 90,
    color: '#b45309',
    roofColor: '#78350f',
    recipes: ['rec_wood_plank'],
  },
  pottery: {
    id: 'pottery',
    siteId: 'IND_POTTERY',
    interiorId: 'ind_pottery',
    name: 'مصنع الخزف والفخار الملكي',
    subtitle: 'دواليب تشكيل · أفران تزجيج ونقش تراثي',
    emoji: '🏺',
    zone: 'light',
    buildCost: 550,
    maxWorkers: 8,
    maxMachines: 3,
    storageCap: 85,
    color: '#c2410c',
    roofColor: '#7c2d12',
    recipes: ['rec_royal_pottery'],
  },
  textile: {
    id: 'textile',
    siteId: 'IND_TEXTILE',
    interiorId: 'ind_textile',
    name: 'مصنع المنسوجات والحرير',
    subtitle: 'أنوال نسيج سريعة · صباغة وتفصيل',
    emoji: '🧵',
    zone: 'light',
    buildCost: 650,
    maxWorkers: 10,
    maxMachines: 4,
    storageCap: 100,
    color: '#9333ea',
    roofColor: '#581c87',
    recipes: ['rec_silk_fabric'],
  },
  food: {
    id: 'food',
    siteId: 'IND_FOOD',
    interiorId: 'ind_food',
    name: 'مصنع الأغذية والمخابز الحديثة',
    subtitle: 'خطوط عجن وخبز · تعبئة وتعقيم آلي',
    emoji: '🥖',
    zone: 'light',
    buildCost: 600,
    maxWorkers: 8,
    maxMachines: 3,
    storageCap: 110,
    color: '#d97706',
    roofColor: '#92400e',
    recipes: ['rec_artisan_bread'],
  },
  electronics: {
    id: 'electronics',
    siteId: 'IND_ELEC',
    interiorId: 'ind_elec',
    name: 'مصنع الإلكترونيات والروبوتات',
    subtitle: 'غرفة نظيفة · أذرع روبوتية لتجميع المعالجات',
    emoji: '🤖',
    zone: 'heavy',
    buildCost: 1400,
    maxWorkers: 10,
    maxMachines: 4,
    storageCap: 80,
    color: '#2563eb',
    roofColor: '#1e1b4b',
    recipes: ['rec_smart_chip'],
  },
};

export const FACTORY_RECIPES: Record<string, FactoryRecipe> = {
  rec_glass_sheet: {
    id: 'rec_glass_sheet',
    factoryId: 'glass',
    name: 'ألواح زجاج معماري',
    emoji: '🪟',
    inputs: { silica_sand: 3, soda_ash: 1, limestone: 1 },
    outputs: { glass_sheet: 3 },
    durationSec: 18,
    minWorkers: 2,
    powerKw: 40,
    sellValue: 68,
  },
  rec_glass_bottle: {
    id: 'rec_glass_bottle',
    factoryId: 'glass',
    name: 'قوارير زجاجية مصقولة',
    emoji: '🍾',
    inputs: { silica_sand: 2, soda_ash: 1 },
    outputs: { glass_bottle: 4 },
    durationSec: 14,
    minWorkers: 1,
    powerKw: 30,
    sellValue: 54,
  },
  rec_stained_glass: {
    id: 'rec_stained_glass',
    factoryId: 'glass',
    name: 'زجاج معشّق تراثي',
    emoji: '🎨',
    inputs: { silica_sand: 3, soda_ash: 2, limestone: 1 },
    outputs: { stained_glass: 2 },
    durationSec: 24,
    minWorkers: 3,
    powerKw: 50,
    sellValue: 115,
  },
  rec_steel_beam: {
    id: 'rec_steel_beam',
    factoryId: 'steel',
    name: 'عوارض فولاذية',
    emoji: '🏗️',
    inputs: { iron_ore: 3, coal: 2 },
    outputs: { steel_beam: 3 },
    durationSec: 22,
    minWorkers: 2,
    powerKw: 65,
    sellValue: 95,
  },
  rec_wood_plank: {
    id: 'rec_wood_plank',
    factoryId: 'wood',
    name: 'ألواح خشبية معالجة',
    emoji: '🪑',
    inputs: { timber_log: 3 },
    outputs: { wood_plank: 4 },
    durationSec: 15,
    minWorkers: 1,
    powerKw: 20,
    sellValue: 62,
  },
  rec_royal_pottery: {
    id: 'rec_royal_pottery',
    factoryId: 'pottery',
    name: 'خزف وفخار مزجّج',
    emoji: '🏺',
    inputs: { raw_clay: 3, coal: 1 },
    outputs: { royal_pottery: 3 },
    durationSec: 16,
    minWorkers: 1,
    powerKw: 25,
    sellValue: 78,
  },
  rec_silk_fabric: {
    id: 'rec_silk_fabric',
    factoryId: 'textile',
    name: 'أقمشة حريرية',
    emoji: '🧵',
    inputs: { cotton_wool: 3 },
    outputs: { silk_fabric: 3 },
    durationSec: 16,
    minWorkers: 2,
    powerKw: 25,
    sellValue: 88,
  },
  rec_artisan_bread: {
    id: 'rec_artisan_bread',
    factoryId: 'food',
    name: 'مخبوزات معلبة',
    emoji: '🥖',
    inputs: { wheat: 4, tomato: 1 },
    outputs: { artisan_bread: 5 },
    durationSec: 12,
    minWorkers: 1,
    powerKw: 18,
    sellValue: 52,
  },
  rec_smart_chip: {
    id: 'rec_smart_chip',
    factoryId: 'electronics',
    name: 'معالجات وروبوتات ذكية',
    emoji: '🤖',
    inputs: { silicon_wafer: 2, copper: 2, glass_sheet: 1 },
    outputs: { smart_chip: 2 },
    durationSec: 28,
    minWorkers: 3,
    powerKw: 75,
    sellValue: 185,
  },
};

export const STOCK_COMPANIES: StockCompany[] = [
  { ticker: 'ALNOOR', name: 'شركة النور للزجاج', sector: 'الصناعات الثقيلة', emoji: '🪟', basePrice: 48, linkedFactoryId: 'glass', linkedSector: 'glass', dividendRate: 0.035 },
  { ticker: 'STEELCO', name: 'مؤسسة الفولاذ الكبرى', sector: 'البناء والصلب', emoji: '⚙️', basePrice: 62, linkedFactoryId: 'steel', linkedSector: 'steel', dividendRate: 0.03 },
  { ticker: 'AGRICO', name: 'الشركة الزراعية المتحدة', sector: 'الزراعة والري', emoji: '🌾', basePrice: 34, linkedSector: 'agri', dividendRate: 0.04 },
  { ticker: 'MARITIME', name: 'ملاحة الميناء والتجارة', sector: 'النقل البحري', emoji: '🚢', basePrice: 55, linkedSector: 'port', dividendRate: 0.038 },
  { ticker: 'CIVICBK', name: 'البنك التجاري المركزي', sector: 'المصارف والتمويل', emoji: '🏦', basePrice: 74, linkedSector: 'bank', dividendRate: 0.045 },
  { ticker: 'TECHBOT', name: 'مختبرات المستقبل للروبوتات', sector: 'التقنية والطاقة', emoji: '🤖', basePrice: 88, linkedFactoryId: 'electronics', linkedSector: 'tech', dividendRate: 0.02 },
  { ticker: 'FOODCO', name: 'مجموعة المخبوزات والأغذية', sector: 'الأغذية', emoji: '🥖', basePrice: 41, linkedFactoryId: 'food', linkedSector: 'food', dividendRate: 0.032 },
  { ticker: 'HERITAGE', name: 'هيئة الآثار والسياحة', sector: 'الثقافة والسياحة', emoji: '🏛️', basePrice: 52, linkedSector: 'heritage', dividendRate: 0.042 },
];

export const VEHICLES: Record<string, VehicleDef> = {
  mini: { id: 'mini', name: 'ميني سيتي', emoji: '🚗', category: 'compact', price: 240, topSpeed: 24, accel: 16, length: 3.6, width: 1.75, height: 1.45, fuelType: 'gas', tankSize: 40, fuelBurnPerSec: 0.28, seats: 2, defaultColor: '#e63946', desc: 'سيارة مدينة رشيقة سهلة الركن' },
  kei: { id: 'kei', name: 'كي المدمجة', emoji: '🚙', category: 'compact', price: 210, topSpeed: 21, accel: 14, length: 3.3, width: 1.65, height: 1.55, fuelType: 'gas', tankSize: 35, fuelBurnPerSec: 0.22, seats: 2, defaultColor: '#38bdf8', desc: 'اقتصادية في استهلاك الوقود' },
  hatch: { id: 'hatch', name: 'هاتشباك سبورت', emoji: '🚘', category: 'compact', price: 320, topSpeed: 27, accel: 18, length: 3.9, width: 1.8, height: 1.48, fuelType: 'gas', tankSize: 45, fuelBurnPerSec: 0.32, seats: 4, defaultColor: '#f59e0b', desc: 'عملية مع تسارع ممتاز' },
  beetle: { id: 'beetle', name: 'كلاسيك بيتل', emoji: '🐞', category: 'compact', price: 360, topSpeed: 22, accel: 13, length: 3.8, width: 1.75, height: 1.52, fuelType: 'gas', tankSize: 42, fuelBurnPerSec: 0.3, seats: 2, defaultColor: '#10b981', desc: 'تصميم تراثي محبوب' },
  sedan: { id: 'sedan', name: 'سيدان العائلية', emoji: '🚘', category: 'sedan', price: 420, topSpeed: 28, accel: 17, length: 4.5, width: 1.85, height: 1.48, fuelType: 'gas', tankSize: 55, fuelBurnPerSec: 0.35, seats: 4, defaultColor: '#3b82f6', desc: 'مريحة للرحلات بين الجزر' },
  taxi: { id: 'taxi', name: 'تاكسي العاصمة', emoji: '🚕', category: 'sedan', price: 460, topSpeed: 28, accel: 17, length: 4.5, width: 1.85, height: 1.52, fuelType: 'gas', tankSize: 58, fuelBurnPerSec: 0.35, seats: 4, defaultColor: '#eab308', desc: 'تعمل على خطوط المدينة' },
  classic: { id: 'classic', name: 'كلاسيك رويال 1965', emoji: '🕰️', category: 'sedan', price: 680, topSpeed: 26, accel: 15, length: 4.8, width: 1.9, height: 1.46, fuelType: 'gas', tankSize: 60, fuelBurnPerSec: 0.45, seats: 4, defaultColor: '#7f1d1d', desc: 'تحفة تاريخية بكروم لامع' },
  wagon: { id: 'wagon', name: 'واغن سياحية', emoji: '🚙', category: 'sedan', price: 480, topSpeed: 26, accel: 15, length: 4.7, width: 1.85, height: 1.56, fuelType: 'gas', tankSize: 60, fuelBurnPerSec: 0.36, seats: 5, defaultColor: '#0d9488', desc: 'صندوق أمتعة واسع' },
  lux: { id: 'lux', name: 'سيدان فاخرة', emoji: '✨', category: 'sedan', price: 950, topSpeed: 32, accel: 20, length: 4.9, width: 1.95, height: 1.5, fuelType: 'gas', tankSize: 70, fuelBurnPerSec: 0.45, seats: 4, defaultColor: '#1e293b', desc: 'فخامة وهدوء وعزل كامل' },
  limo: { id: 'limo', name: 'ليموزين القصر', emoji: '🎩', category: 'sedan', price: 1450, topSpeed: 29, accel: 16, length: 6.4, width: 2.0, height: 1.54, fuelType: 'gas', tankSize: 80, fuelBurnPerSec: 0.55, seats: 6, defaultColor: '#0f172a', desc: 'سيارة الشخصيات الرسمية' },
  ev_sedan: { id: 'ev_sedan', name: 'نوفا الكهربائية EV', emoji: '⚡', category: 'ev', price: 780, topSpeed: 34, accel: 24, length: 4.6, width: 1.9, height: 1.44, fuelType: 'ev', tankSize: 100, fuelBurnPerSec: 0.25, seats: 4, defaultColor: '#06b6d4', desc: 'صفر انبعاثات مع شحن كهربائي سريع' },
  ev_suv: { id: 'ev_suv', name: 'ترا الكهربائي SUV', emoji: '🔋', category: 'ev', price: 980, topSpeed: 31, accel: 22, length: 4.8, width: 2.0, height: 1.72, fuelType: 'ev', tankSize: 120, fuelBurnPerSec: 0.3, seats: 5, defaultColor: '#14b8a6', desc: 'دفع رباعي كهربائي ذكي' },
  suvc: { id: 'suvc', name: 'كروس أوفر', emoji: '🚙', category: 'suv', price: 540, topSpeed: 27, accel: 16, length: 4.4, width: 1.9, height: 1.66, fuelType: 'gas', tankSize: 60, fuelBurnPerSec: 0.38, seats: 5, defaultColor: '#6366f1', desc: 'توازن بين المدينة والطرق الوعرة' },
  suv: { id: 'suv', name: 'SUV الكبيرة', emoji: '🚙', category: 'suv', price: 720, topSpeed: 28, accel: 16, length: 4.9, width: 2.02, height: 1.82, fuelType: 'gas', tankSize: 75, fuelBurnPerSec: 0.48, seats: 7, defaultColor: '#334155', desc: 'قوة وثبات على كل الطرق' },
  jeep: { id: 'jeep', name: 'جيب الصحراء 4×4', emoji: '🏜️', category: 'suv', price: 650, topSpeed: 26, accel: 17, length: 4.3, width: 1.95, height: 1.85, fuelType: 'gas', tankSize: 70, fuelBurnPerSec: 0.46, seats: 4, defaultColor: '#ca8a04', desc: 'مخصص للمواقع الأثرية والرمال' },
  offroad: { id: 'offroad', name: 'أوف رود المدرّعة', emoji: '⛰️', category: 'suv', price: 890, topSpeed: 27, accel: 18, length: 4.7, width: 2.1, height: 1.95, fuelType: 'diesel', tankSize: 85, fuelBurnPerSec: 0.5, seats: 4, defaultColor: '#4d7c0f', desc: 'تعليق مرتفع وإطارات ضخمة' },
  buggy: { id: 'buggy', name: 'باجي الشاطئ', emoji: '🏖️', category: 'sport', price: 310, topSpeed: 29, accel: 21, length: 3.2, width: 1.8, height: 1.38, fuelType: 'gas', tankSize: 32, fuelBurnPerSec: 0.3, seats: 2, defaultColor: '#f97316', desc: 'خفيف وممتع على الشواطئ' },
  coupe: { id: 'coupe', name: 'كوبيه جي تي', emoji: '🏎️', category: 'sport', price: 860, topSpeed: 36, accel: 24, length: 4.4, width: 1.92, height: 1.32, fuelType: 'gas', tankSize: 58, fuelBurnPerSec: 0.52, seats: 2, defaultColor: '#dc2626', desc: 'انسيابية عالية وأداء رياضي' },
  muscle: { id: 'muscle', name: 'ماسل V8', emoji: '🔥', category: 'sport', price: 920, topSpeed: 37, accel: 25, length: 4.7, width: 1.96, height: 1.35, fuelType: 'gas', tankSize: 65, fuelBurnPerSec: 0.6, seats: 2, defaultColor: '#b91c1c', desc: 'محرك V8 بصوت قوي' },
  roadster: { id: 'roadster', name: 'رودستر مكشوفة', emoji: '☀️', category: 'sport', price: 1050, topSpeed: 38, accel: 26, length: 4.2, width: 1.9, height: 1.24, fuelType: 'gas', tankSize: 55, fuelBurnPerSec: 0.54, seats: 2, defaultColor: '#ec4899', desc: 'سيارة صيفية مكشوفة السقف' },
  sport: { id: 'sport', name: 'سبورت تيربو', emoji: '🏁', category: 'sport', price: 1200, topSpeed: 41, accel: 28, length: 4.45, width: 1.98, height: 1.24, fuelType: 'gas', tankSize: 60, fuelBurnPerSec: 0.62, seats: 2, defaultColor: '#ea580c', desc: 'مخصصة للحلبات والطرق السريعة' },
  super: { id: 'super', name: 'سوبركار X15', emoji: '⚡', category: 'sport', price: 1850, topSpeed: 46, accel: 32, length: 4.55, width: 2.04, height: 1.18, fuelType: 'gas', tankSize: 65, fuelBurnPerSec: 0.7, seats: 2, defaultColor: '#facc15', desc: 'أسرع مركبة في عالمنا الصغير' },
  pickup: { id: 'pickup', name: 'بيك أب المزرعة', emoji: '🛻', category: 'truck', price: 520, topSpeed: 24, accel: 15, length: 5.1, width: 2.0, height: 1.82, fuelType: 'diesel', tankSize: 80, fuelBurnPerSec: 0.45, seats: 3, defaultColor: '#15803d', desc: 'مثالي لنقل المحاصيل والمواد' },
  van: { id: 'van', name: 'فان التوصيل', emoji: '🚐', category: 'truck', price: 560, topSpeed: 23, accel: 14, length: 5.0, width: 1.98, height: 2.15, fuelType: 'diesel', tankSize: 75, fuelBurnPerSec: 0.42, seats: 2, defaultColor: '#f8fafc', desc: 'لنقل الطرود بين المصانع' },
  boxtruck: { id: 'boxtruck', name: 'شاحنة بضائع ثقيلة', emoji: '🚛', category: 'truck', price: 960, topSpeed: 21, accel: 11, length: 7.4, width: 2.35, height: 3.1, fuelType: 'diesel', tankSize: 140, fuelBurnPerSec: 0.65, seats: 2, defaultColor: '#2563eb', desc: 'تنقل حاويات المصانع إلى الميناء' },
  citybus: { id: 'citybus', name: 'حافلة النقل العام', emoji: '🚌', category: 'transit', price: 1100, topSpeed: 22, accel: 11, length: 8.8, width: 2.45, height: 2.95, fuelType: 'diesel', tankSize: 160, fuelBurnPerSec: 0.68, seats: 16, defaultColor: '#0284c7', desc: 'تنقل المواطنين بين محطات الجزر' },
  schoolbus: { id: 'schoolbus', name: 'حافلة المدرسة', emoji: '🚍', category: 'transit', price: 920, topSpeed: 21, accel: 11, length: 8.2, width: 2.4, height: 2.9, fuelType: 'diesel', tankSize: 140, fuelBurnPerSec: 0.6, seats: 14, defaultColor: '#f59e0b', desc: 'لنقل الطلاب إلى المدرسة والجامعة' },
  tractor: { id: 'tractor', name: 'جرار زراعي', emoji: '🚜', category: 'farm', price: 450, topSpeed: 15, accel: 12, length: 3.8, width: 2.1, height: 2.4, fuelType: 'diesel', tankSize: 90, fuelBurnPerSec: 0.4, seats: 1, defaultColor: '#16a34a', desc: 'لحراثة الحقول وسحب المقطورات' },
  police: { id: 'police', name: 'دورية الشرطة', emoji: '🚓', category: 'service', price: 820, topSpeed: 35, accel: 24, length: 4.6, width: 1.9, height: 1.56, fuelType: 'gas', tankSize: 65, fuelBurnPerSec: 0.42, seats: 4, defaultColor: '#1e293b', desc: 'مجهزة بصفارة وأضواء طوارئ' },
  ambulance: { id: 'ambulance', name: 'سيارة الإسعاف', emoji: '🚑', category: 'service', price: 880, topSpeed: 32, accel: 21, length: 5.4, width: 2.08, height: 2.35, fuelType: 'diesel', tankSize: 80, fuelBurnPerSec: 0.48, seats: 4, defaultColor: '#ffffff', desc: 'للاستجابة السريعة للحوادث' },
};

export const TECH_TREE: TechNode[] = [
  { id: 'grid_power', name: 'شبكة الكهرباء المركزية', emoji: '⚡', cost: 250, prereq: [], desc: 'تغذي المصانع والبيوت وتزيد سرعة الإنتاج +15%', unlocks: 'طاقة أعلى للمصانع' },
  { id: 'water_grid', name: 'شبكة المياه والري الحديث', emoji: '💧', cost: 260, prereq: [], desc: 'تربط السد والمزارع وتسرّع نمو المحاصيل +20%', unlocks: 'ري آلي للمزارع' },
  { id: 'telecom', name: 'الاتصالات والإنترنت الداخلي', emoji: '📡', cost: 380, prereq: ['grid_power'], desc: 'يربط البورصة والمقر والميناء بأسعار لحظية', unlocks: 'إشعارات السوق الذكية' },
  { id: 'ev_infra', name: 'محطات الشحن الكهربائي', emoji: '🔋', cost: 450, prereq: ['grid_power'], desc: 'تفعيل شحن سيارات EV وتقليل تلوث المدينة', unlocks: 'سيارات كهربائية نظيفة' },
  { id: 'automation', name: 'الأتمتة والروبوتات الصناعية', emoji: '🤖', cost: 720, prereq: ['grid_power', 'telecom'], desc: 'تخفض وقت تصنيع الدفعات -25% في كل المصانع', unlocks: 'خطوط إنتاج مؤتمتة' },
  { id: 'smart_transit', name: 'شبكة الحافلات الذكية', emoji: '🚌', cost: 520, prereq: ['telecom'], desc: 'تزيد رضا المواطنين وتقلل الازدحام المروري', unlocks: 'كفاءة النقل العام' },
  { id: 'archaeology_tech', name: 'تقنيات التنقيب بالرادار', emoji: '🧭', cost: 480, prereq: ['water_grid'], desc: 'تضاعف فرص اكتشاف الآثار النادرة والأسطورية', unlocks: 'مسح أثري دقيق' },
];

export const ARTIFACTS: ArtifactDef[] = [
  { id: 'art_sun_seal', name: 'ختم الشمس الذهبي', emoji: '☀️', era: 'ancient', rarity: 'legendary', value: 420, dailyTourism: 35, color: '#fbbf24' },
  { id: 'art_glass_amphora', name: 'أمفورة زجاجية فينيقية', emoji: '🏺', era: 'classical', rarity: 'epic', value: 260, dailyTourism: 22, color: '#38bdf8' },
  { id: 'art_astrolabe', name: 'إسطرلاب بيت الحكمة', emoji: '🧭', era: 'islamic', rarity: 'legendary', value: 460, dailyTourism: 38, color: '#d97706' },
  { id: 'art_maritime_compass', name: 'بوصلة البحارة البرونزية', emoji: '⚓', era: 'medieval', rarity: 'rare', value: 180, dailyTourism: 14, color: '#0d9488' },
  { id: 'art_clay_tablet', name: 'لوح مسماري زراعي', emoji: '📜', era: 'ancient', rarity: 'common', value: 95, dailyTourism: 8, color: '#b45309' },
  { id: 'art_mosaic_bird', name: 'فسيفساء الطائر الملوّن', emoji: '🦚', era: 'classical', rarity: 'epic', value: 280, dailyTourism: 24, color: '#8b5cf6' },
  { id: 'art_royal_crown', name: 'تاج المعبد الغارق', emoji: '👑', era: 'ancient', rarity: 'legendary', value: 520, dailyTourism: 45, color: '#f59e0b' },
  { id: 'art_ceramic_lamp', name: 'مصباح خزفي منقوش', emoji: '🪔', era: 'islamic', rarity: 'rare', value: 165, dailyTourism: 12, color: '#ea580c' },
];

export const BUILDER_BLUEPRINTS: BuilderBlueprint[] = [
  {
    id: 'bp_villa_cottage',
    name: 'بيت حجري تراثي',
    emoji: '🏡',
    category: 'home',
    cost: 280,
    w: 11,
    d: 10,
    h: 6.5,
    color: '#efe3cc',
    roofColor: '#b45309',
    popDelta: 6,
    jobsDelta: 0,
    happyDelta: 4,
    pollutionDelta: 0,
    powerNeed: 10,
    waterNeed: 10,
    materialsReq: { wood_plank: 1, glass_sheet: 1 },
    stages: 3,
  },
  {
    id: 'bp_tower_apt',
    name: 'عمارة سكنية حديثة',
    emoji: '🏢',
    category: 'home',
    cost: 620,
    w: 16,
    d: 14,
    h: 18,
    color: '#cbd5e1',
    roofColor: '#334155',
    popDelta: 24,
    jobsDelta: 2,
    happyDelta: 3,
    pollutionDelta: 2,
    powerNeed: 35,
    waterNeed: 30,
    materialsReq: { steel_beam: 2, glass_sheet: 2 },
    stages: 3,
  },
  {
    id: 'bp_shop_plaza',
    name: 'سوق ومتجر تجاري',
    emoji: '🏬',
    category: 'commercial',
    cost: 440,
    w: 14,
    d: 12,
    h: 8,
    color: '#fde68a',
    roofColor: '#92400e',
    popDelta: 0,
    jobsDelta: 10,
    happyDelta: 6,
    pollutionDelta: 1,
    powerNeed: 22,
    waterNeed: 12,
    materialsReq: { glass_sheet: 1, wood_plank: 1 },
    stages: 3,
  },
  {
    id: 'bp_mini_factory',
    name: 'ورشة تصنيع متطورة',
    emoji: '🏭',
    category: 'industrial',
    cost: 580,
    w: 16,
    d: 14,
    h: 9,
    color: '#94a3b8',
    roofColor: '#1e293b',
    popDelta: 0,
    jobsDelta: 16,
    happyDelta: -2,
    pollutionDelta: 8,
    powerNeed: 45,
    waterNeed: 20,
    materialsReq: { steel_beam: 2 },
    stages: 3,
  },
  {
    id: 'bp_park_garden',
    name: 'حديقة عامة ونافورة',
    emoji: '🌳',
    category: 'park',
    cost: 190,
    w: 14,
    d: 14,
    h: 3.5,
    color: '#22c55e',
    roofColor: '#15803d',
    popDelta: 0,
    jobsDelta: 2,
    happyDelta: 12,
    pollutionDelta: -6,
    powerNeed: 5,
    waterNeed: 15,
    materialsReq: {},
    stages: 2,
  },
  {
    id: 'bp_solar_station',
    name: 'محطة طاقة شمسية نظيفة',
    emoji: '☀️',
    category: 'civic',
    cost: 460,
    w: 14,
    d: 12,
    h: 4.5,
    color: '#1d4ed8',
    roofColor: '#0f172a',
    popDelta: 0,
    jobsDelta: 6,
    happyDelta: 5,
    pollutionDelta: -4,
    powerNeed: -80,
    waterNeed: 5,
    materialsReq: { glass_sheet: 2 },
    stages: 2,
  },
];

export const QUESTS: QuestStep[] = [
  {
    id: 'q1_explore_villa',
    title: 'جولة في القصر الجديد',
    hint: 'ادخل من الباب الأمامي للقصر، ثم اصعد الدرج للطابق الثاني وافتح خزانة الملابس',
    islandId: 'ISL_HOME',
    targetX: 0,
    targetZ: -20,
    checkType: 'enter_interior',
    targetId: 'home_upper',
    rewardCoins: 120,
    rewardXp: 40,
  },
  {
    id: 'q2_glass_factory',
    title: 'زيارة مصنع النور للزجاج',
    hint: 'توجه إلى جزيرة الصناعة شرقاً وادخل مصنع النور للزجاج وشغّل دفعة إنتاج',
    islandId: 'ISL_INDUSTRY',
    targetX: 315,
    targetZ: 105,
    checkType: 'factory_batch',
    targetId: 'glass',
    rewardCoins: 200,
    rewardXp: 75,
  },
  {
    id: 'q3_stock_exchange',
    title: 'استثمار في البورصة المركزية',
    hint: 'زر جزيرة الأعمال غرباً، ادخل مبنى البورصة واشترِ أسهم شركة النور أو أي شركة',
    islandId: 'ISL_BUSINESS',
    targetX: -420,
    targetZ: 185,
    checkType: 'buy_stock',
    rewardCoins: 180,
    rewardXp: 60,
  },
  {
    id: 'q4_port_export',
    title: 'تصدير شحنة بحرية من الميناء',
    hint: 'انقل بضاعة إلى جزيرة الميناء وأطلق شحنة تصدير عبر السفينة والرافعة',
    islandId: 'ISL_PORT',
    targetX: -440,
    targetZ: 1085,
    checkType: 'port_export',
    rewardCoins: 260,
    rewardXp: 90,
  },
  {
    id: 'q5_temple_excavate',
    title: 'سر المعبد القديم',
    hint: 'توجّه إلى المعبد الأثري في جزيرة الحياة والعلم ونقّب عن قطعة أثرية نادرة',
    islandId: 'ISL_LIFE',
    targetX: 785,
    targetZ: 545,
    checkType: 'excavate',
    rewardCoins: 240,
    rewardXp: 85,
  },
];

export const OUTFITS = [
  { id: 'casual', name: 'كاجوال أنيق', emoji: '👕', price: 0, color: '#3b82f6' },
  { id: 'formal', name: 'بدلة رسمية', emoji: '🤵', price: 110, color: '#1e293b' },
  { id: 'merchant', name: 'لباس التاجر التراثي', emoji: '🧥', price: 140, color: '#b45309' },
  { id: 'engineer', name: 'زي مهندس المصنع', emoji: '🦺', price: 95, color: '#eab308' },
  { id: 'sailor', name: 'زي القبطان البحري', emoji: '⚓', price: 130, color: '#0369a1' },
  { id: 'farmer', name: 'زي المزارع', emoji: '🌾', price: 75, color: '#15803d' },
  { id: 'scholar', name: 'عباءة الحكيم والعالم', emoji: '🎓', price: 160, color: '#6d28d9' },
  { id: 'sporty', name: 'ملابس رياضية', emoji: '🏃', price: 85, color: '#e11d48' },
];

export const FURNITURE_CATALOG = [
  { id: 'sofa_royal', name: 'أريكة فاخرة', emoji: '🛋️', price: 120, color: '#7f1d1d' },
  { id: 'coffee_tbl', name: 'طاولة ضيافة رخام', emoji: '🪑', price: 70, color: '#cbd5e1' },
  { id: 'tv_oled', name: 'شاشة تلفاز ذكية', emoji: '📺', price: 180, color: '#0f172a' },
  { id: 'lamp_gold', name: 'أباجورة ذهبية', emoji: '💡', price: 55, color: '#f59e0b' },
  { id: 'plant_ficus', name: 'نبتة زينة داخلية', emoji: '🪴', price: 45, color: '#16a34a' },
  { id: 'bookshelf', name: 'مكتبة كتب خشبية', emoji: '📚', price: 135, color: '#78350f' },
  { id: 'rug_persian', name: 'سجادة فاخرة', emoji: '🧶', price: 90, color: '#991b1b' },
];

export const PETS_CATALOG = [
  { id: 'dog', name: 'كلب وفي', emoji: '🐕', price: 150, color: '#d97706' },
  { id: 'cat', name: 'قطة منزلية', emoji: '🐈', price: 130, color: '#f8fafc' },
  { id: 'rabbit', name: 'أرنب أبيض', emoji: '🐇', price: 90, color: '#e2e8f0' },
  { id: 'parrot', name: 'ببغاء ملوّن', emoji: '🦜', price: 160, color: '#10b981' },
];

export const FARM_ANIMALS = [
  { id: 'cow', name: 'بقرة حلوب', emoji: '🐄', price: 180, product: 'milk', productEmoji: '🥛', productVal: 24 },
  { id: 'sheep', name: 'خروف صوفي', emoji: '🐑', price: 120, product: 'cotton_wool', productEmoji: '🧶', productVal: 18 },
  { id: 'chicken', name: 'دجاجة بياضة', emoji: '🐔', price: 65, product: 'egg', productEmoji: '🥚', productVal: 12 },
  { id: 'horse', name: 'حصان عربي أصيل', emoji: '🐎', price: 320, product: 'ride', productEmoji: '🏇', productVal: 35 },
];
