/* محتوى القرية: البيوت، الشخصيات، الأسئلة، الجمل */
(function () {
  const OSW = window.OSW;

  const MOODS = ["😍", "🥰", "😂", "🥹", "😌", "🤩", "😅", "🌧️"];
  const DREAM_CATS = ["سفر ✈️", "بيت 🏡", "شغل 💼", "تجربة 🎈", "تعلّم 📚", "غير هيك ✨"];
  const KINDS = ["فيلم 🎬", "مسلسل 📺", "كتاب 📖", "برنامج 🎙️", "لعبة 🎮"];

  // fields: k = مكان التخزين (title/body/unlock_at/media أو داخل data)
  OSW.HOUSES = [
    {
      id: "first", name: "بيت أول مرة", emoji: "🐣", x: 300, y: 560, s: 0.92, wall: "#FFE29A", roof: "#F08A24", style: 0,
      resident: { name: "الكتكوت الفضولي", emoji: "🐣", lines: ["كل شي حلو إله أول مرة… شو كانت أولكم؟", "أنا بموت على حكاية البداية 🥹", "أول نظرة، أول رسالة، أول ضحكة… سجّلوهم كلهم!", "احكولي، شو أول شي ضحّككم سوا؟"] },
      empty: "لسا ما حدا سجّل أول مرة. ابدأ بأول لقاء!", add: "سجّل أول مرة", card: "first",
      fields: [
        { k: "title", label: "شو كانت؟", type: "text", ph: "مثلاً: أول لقاء", req: 1, chips: ["أول لقاء", "أول رسالة", "أول ضحكة", "أول هدية", "أول مكالمة", "أول سفرة", "أول خلاف", "أول «بحبك»"] },
        { k: "when", label: "إمتى؟", type: "date" },
        { k: "body", label: "شو صار؟ شو كان شعورك؟", type: "area", ph: "احكي بالتفصيل…" },
        { k: "media", label: "صور", type: "photos" },
      ],
    },
    {
      id: "memories", name: "ألبوم الذكريات", emoji: "📷", x: 610, y: 560, s: 0.92, wall: "#F6C7D9", roof: "#B83A6B", style: 1,
      resident: { name: "الجدة حكاية", emoji: "👵", lines: ["الذكريات مثل الشاي، بتطيب أكتر مع الوقت ☕", "تعالوا، خلّوا هالذكرى ما تروح.", "كل ذكرى بتنكتب بتصير بيت صغير بالقلب.", "شو رح نخزّن اليوم؟"] },
      empty: "البيت فاضي… أول ذكرى بتفتحه!", add: "أضف ذكرى", card: "memory", comment: { kind: "feel", label: "شعوري بالذكرى", ph: "كيف كان شعورك بهاليوم؟" },
      fields: [
        { k: "title", label: "اسم الذكرى", type: "text", ph: "مثلاً: سهرة العيد", req: 1 },
        { k: "when", label: "إمتى صارت؟", type: "date" },
        { k: "mood", label: "كيف كان الجو؟", type: "mood" },
        { k: "body", label: "احكي الذكرى", type: "area", ph: "شو صار؟ شو بتحب تتذكر؟" },
        { k: "media", label: "صور", type: "photos" },
      ],
    },
    {
      id: "moments", name: "بيت المواقف", emoji: "🎭", x: 920, y: 560, s: 0.92, wall: "#BDE7F5", roof: "#2879A8", style: 2,
      resident: { name: "أبو ضحكة", emoji: "🎭", lines: ["في مواقف بتنضحك عليها بعد سنة أكتر من يومها 😂", "احكي الموقف من عندك… وخلّيها تحكي من عندها!", "المحرج اليوم هو أحلى نكتة بكرة.", "كل موقف إله وجهتين نظر، وأنا بدي أسمع الاثنتين."] },
      empty: "ما في مواقف لسا. شو آخر موقف حصل؟", add: "احكي موقف", card: "moment", comment: { kind: "pov", label: "احكي من وجهة نظرك", ph: "كيف شفت أنت الموقف؟" },
      fields: [
        { k: "title", label: "عنوان الموقف", type: "text", ph: "مثلاً: ضيّعنا الطريق", req: 1 },
        { k: "when", label: "إمتى؟", type: "date" },
        { k: "body", label: "احكي الموقف من وجهة نظرك", type: "area", ph: "شو صار بالضبط؟" },
        { k: "media", label: "صور", type: "photos" },
      ],
    },
    {
      id: "letters", name: "البريد", emoji: "✉️", x: 1680, y: 560, s: 0.92, wall: "#E6D8FF", roof: "#6E4BC4", style: 3,
      resident: { name: "ساعي البريد نشمي", emoji: "📮", lines: ["عندي رسائل، بس ما بسلّم قبل ميعادها 😉", "الرسالة اللي بتنكتب بحب بتوصل قبل ما تنبعت.", "بدك تكتب لشريكك؟ ولا لنفسك بعد سنة؟", "الرسالة المقفلة بتستاهل الانتظار."] },
      empty: "ما في رسائل. اكتب أول رسالة!", add: "اكتب رسالة", card: "letter", sealed: true,
      fields: [
        { k: "to", label: "لمين؟", type: "select", opts: [["partner", "لـ {partner}"], ["me", "لنفسي (بس أنا بشوفها)"]] },
        { k: "title", label: "عنوان الرسالة", type: "text", ph: "عزيزي…", req: 1 },
        { k: "body", label: "الرسالة", type: "area", ph: "اكتب اللي بقلبك…", req: 1, big: 1 },
        { k: "unlock_at", label: "تنفتح بتاريخ (اختياري)", type: "unlock", chips: [["بعد أسبوع", 7], ["بعد شهر", 30], ["بعد 6 شهور", 182], ["بعد سنة", 365]] },
      ],
    },
    {
      id: "dreams", name: "نجمة الأحلام", emoji: "🌠", x: 1990, y: 560, s: 0.92, wall: "#CFC9FF", roof: "#3E3A9C", style: 1,
      resident: { name: "النجم الحالم", emoji: "🌟", lines: ["الحلم اللي بيتكتب بيقرّب خطوة.", "علّموا النجمة لما يتحقق حلم!", "كبيرة وصغيرة… كلها أحلام.", "الحلم المشترك له طعم تاني."] },
      empty: "اكتبوا أول حلم مشترك!", add: "أضف حلم", card: "dream",
      fields: [
        { k: "title", label: "الحلم", type: "text", ph: "مثلاً: نشوف الثلج سوا", req: 1 },
        { k: "cat", label: "نوعه", type: "select", opts: DREAM_CATS.map((c) => [c, c]) },
        { k: "body", label: "تفاصيل (اختياري)", type: "area", ph: "شو بدكم تعملوا بالضبط؟" },
      ],
    },
    {
      id: "songs", name: "رف الأغاني", emoji: "🎵", x: 2300, y: 560, s: 0.92, wall: "#BFF0DE", roof: "#118C6D", style: 0,
      resident: { name: "العازف أبو سالم", emoji: "🎻", lines: ["كل أغنية إلها ريحة ذكرى.", "شو الأغنية اللي لما بتنسمع بتبتسم؟", "أغنيتكم لسا ما اخترتوها؟ يلا!", "الأغنية بتضل لما الأيام بتروح."] },
      empty: "ما في أغاني. شو أغنيتكم؟", add: "أضف أغنية", card: "song",
      fields: [
        { k: "title", label: "اسم الأغنية", type: "text", req: 1 },
        { k: "artist", label: "الفنان", type: "text" },
        { k: "link", label: "رابط (يوتيوب/سبوتيفاي)", type: "url", ph: "https://…" },
        { k: "body", label: "ليش بتذكّرك فينا؟", type: "area", ph: "الذكرى المرتبطة فيها" },
        { k: "ours", label: "هاي أغنيتنا ⭐", type: "check" },
      ],
    },
    {
      id: "photos", name: "رف الصور", emoji: "🖼️", x: 260, y: 930, s: 0.95, wall: "#D7ECFF", roof: "#3A6EA5", style: 2,
      resident: { name: "المصوّر أبو فلاش", emoji: "📸", lines: ["لقطة وحدة بتحكي ألف كلمة.", "ما في صورة سيئة إذا كنتوا فيها سوا.", "علّقوا على كل صورة عشان ما تنسوا شو كان الجو.", "ابتسموا… كليك! 📸"] },
      empty: "الألبوم فاضي. ارفع أول صورة!", add: "أضف صور", card: "photo",
      fields: [
        { k: "title", label: "وصف الصورة", type: "text", ph: "مثلاً: عالبحر الميت", req: 1 },
        { k: "when", label: "إمتى؟", type: "date" },
        { k: "media", label: "الصور", type: "photos", req: 1 },
        { k: "body", label: "تعليق (اختياري)", type: "area" },
      ],
    },
    {
      id: "cafe", name: "المقهى", emoji: "☕", x: 600, y: 930, s: 0.95, wall: "#E9D2BE", roof: "#7A4A2E", style: 2,
      resident: { name: "أبو الهيل", emoji: "🧔", lines: ["قهوة وحكي عميق؟ تفضلوا.", "اسحب سؤال وجاوب بصدق.", "الحكي الحلو أحلى من القهوة.", "جاوب، وخلّي الثاني يشوف جوابك."] },
      empty: "ما في أجوبة محفوظة. اسحب سؤال!", add: "", card: "qa", special: "cafe",
      fields: [],
    },
    {
      id: "because", name: "بيت بحبك لأنو", emoji: "💌", x: 1960, y: 930, s: 0.95, wall: "#FFD0DC", roof: "#E63E6D", style: 0,
      resident: { name: "الحمامة الزاجلة", emoji: "🕊️", lines: ["كل سبب بتكتبه بيوصل للقلب.", "الأسباب ما بتخلص، زيدوا واحد كمان.", "شو اللي صار اليوم وخلّاك تحب أكتر؟", "ورقة صغيرة، وفرحة كبيرة."] },
      empty: "اكتب أول سبب: «بحبك لأنو…»", add: "أضف سبب", card: "because",
      fields: [{ k: "body", label: "بحبك لأنو…", type: "area", ph: "اكتب السبب…", req: 1 }],
    },
    {
      id: "station", name: "المحطة", emoji: "🚂", x: 2320, y: 930, s: 0.95, wall: "#D9E4EC", roof: "#4C5E73", style: 2,
      resident: { name: "قائد القطار", emoji: "🚂", lines: ["يا مسافرين! وين وجهتنا الجاية؟", "كل رحلة بتبدأ بحلم وتذكرة.", "سجّلوا الأماكن اللي زرتوها واللي بدكم تزوروها.", "طوط طوووط!"] },
      empty: "ما في رحلات. وين بدكم تروحوا؟", add: "أضف رحلة", card: "trip",
      fields: [
        { k: "title", label: "المكان", type: "text", ph: "مثلاً: العقبة", req: 1 },
        { k: "status", label: "وين وصلنا؟", type: "select", opts: [["planned", "بدنا نروح 🧳"], ["done", "رحنا ✅"]] },
        { k: "when", label: "إمتى؟", type: "date" },
        { k: "body", label: "تفاصيل أو ذكريات", type: "area" },
        { k: "media", label: "صور", type: "photos" },
      ],
    },
    {
      id: "fights", name: "بيت الخلافات الحلوة", emoji: "🕊️", x: 380, y: 1330, s: 1, wall: "#E4F0D0", roof: "#5C8F2E", style: 3,
      resident: { name: "الحكيم أبو الصلح", emoji: "🧙", lines: ["الخلاف مو عيب، العيب ما نتعلم منه.", "اكتبوا شو زعّلكم وكيف صالحتوا، بتنفع مرة تانية.", "الاعتذار الصادق بيبني بيت أقوى.", "الحب الكبير بيعرف يصلّح."] },
      empty: "ما في خلافات مسجّلة… الله يديم الحال 😄", add: "سجّل خلاف", card: "fight",
      fields: [
        { k: "title", label: "شو صار؟", type: "text", ph: "جملة قصيرة", req: 1 },
        { k: "body", label: "شو زعّلني؟", type: "area" },
        { k: "fix", label: "كيف صالحنا بعض؟", type: "area" },
        { k: "lesson", label: "شو تعلّمنا؟", type: "area" },
        { k: "resolved", label: "انحلّت ✅", type: "check" },
      ],
    },
    {
      id: "secrets", name: "بيت الأسرار", emoji: "🔒", x: 720, y: 1330, s: 1, wall: "#CBC3D8", roof: "#34274F", style: 3,
      resident: { name: "البومة الكتومة", emoji: "🦉", lines: ["شششش… هون أسرارنا، أنا ما بحكي.", "كلمة السر بتضل بينكم بس.", "اللي بتكتبوه هون بيتشفّر عجهازكم قبل ما يطلع.", "حتى صاحب الموقع ما بقدر يقرأ اللي هون."] },
      empty: "ما في أسرار لسا 🤫", add: "اكتب سر", card: "secret", special: "secrets",
      fields: [
        { k: "title", label: "عنوان السر", type: "text", req: 1 },
        { k: "body", label: "السر", type: "area", req: 1, big: 1 },
      ],
    },
    {
      id: "stories", name: "بيت الحكايات", emoji: "📖", x: 1060, y: 1330, s: 1, wall: "#FFE0B8", roof: "#9A5B1C", style: 1,
      resident: { name: "أبو الحكايا", emoji: "📖", lines: ["كل حكاية بدها بداية… وأنتم كملوا النهاية.", "اكتب سطرين وخلّيها تكمّل!", "يلا نألف حكاية سوا.", "الحكاية المشتركة أحلى."] },
      empty: "ابدأ أول حكاية وخلّيها تكمّل!", add: "ابدأ حكاية", card: "story", comment: { kind: "continue", label: "كمّل الحكاية", ph: "شو صار بعدين؟" },
      fields: [
        { k: "title", label: "عنوان الحكاية", type: "text", req: 1 },
        { k: "body", label: "الحكاية", type: "area", req: 1, big: 1, ph: "كان يا ما كان…" },
      ],
    },
    {
      id: "laugh", name: "بيت الضحك", emoji: "😂", x: 1540, y: 1330, s: 1, wall: "#FFF2A8", roof: "#E0A200", style: 0,
      resident: { name: "مهرّج القرية", emoji: "🤡", lines: ["ضحكة اليوم بتساوي مية دوا 😂", "عندك ميم؟ نزّله وخلينا نفرفح.", "اضغط «ضحّكني» وشوف شو بصير.", "الدنيا حلوة لما نضحك سوا."] },
      empty: "ما في ضحك لسا! نزّل أول ميم.", add: "أضف شي بيضحّك", card: "laugh", special: "laugh",
      fields: [
        { k: "body", label: "النكتة أو الموقف", type: "area", ph: "اكتب شي بيضحّك…" },
        { k: "media", label: "ميم/صورة", type: "photos" },
      ],
    },
    {
      id: "quotes", name: "بيت الاقتباسات", emoji: "💬", x: 1880, y: 1330, s: 1, wall: "#D8E3FF", roof: "#3053B8", style: 2,
      resident: { name: "أبو حكمة", emoji: "🧙‍♂️", lines: ["كلمة بتصيب القلب بتضل عمر.", "شو الجملة اللي بتعنيلك هالأيام؟", "خزّن اقتباس، بيفيدك بيوم تعبان.", "الحكمة بتنحكى مرة وبتنفع ألف."] },
      empty: "خزّنوا أول اقتباس!", add: "أضف اقتباس", card: "quote",
      fields: [
        { k: "body", label: "الاقتباس", type: "area", req: 1, big: 1 },
        { k: "by", label: "مين قاله؟ (أو من وين)", type: "text" },
        { k: "why", label: "ليش بيعنيلك؟", type: "area" },
      ],
    },
    {
      id: "library", name: "المكتبة", emoji: "📚", x: 2220, y: 1330, s: 1, wall: "#D9C6A8", roof: "#5B3A22", style: 3,
      resident: { name: "أمين المكتبة", emoji: "👓", lines: ["فيلم حلو أو كتاب بيجمع اثنين أحلى من ألف كلمة.", "شو شفتوا؟ شو رأيكم؟ قيّموا بالنجوم!", "على الطاولة فيلم الليلة؟ 🍿", "كل واحد يعطي رأيه… وبنشوف مين بيتفق."] },
      empty: "ما في كتب أو أفلام لسا.", add: "أضف عنوان", card: "library",
      fields: [
        { k: "kind", label: "النوع", type: "select", opts: KINDS.map((c) => [c, c]) },
        { k: "title", label: "الاسم", type: "text", req: 1 },
        { k: "status", label: "وين وصلنا؟", type: "select", opts: [["want", "بدنا نشوفه/نقراه"], ["done", "خلّصناه ✅"]] },
        { k: "body", label: "رأيي فيه", type: "area" },
      ],
    },
    // أماكن مختومة (مفتوحة بتاريخ)
    {
      id: "capsule", name: "الكبسولة الزمنية", emoji: "⏳", kind: "mini", x: 985, y: 1090, wall: "#B8C2CC", roof: "#5A6672",
      resident: { name: "حارس الزمن", emoji: "⏳", lines: ["اللي بنكتبه اليوم بيوصل بعد سنين… مثل رسالة من زمان.", "اقفلوها وانسوها… وبعدين فاجئوا بعض!", "الوقت أحسن صندوق أمانات."] },
      empty: "ما في كبسولات مدفونة.", add: "ادفن كبسولة", card: "capsule", sealed: true,
      fields: [
        { k: "title", label: "اسم الكبسولة", type: "text", req: 1 },
        { k: "body", label: "اللي بدك تقوله لـ «أنتم بعد زمان»", type: "area", req: 1, big: 1 },
        { k: "media", label: "صور", type: "photos" },
        { k: "unlock_at", label: "تنفتح بتاريخ", type: "unlock", req: 1, chips: [["بعد شهر", 30], ["بعد 6 شهور", 182], ["بعد سنة", 365], ["بعد 5 سنين", 1825]] },
      ],
    },
    {
      id: "surprise", name: "صندوق المفاجآت", emoji: "🎁", kind: "mini", x: 1615, y: 1090, wall: "#FFB3C7", roof: "#E63E6D",
      resident: { name: "أمين الهدايا", emoji: "🎁", lines: ["مفاجأة مستنية موعدها 🤫", "خبّي شي حلو وخلّيه ينفتح بوقته.", "كل مفاجأة بتعرف وقتها."] },
      empty: "الصندوق فاضي. جهّز مفاجأة!", add: "جهّز مفاجأة", card: "surprise", sealed: true,
      fields: [
        { k: "title", label: "اسم المفاجأة", type: "text", req: 1 },
        { k: "body", label: "شو فيها؟ (رسالة، وعد، فكرة…)", type: "area", req: 1, big: 1 },
        { k: "media", label: "صور", type: "photos" },
        { k: "unlock_at", label: "تنفتح بتاريخ", type: "unlock", req: 1, chips: [["بكرة", 1], ["بعد أسبوع", 7], ["بعد شهر", 30]] },
      ],
    },
  ];
  OSW.HOUSE = Object.fromEntries(OSW.HOUSES.map((h) => [h.id, h]));
  OSW.VISIT_HOUSES = OSW.HOUSES.map((h) => h.id).concat(["fountain", "lighthouse", "garden", "plaza", "home"]);

  OSW.MOODS = MOODS;
  OSW.REACTIONS = ["❤️", "😂", "🥹", "🔥", "👏"];

  OSW.DAILY_Q = [
    "شو أحلى شي صار معك اليوم؟", "لو بتقدر تسافر هلأ لأي مكان، وين بتروح وليش؟", "شو الأكلة اللي بتصلّح مزاجك؟",
    "شو أول شي لفت نظرك لما تعرفنا على بعض؟", "شو أصغر شي بنعمله بيفرّحك؟", "شو أغنية بتذكّرك فينا؟",
    "لو إلك يوم كامل بدون التزامات، كيف بدك نقضيه سوا؟", "شو أكتر ذكرى بتحب ترجعلها؟", "شو أكتر شي بتحلم نعمله سوا هالسنة؟",
    "شو الشي اللي بتتمنى نتعلمه سوا؟", "شو أكتر لحظة حسّيت فيها بالأمان معنا؟", "شو أحلى مفاجأة بتتخيلها؟",
    "شو أكتر موقف ضحّكنا لحد ما دمعت عيوننا؟", "شو العادة الصغيرة اللي بتحب نعملها كل يوم؟", "لو كتبنا فيلم عن قصتنا، شو بنسميه؟",
    "شو الشي اللي بدك نضل محافظين عليه دايماً؟", "شو لون يومك اليوم؟ وليش؟", "شو أحلى كلمة سمعتها مني؟",
    "شو أكتر مكان حسّيت فيه براحة؟", "لو معك ساعتين فاضيين معنا، شو بنعمل؟", "شو أكتر شي تعلمته من علاقتنا؟",
    "شو الهدية اللي بتتمنى تجيك؟", "شو أول شي بتعمله لما بتشوفني بعد غياب؟", "شو الحلم الصغير اللي لسا ما حكيتلي عنه؟",
    "شو اللي بيخليك تبتسم لما بتفتكرنا؟", "شو أكتر يوم بتتمنى يتكرر؟", "شو الشي اللي بدك نجربه لأول مرة سوا؟",
    "شو أحلى طقس بتحب نكون فيه سوا؟", "كلمة وحدة بتوصف علاقتنا هالأيام؟", "شو أكتر شي بيريحك لما بتتعب؟",
    "شو أحلى رسالة وصلتك بحياتك؟", "شو بدك نعمل بالإجازة الجاية؟", "شو أصغر خطوة بتقرّبنا أكتر؟",
    "شو الشي اللي بتتمنى ما يتغير فينا أبداً؟", "لو معك قوة خارقة، شو بتختار وليش؟", "على شو بتشكر ربنا اليوم؟",
    "احكيلي ذكرى حلوة من طفولتك.", "شو أكتر أكلة بتحب نطبخها سوا؟", "شو أحلى شي بتحبه فيك أنت؟",
  ];
  OSW.CAFE_Q = [
    "سفرة مفاجئة ولا ليلة هادية بالبيت؟ وليش؟", "احكيلي عن أغرب حلم شفته مؤخراً.", "شو بتتمنى تعرفه عني وما حكيتلك؟",
    "لو بترجع لأي يوم من حياتك، أي يوم؟", "شو أكتر موقف محرج صار معك؟", "لو عندنا بيت مثالي، شو أهم غرفة فيه؟",
    "لو بتتعشى مع أي شخص من التاريخ، مين؟", "مين أكتر شخص أثّر فيك؟", "شو أكتر عادة عندي بتضحكك؟",
    "لو بتفتح مطعم، شو اسمه وشو بيقدم؟", "شو هدفك الأساسي هالسنة؟", "بتحب الصباح ولا الليل؟ وليش؟",
    "كوب قهوة وحكي: شو اللي شاغل بالك هالأيام؟", "شو اللي بيخليك تضحك بدون سبب؟", "شو مهارة بتتمنى تتقنها؟",
    "شو أجمل هدية أخدتها بحياتك؟", "لو بتكتب رسالة لنفسك وأنت عمرك 10 سنين، شو بتقول؟", "شو رائحة بتذكّرك بشي حلو؟",
    "لو فيلم عن حياتنا، مين بتختار يمثل دورك؟", "شو أكبر إنجاز عملته بحياتك؟", "وين المكان اللي بتروحله لما بدك تهدا؟",
    "شو الشي اللي بتخاف منه وبدك تتغلب عليه؟", "لو معك مليون دينار، شو أول شي بتعمله؟", "شو أحلى شي بالصداقة برأيك؟",
    "لو بتقدر تغيّر شي واحد بالعالم، شو بيكون؟",
  ];
  OSW.SWEET = [
    "وجودك بيخلي الأيام العادية أحلى.", "اليوم ابتسم، في حدا بيفكر فيك هلأ 💛", "الحب مو بالكلام الكبير، هو بالتفاصيل الصغيرة.",
    "كل يوم معك هو يوم زيادة بالعمر الحلو.", "أنت سبب كبير من أسباب ضحكتي.", "لو الدنيا زحمة، قلبي بيلاقيك.",
    "بعض الناس بيصيروا بيت. وانت بيتي.", "الحمدلله على نعمة إنك بحياتي.", "كل لحظة معك بتستاهل نكتبها.",
    "بتعرف إنك أحلى صدفة؟", "قلبي بيقول: شكراً إنك موجود.", "الأيام الحلوة معك ما بتخلص.",
    "الحب إنك تضل بنفس المكان وقت الباقي بيروح.", "كل ما أشوفك، بتصير الدنيا أخف.", "أحلى ما فيك إنك أنت.",
    "ضحكتك هي سر القرية كلها.", "لو كان الحب نجمة، كنتي (كنت) سماي كلها.", "الأمان هو إنك تكون جنبي.",
  ];
  OSW.GREET = {
    morning: ["صباح الخير {name}! يوم جديد، وذكريات جديدة بتستناكم ☀️", "صباحو {name}! شو أول شي بدك تحكي اليوم؟"],
    noon: ["أهلين {name}! الشمس عالية والقرية نشيطة 🌤️", "يا هلا {name}! تغدّيت؟ 😄"],
    evening: ["مسا الخير {name}! الفوانيس بلّشت تشتعل 🏮", "أهلين {name}! وقت الحكي الحلو."],
    night: ["مسا النور {name}! القرية هادية والنجوم طالعة 🌙", "سهران يا {name}؟ البومة معك 🦉"],
  };
  OSW.GUIDE_TIPS = [
    "اسحب الشاشة عشان تتجول بالقرية، وكبّر/صغّر بإصبعين.",
    "اضغط على أي بيت عشان تدخله.",
    "دوّر… في كنوز مخبّأة بالقرية ✨",
    "جرّب النافورة: كل يوم في سؤال جديد إلكم.",
    "المنارة بتضوي لما حدا يكتب كلمة حلوة.",
    "الشجرة بتكبر كل ما زدتوا ذكريات 🌳",
    "بيت الأسرار مشفّر: كلمة السر عندكم بس.",
    "جرّب الحديقة، فيها لعبة صغيرة 🎮",
  ];
  OSW.HIDDEN = [
    { id: "star", emoji: "⭐", x: 140, y: 430, msg: "لقيت نجمة ضايعة! تمنّى أمنية بصمت…" },
    { id: "bottle", emoji: "🍾", x: 2735, y: 1160, msg: "رسالة بزجاجة: «مهما بعدت المسافات، قلبي عندك.»" },
    { id: "clover", emoji: "🍀", x: 2450, y: 1500, msg: "نفل بأربع ورقات! حظ حلو جاي لكم 🍀" },
    { id: "key", emoji: "🗝️", x: 520, y: 1560, msg: "مفتاح قديم… يمكن بيفتح قلب حدا 😉" },
    { id: "mush", emoji: "🍄", x: 1780, y: 1530, msg: "فطرة سحرية! بتخلي أحلامكم أوضح." },
    { id: "map", emoji: "🗺️", x: 2090, y: 770, msg: "خريطة كنز: الكنز الحقيقي هو يوم عادي بتقضيه معه/معها." },
    { id: "shell", emoji: "🐚", x: 2560, y: 1010, msg: "صدفة… لو حطيتها على إذنك بتسمع صوت «بحبك»." },
    { id: "butterfly", emoji: "🦋", x: 1130, y: 395, msg: "فراشة نادرة! دايماً بتجي عند الناس السعيدة." },
  ];
  OSW.PALETTES = {
    shirts: ["#2F7DE1", "#D6336C", "#12A594", "#F08A24", "#6E4BC4", "#E5484D", "#2B2B3A", "#E0A200"],
    hairs: ["#2b1d14", "#4a2c1a", "#8a5a2b", "#d1a35a", "#111111", "#7a1f1f", "#d9a6c2", "#e8e2d0"],
    styles: [["short", "قصير"], ["long", "طويل"], ["ponytail", "ذيل حصان"], ["hijab", "حجاب"]],
    skins: ["#f6d2b0", "#f2c9a0", "#e0a97c", "#c68a5e", "#8d5a3b"],
  };
})();

/* ---------- الملابس (تأثيرها على السرعة) ---------- */
(function () {
  const OSW = window.OSW;
  OSW.CLOTH_CATS = [["all", "✨ الكل"], ["daily", "👕 يومي"], ["trad", "🇯🇴 تراثي"], ["work", "👨‍🌾 شغل"], ["fancy", "👑 فخم"], ["fun", "🎉 مرح"]];
  OSW.CLOTHES = {
    // outfit = طقم كامل | acc = إكسسوار
    casual: { n: "لبس عادي", e: "👕", price: 0, kind: "outfit", style: "casual", speed: 1, note: "لبسك الأساسي" },
    hoodie: { n: "هودي مريح", e: "🧥", price: 60, kind: "outfit", style: "hoodie", speed: 1.03, c1: "#6c7a89", c2: "#2f3a4a", note: "خفيف ومريح (+3% سرعة)" },
    sport: { n: "لبس رياضة", e: "🏃", price: 90, kind: "outfit", style: "sport", speed: 1.18, c1: "#1fa3d8", c2: "#223344", note: "بتركض أسرع (+18%)" },
    jacket: { n: "جاكيت جلد", e: "🧥", price: 140, kind: "outfit", style: "jacket", speed: 1, c1: "#3b2f2f", c2: "#2a3140", note: "أناقة بلا تأثير" },
    suit: { n: "بدلة رسمية", e: "🤵", price: 240, kind: "outfit", style: "suit", speed: 0.8, c1: "#262b38", c2: "#262b38", gender: "boy", note: "ثقيلة (-20% سرعة) بس للمناسبات" },
    thobe: { n: "ثوب أبيض", e: "🥻", price: 150, kind: "outfit", style: "thobe", speed: 0.9, c1: "#f4f1e8", c2: "#f4f1e8", gender: "boy", note: "تراثي (-10% سرعة)" },
    dress: { n: "فستان صيفي", e: "👗", price: 170, kind: "outfit", style: "dress", speed: 0.95, c1: "#ff7aa8", c2: "#ff7aa8", gender: "girl", note: "ناعم (-5% سرعة)" },
    gown: { n: "فستان سهرة", e: "👗", price: 300, kind: "outfit", style: "gown", speed: 0.78, c1: "#6d3fb3", c2: "#6d3fb3", gender: "girl", note: "فخم وثقيل (-22% سرعة)" },
    pajama: { n: "بيجامة نوم", e: "🛌", price: 70, kind: "outfit", style: "pajama", speed: 1, c1: "#8fb8ff", c2: "#8fb8ff", note: "للنوم المريح" },
    rain: { n: "معطف مطر", e: "☔", price: 110, kind: "outfit", style: "rain", speed: 0.97, c1: "#ffd23f", c2: "#33415a", note: "للمطر والشتاء" },
    // --- جديد: أطقم يومية ---
    denim: { n: "جينز وقميص", e: "👖", price: 80, kind: "outfit", cat: "daily", style: "tee", speed: 1, c1: "#e8eef7", c2: "#3d6bb3", note: "كلاسيكي ومرتب" },
    tee_red: { n: "تيشيرت أحمر", e: "👕", price: 45, kind: "outfit", cat: "daily", style: "tee", speed: 1, c1: "#e5484d", c2: "#2f3a4a", note: "لون الحيوية" },
    tee_green: { n: "تيشيرت أخضر", e: "👕", price: 45, kind: "outfit", cat: "daily", style: "tee", speed: 1, c1: "#2fa86a", c2: "#c9b79c", note: "طبيعي ومنعش" },
    hoodie_pink: { n: "هودي وردي", e: "🧥", price: 70, kind: "outfit", cat: "daily", style: "hoodie", speed: 1.03, c1: "#ff8fb1", c2: "#7a5a86", note: "ناعم ومريح" },
    hawaii: { n: "قميص هاواي", e: "🌺", price: 85, kind: "outfit", cat: "daily", style: "hawaii", speed: 1.02, c1: "#ff7f50", c2: "#e9d9a6", note: "إجازة صيفية 🏝️" },
    varsity: { n: "جاكيت الجامعة", e: "🏈", price: 120, kind: "outfit", cat: "daily", style: "varsity", speed: 1, c1: "#2f5de0", c2: "#2a3140", note: "ستايل الطلاب" },
    puffer: { n: "جاكيت شتوي منفوخ", e: "🧥", price: 150, kind: "outfit", cat: "daily", style: "puffer", speed: 0.95, c1: "#e8a33d", c2: "#2f3a4a", note: "دافي للشتاء (-5% سرعة)" },
    poncho: { n: "بونشو صوف", e: "🧶", price: 110, kind: "outfit", cat: "daily", style: "poncho", speed: 0.97, c1: "#c0642a", c2: "#3b3b4f", note: "دافي ومزركش" },
    track: { n: "بدلة رياضية حمرا", e: "🏅", price: 130, kind: "outfit", cat: "daily", style: "sport", speed: 1.2, c1: "#e63946", c2: "#2a2a35", note: "ركض أسرع (+20%)" },
    // --- تراثي ---
    bisht: { n: "بشت وثوب", e: "🧕", price: 280, kind: "outfit", cat: "trad", style: "bisht", speed: 0.88, c1: "#f4f1e8", c2: "#f4f1e8", gender: "boy", note: "للمناسبات الكبيرة (-12% سرعة)" },
    abaya: { n: "عباية مطرزة", e: "🖤", price: 260, kind: "outfit", cat: "trad", style: "abaya", speed: 0.85, c1: "#1f1f28", c2: "#1f1f28", gender: "girl", note: "أنيقة بتطريز ذهبي (-15% سرعة)" },
    embroid: { n: "ثوب فلاحي مطرز", e: "🇯🇴", price: 320, kind: "outfit", cat: "trad", style: "embroid", speed: 0.85, c1: "#2a2230", c2: "#2a2230", gender: "girl", note: "تطريز أردني بالأحمر (-15% سرعة)" },
    jordan: { n: "زي أردني (دشداشة وسترة)", e: "🧔", price: 200, kind: "outfit", cat: "trad", style: "vest", speed: 0.92, c1: "#cdb98a", c2: "#cdb98a", gender: "boy", note: "سترة تراثية" },
    // --- شغل ومهن ---
    farmer: { n: "أفرول مزارع", e: "👨‍🌾", price: 100, kind: "outfit", cat: "work", style: "overalls", speed: 1.02, c1: "#c0392b", c2: "#3d6bb3", note: "للمزرعة والحظيرة 🐄" },
    chef: { n: "لبس الطباخ", e: "👨‍🍳", price: 120, kind: "outfit", cat: "work", style: "chef", speed: 1, c1: "#fbfbfb", c2: "#3a3a46", note: "للمطبخ" },
    doctor: { n: "بلوزة الدكتور", e: "🩺", price: 140, kind: "outfit", cat: "work", style: "doctor", speed: 1, c1: "#ffffff", c2: "#4aa3c9", note: "معطف أبيض وسماعة" },
    pilot: { n: "لبس الطيار", e: "✈️", price: 190, kind: "outfit", cat: "work", style: "pilot", speed: 1, c1: "#24344f", c2: "#24344f", note: "كحلي بشارات ذهبية" },
    cowboy: { n: "لبس رعاة البقر", e: "🤠", price: 150, kind: "outfit", cat: "work", style: "cowboy", speed: 1.02, c1: "#a8714a", c2: "#3d6bb3", note: "سترة وجينز" },
    // --- فخم ---
    tux: { n: "سموكن أبيض", e: "🤵", price: 320, kind: "outfit", cat: "fancy", style: "suit", speed: 0.8, c1: "#f1efe9", c2: "#2a2a33", gender: "boy", note: "لحفلة الأحلام" },
    prom: { n: "فستان أحمر", e: "💃", price: 330, kind: "outfit", cat: "fancy", style: "gown", speed: 0.78, c1: "#d62839", c2: "#d62839", gender: "girl", note: "إطلالة نارية" },
    princess: { n: "فستان الأميرة", e: "👸", price: 380, kind: "outfit", cat: "fancy", style: "gown", speed: 0.75, c1: "#7ad0f5", c2: "#7ad0f5", gender: "girl", note: "أزرق ملكي (-25% سرعة)" },
    king: { n: "رداء الملك", e: "🤴", price: 420, kind: "outfit", cat: "fancy", style: "king", speed: 0.75, c1: "#b3202e", c2: "#b3202e", note: "فرو أبيض وحزام ذهبي (-25% سرعة)" },
    // --- مرح ---
    astro: { n: "بدلة رائد فضاء", e: "👨‍🚀", price: 260, kind: "outfit", cat: "fun", style: "astro", speed: 0.85, c1: "#f4f6f8", c2: "#f4f6f8", note: "بطيئة بس سينمائية 🚀" },
    pirate: { n: "لبس القرصان", e: "🏴‍☠️", price: 170, kind: "outfit", cat: "fun", style: "pirate", speed: 1, c1: "#f1efe9", c2: "#2b2b35", note: "خطوط وحزام" },
    knight: { n: "درع الفارس", e: "🛡️", price: 340, kind: "outfit", cat: "fun", style: "knight", speed: 0.75, c1: "#aab4bf", c2: "#8a949f", note: "حديد ثقيل (-25% سرعة)" },
    ninja: { n: "لبس النينجا", e: "🥷", price: 280, kind: "outfit", cat: "fun", style: "ninja", speed: 1.25, c1: "#1c1c24", c2: "#1c1c24", note: "سريع وخفي (+25% سرعة)" },
    hero: { n: "بطل خارق", e: "🦸", price: 300, kind: "outfit", cat: "fun", style: "hero", speed: 1.15, c1: "#2f5de0", c2: "#d62839", note: "مع شعار وحزام (+15% سرعة)" },
    dino: { n: "بيجامة ديناصور", e: "🦖", price: 130, kind: "outfit", cat: "fun", style: "onesie", animal: "dino", speed: 1, c1: "#5fb35f", c2: "#5fb35f", note: "كشخة ودافية" },
    panda: { n: "بيجامة باندا", e: "🐼", price: 130, kind: "outfit", cat: "fun", style: "onesie", animal: "panda", speed: 1, c1: "#f4f4f4", c2: "#2b2b2b", note: "لطيفة جداً" },
    bunny: { n: "بيجامة أرنوب", e: "🐰", price: 130, kind: "outfit", cat: "fun", style: "onesie", animal: "bunny", speed: 1, c1: "#ffd3e2", c2: "#ffd3e2", note: "ودنين طويلين" },
    cap: { n: "كاب", e: "🧢", price: 35, kind: "acc", slot: "head", speed: 1 },
    shades: { n: "نظارة شمس", e: "🕶️", price: 45, kind: "acc", slot: "face", speed: 1 },
    scarf: { n: "شال", e: "🧣", price: 40, kind: "acc", slot: "neck", speed: 1 },
    crown: { n: "تاج ورد", e: "🌸", price: 55, kind: "acc", slot: "head", gender: "girl", speed: 1 },
    bow: { n: "فيونكة", e: "🎀", price: 30, kind: "acc", slot: "head", gender: "girl", speed: 1 },
    tie: { n: "ربطة عنق", e: "👔", price: 25, kind: "acc", slot: "neck", gender: "boy", speed: 1 },
    straw: { n: "قبعة قش", e: "👒", price: 40, kind: "acc", slot: "head", speed: 1 },
    beanie: { n: "طاقية صوف", e: "🧶", price: 35, kind: "acc", slot: "head", speed: 1 },
    chefhat: { n: "قبعة الطباخ", e: "👨‍🍳", price: 45, kind: "acc", slot: "head", speed: 1 },
    party: { n: "قبعة حفلة", e: "🎉", price: 30, kind: "acc", slot: "head", speed: 1 },
    cowhat: { n: "قبعة رعاة", e: "🤠", price: 60, kind: "acc", slot: "head", speed: 1 },
    pirhat: { n: "قبعة قرصان", e: "🏴‍☠️", price: 70, kind: "acc", slot: "head", speed: 1 },
    goldcrown: { n: "تاج ذهبي", e: "👑", price: 150, kind: "acc", slot: "head", speed: 1 },
    halo: { n: "هالة ملاك", e: "😇", price: 80, kind: "acc", slot: "head", speed: 1 },
    bunnyears: { n: "ودان أرنب", e: "🐰", price: 50, kind: "acc", slot: "head", speed: 1 },
    kuffiya: { n: "كوفية وعقال", e: "🧣", price: 90, kind: "acc", slot: "head", gender: "boy", speed: 1 },
    phones: { n: "سماعات", e: "🎧", price: 65, kind: "acc", slot: "head", speed: 1 },
    glasses: { n: "نظارة طبية", e: "👓", price: 40, kind: "acc", slot: "face", speed: 1 },
    mask: { n: "قناع حفلة", e: "🎭", price: 55, kind: "acc", slot: "face", speed: 1 },
    bowtie: { n: "فيونكة رسمية", e: "🎩", price: 30, kind: "acc", slot: "neck", gender: "boy", speed: 1 },
    pearls: { n: "عقد لؤلؤ", e: "📿", price: 90, kind: "acc", slot: "neck", gender: "girl", speed: 1 },
    medal: { n: "ميدالية", e: "🥇", price: 60, kind: "acc", slot: "neck", speed: 1 },
    backpack: { n: "شنطة ظهر", e: "🎒", price: 75, kind: "acc", slot: "back", speed: 1 },
    cape: { n: "عباءة سوبر", e: "🦸", price: 110, kind: "acc", slot: "back", speed: 1.05 },
    wings: { n: "أجنحة ملاك", e: "🪽", price: 160, kind: "acc", slot: "back", speed: 1 },
    fairy: { n: "أجنحة فراشة", e: "🦋", price: 160, kind: "acc", slot: "back", gender: "girl", speed: 1 },
  };
})();
